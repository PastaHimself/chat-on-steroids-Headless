/**
 * The model-visible text adapted from Codex's tool specs in
 * `codex-rs/core/src/tools/handlers/shell_spec.rs`, `view_image_spec.rs` and
 * `apply_patch_spec.rs`.
 *
 * These strings are the tools' actual contract with the model. Local changes describe batching,
 * retained results and connector output limits. Where Codex switches on `cfg!(windows)` this uses `process.platform`,
 * which is the same decision made at run time instead of compile time.
 */

import { defaultUserShell, isWindowsPowerShell5 } from './shell.js';

const IS_WINDOWS = process.platform === 'win32';

/**
 * Whether the shell `exec_command` launches is the one without `&&` and `||`.
 *
 * Not the same question as "is this Windows": `defaultUserShell()` prefers `pwsh.exe`, so on a
 * PowerShell 7 machine the operators work and saying otherwise would cost the model a working line.
 */
export const LAUNCHES_WINDOWS_POWERSHELL_5 = IS_WINDOWS && isWindowsPowerShell5(defaultUserShell().shellPath);

/**
 * `windows_shell_guidance()`, reworded (#1417).
 *
 * Codex's text is headed "Windows safety rules" and written as prohibitions ("Do not…",
 * "Never issue…"). ChatGPT's approval reviewer read that as a tool telling the model how to
 * classify risk, and stopped long unattended runs with a "Suspicious instruction" prompt that
 * names the description, not the command. The advice is unchanged; it is now phrased as notes
 * about what works in this shell.
 */
export const WINDOWS_SHELL_GUIDANCE = `Windows shell notes:
- Deleting or moving files works reliably inside one shell. Paths listed in PowerShell and handed to \`cmd /c\`, batch builtins, or another shell for deletion or moving break on quoting; use native PowerShell cmdlets such as \`Remove-Item\` / \`Move-Item\` with \`-LiteralPath\` rather than string-built shell commands.
- Before a recursive delete or move, resolve the absolute target paths and check that they lie inside the intended workspace or the explicitly named target directory, in particular when a path was computed.
- \`Start-Process\` for a background helper or service: add \`-WindowStyle Hidden\` unless the user asked for a visible window. Visible windows are for interactive tools the user needs to see or control.`;

/**
 * Said on the tool the launch goes through, because `tools/list` is re-sent every turn while the
 * session instructions are read once. On 2026-09-02 a prime testing its game could not get a
 * foreground reading out of the browser window it controlled, and instead of reusing that one
 * window it launched a fresh debug instance on a new port and profile for every retry — five
 * browsers, each one resident, and a CPU running hot for a benchmark it never got. The rule is
 * one of restraint rather than prohibition: a browser it actually uses is fine, a replacement
 * per attempt is not.
 */
export const BROWSER_LAUNCH_GUIDANCE =
  'Browsers: do not spawn a new browser, profile or debug port per attempt — each stays resident and heats the CPU. Keep to one or two windows you actually use and reuse the one already open.';

export const EXEC_COMMAND_DESCRIPTION = IS_WINDOWS
  ? `Runs a command and returns output or a session ID. Use write_stdin for progress, input, or retained output. Background results also arrive on later responses.\n\n${WINDOWS_SHELL_GUIDANCE}\n\n${BROWSER_LAUNCH_GUIDANCE}`
  : `Runs a command and returns output or a session ID. Use write_stdin for progress, input, or retained output. Background results also arrive on later responses.\n\n${BROWSER_LAUNCH_GUIDANCE}`;

/**
 * Codex's text is 'Shell command to execute.'; two measured additions.
 *
 * Windows PowerShell 5.1 has no `&&` or `||` at all, and recorded sessions show the model reaching
 * for them and getting a parse error that names the token without saying the feature is missing.
 * Separately, 109 recorded exec calls were a file being read through the shell, which `read` does
 * better and without the exec capability. Both live on the parameter because `tools/list` is
 * re-sent every turn while the session instructions are read once.
 */
export const EXEC_COMMAND_CMD_DESCRIPTION = LAUNCHES_WINDOWS_POWERSHELL_5
  ? 'Shell command to execute. To read a file, use the read tool instead. This shell is Windows PowerShell 5.1, which has no && or ||: use the cmds array for a sequence, or A; if ($?) { B }.'
  : 'Shell command to execute. To read a file, use the read tool instead.';

export const EXEC_COMMAND_CMDS_DESCRIPTION =
  'Use cmd or cmds, not both. cmds runs sequentially in one shell session; sections show exit codes. It continues after ordinary non-zero exits; first non-zero exit wins.';

export const EXEC_COMMAND_WORKDIR_DESCRIPTION = 'Working directory for the command. Defaults to the turn cwd.';

export const EXEC_COMMAND_TTY_DESCRIPTION =
  'True allocates a PTY for the command; false or omitted uses plain pipes.';

export const EXEC_COMMAND_YIELD_TIME_DESCRIPTION = IS_WINDOWS
  ? 'Wait up to 10000 ms (250-30000 on Windows). Finished commands return immediately; otherwise return a session ID.'
  : 'Wait before yielding output. Defaults to 10000 ms; effective range is 250-30000 ms.';

/**
 * `max_output_tokens` is retired from the model-facing surface, a divergence from Codex.
 *
 * ChatGPT drops a tool result over roughly 10,000 tokens before the model reads it, so raising the
 * budget bought nothing while the model spent a parameter and a guess on every call. The budget is
 * fixed at `DEFAULT_MAX_OUTPUT_TOKENS`; the runtime below still takes `maxOutputTokens`.
 *
 * It is still *accepted* because these schemas are `.strict()` and ChatGPT caches tool definitions:
 * dropping the key turned older chats' calls into `Unrecognized key`, refusing the whole command.
 * Accept it silently; the declaration already explains that it is ignored. Repeating the
 * migration advice on every result only amplified stale-schema calls into transcript noise.
 */
export const MAX_OUTPUT_TOKENS_DESCRIPTION =
  'Ignored; still accepted so older cached schemas keep working. Omit it.';

export const EXEC_COMMAND_SHELL_DESCRIPTION = "Shell binary to launch. Defaults to the user's default shell.";

export const EXEC_COMMAND_LOGIN_DESCRIPTION =
  IS_WINDOWS
    ? 'True loads the shell profile; false disables it. Defaults to false on Windows for deterministic commands.'
    : 'True runs the shell with -l/-i semantics; false disables them. Defaults to true.';

export const WRITE_STDIN_DESCRIPTION =
  // Plain function only. ChatGPT's safety check flagged "including automatic delivery; never reruns
  // work" as a Suspicious Instruction (2026-10-15) and held a long run on an approval card.
  'Polls or writes to the returned session ID. Empty chars read the session output, also after the command finished. Completed processes reject input. Keeps the latest 64 results in this app, 256 KiB each.';

export const WRITE_STDIN_SESSION_ID_DESCRIPTION = 'Returned running or completed session ID.';

export const WRITE_STDIN_CHARS_DESCRIPTION =
  'Bytes to write to stdin. Defaults to empty, which polls without writing.';

export const WRITE_STDIN_YIELD_TIME_DESCRIPTION =
  'Wait before yielding output. Non-empty writes default to 250 ms and cap at 30000 ms; empty polls wait up to 5000-300000 ms by default but return early when the first output arrives.';

/**
 * `APPLY_PATCH_LARK_GRAMMAR` (`core/src/tools/handlers/apply_patch.lark`).
 *
 * On Codex this grammar *is* the schema: `apply_patch` is `ToolSpec::Freeform`, so the model is
 * given the grammar and emits raw patch text against it. MCP advertises JSON object schemas only,
 * so the grammar moves into the description -- otherwise the model would lose the exact syntax
 * spec that Freeform hands it.
 */
export const APPLY_PATCH_LARK_GRAMMAR = `start: begin_patch hunk+ end_patch
begin_patch: "*** Begin Patch" LF
end_patch: "*** End Patch" LF?

hunk: add_hunk | delete_hunk | update_hunk
add_hunk: "*** Add File: " filename LF add_line+
delete_hunk: "*** Delete File: " filename LF
update_hunk: "*** Update File: " filename LF change_move? change?

filename: /(.+)/
add_line: "+" /(.*)/ LF -> line

change_move: "*** Move to: " filename LF
change: (change_context | change_line)+ eof_line?
change_context: ("@@" | "@@ " /(.+)/) LF
change_line: ("+" | "-" | " ") /(.*)/ LF
eof_line: "*** End of File" LF

%import common.LF`;

/**
 * Codex's description is "The `apply_patch` tool can be used to edit files. This is a FREEFORM
 * tool, so do not wrap the patch in JSON."
 *
 * The second sentence cannot survive the move to MCP -- here the patch *is* carried in JSON, as
 * the single `patch` string -- so it is replaced by the truth about this transport and followed by
 * the grammar the Freeform spec would otherwise supply. Matching and update semantics stay
 * ported from Codex; local guidance and bounded mismatch diagnostics help callers correct edits.
 */
export const APPLY_PATCH_DESCRIPTION = `The \`apply_patch\` tool can be used to edit files. Pass the patch text as the \`patch\` string; everything else about the format below is unchanged.

Within each Update File block, put edits in file order. Quote the current file text for old/context lines; matching searches forward and does not reconstruct reformatted code. On a mismatch, use the diagnostic to correct the patch before retrying.

The patch must match this grammar:

${APPLY_PATCH_LARK_GRAMMAR}`;

export const APPLY_PATCH_ARGUMENT_DESCRIPTION =
  'The patch text, from *** Begin Patch through *** End Patch, exactly as the grammar describes it.';
