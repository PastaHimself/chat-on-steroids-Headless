import { registerWorkspaceTerminalIpc } from './workspace-terminal-ipc.js';
import { forgetSurfaceTokens } from './mcp/persistent-paths.js';
import { firefoxAddonUrl } from '../shared/firefox-addon.js';
import { approvalCardView, requestApprovalAnswer } from './approval-wait.js';
import { registerDictationIpc } from './dictation.js';
import { CONNECTOR_SUFFIX_MAX, CONNECTOR_SUFFIX_PATTERN } from '../shared/connector-names.js';
import { setStopNoticeTranslations } from './stuck-notice.js';
import { setMainTextTranslations } from './main-texts.js';
import { applyLoginStartup, supportsLoginStartup } from './window-lifecycle.js';
import { startControlApi, stopControlApi } from './control-api.js';
import { appearanceSchema } from './appearance-schema.js';
import { mergeAppearance } from '../shared/appearance.js';
import { prepareSessionPrompt, prepareSkillFollowup } from './session/prompt.js';
import { importSkillFile, importSkillPackage, listManagedSkills, listSkills, removeSkill } from './skills.js';
import { checkGitHubSkillUpdates, importGitHubSkill, linkGitHubSkill, updateGitHubSkill } from './skill-github.js';
import { SKILL_ID_PATTERN } from '../shared/skills.js';
import { listSkillLibrary } from './skill-library.js';
import { installRecommendedSkill, listRecommendedSkills } from './recommended-skills.js';
import { noteChatOrigin } from './session/recorder.js';
import { refreshAppProxy } from './app-proxy.js';
import { committedResumeAncestorsFromSummary, DEFAULT_RECORDING_STORAGE_GIB, REASONING_EFFORTS, RECORDING_STORAGE_LIMITS_GIB, type RecordingStorageLimitGiB, type SessionChange } from '../shared/session.js';
import { safeExternalLink } from '../shared/external-link.js';
import { wakeBrowserWork } from './browser-wake.js';
import { refreshKeepAwake } from './keep-awake.js';
import { getChatModels, startChatModelDiscovery, configureChatModelDiscovery } from './chat-models.js';
import { releaseSessionFinish, requestSessionFinishGoal } from './session/finish.js';
import { GOAL_MARKER_INSTRUCTION } from '../shared/goal-templates.js';
import { validateInputImages } from './session/input-images.js';
import { stageInputAttachment, stageInputAttachments, type AttachmentSource } from './session/input-attachments.js';
import { recordDeliveredInput, recordedInputImage } from './session/input-history.js';
import { UI_BASE_ZOOM, titleBarOverlayForTheme, windowBackgroundForTheme } from './window-layout.js';
import { usageOverview } from './session/usage.js';
import { readProviderUsage } from './provider-usage.js';
import { inputArgs, listInputs, editQueuedInput, sendQueuedInputNow, reorderQueuedInputs, setInputAutomation, configureInputDelivery, pausedBrowserHelpers, cancelFinishInputs } from './session/input.js';
import { draftOpeningMessage, onGoalChange, nativeGoalFailure } from './goal.js';
import { cancelTaskRequest, runTaskRequest } from './task-request.js';
import { randomUUID } from 'node:crypto';
import { retryGoalBrowserHelper } from './goal.js';
import { requestBrowserPreferences } from './browser-preferences.js';
import { sendDesktopInput, cancelDesktopInput, retryQueuedInputBrowser } from './session/start-input.js';
import { wakeBrowserUrl } from './browser-startup.js';
import { registerPluginIpc } from './plugins-ipc.js';
import { deletePet, importPet, loadPetAsset, petLibraryState, setPetEnabled, setPetFavorite } from './pet-library.js';
import { petOverlayControlState, refreshPetOverlayActivities, refreshPetOverlayAppearance, setPetOverlayVisible } from './pet-overlay.js';
import { confirmedPluginSchemas, pluginRefreshPublications, pluginRefreshStatuses, onPluginRefreshChange, pluginRefreshUnreadable, resetPluginRefreshLedger } from './plugin-refresh.js';
/**
 * IPC surface.
 *
 * A fixed list of named handlers, each validating its own input with zod. There is no
 * generic "call this method" or "read this file" channel, so a compromised renderer
 * gains only the operations listed below — it can never reach the filesystem or spawn
 * a process directly. Secrets travel one way: the renderer can set or clear the API
 * key but can never read it back.
 */

import { app, BrowserWindow, clipboard, dialog, ipcMain, nativeTheme, shell } from 'electron';
import { z } from 'zod';
import {
  CAPABILITIES,
  browserExtensionRequired,
  CHAT_BROWSERS,
  GOAL_MODES,
  GOAL_PROVIDERS,
  GOAL_REASONING_LEVELS,
  type AppState,
  type Config
} from '../shared/types.js';
import { MAX_GOAL_SYSTEM_PROMPT_CHARS } from '../shared/goal.js';
import { DEFAULT_HANDOFF_LENGTH, HANDOFF_LENGTHS, MAX_HANDOFF_PROMPT_CHARS } from '../shared/handoff.js';
import { applySettings, connect, disconnect, getStatus, onStatusChange, rememberRunningSurfaceTokens } from './connection.js';
import { effectiveCapabilities, getConfig, updateConfig, MAX_MCP_INSTRUCTIONS_CHARS, browserBridgePortSchema, settingsRecovered } from './config.js';
import { UI_LANGUAGES } from '../shared/ui-language.js';
import { PROJECT_COLORS } from '../shared/projects.js';
import { bridgePortSelection } from './bridge-ports.js';
import { clearAllGoalSwitches, draftTaskPlan, listGoalModels, MODEL_PAGE_SIZE, retireGoalDrafts, goalBackendFor, goalSwitchFor, setGoalSwitchNow, setGoalReplyActiveNow, setGoalObjectiveNow } from './goal.js';
import { forgetExposedSurface } from './mcp/server.js';
import { runningToolActivity } from './mcp/call-context.js';
import { onBackgroundExecChange, runningExecProcesses, stopExecProcess } from './codex/ownership.js';
import { keychainNoticeReady } from './keychain-notice.js';
import { runDiagnostics } from './diagnostics.js';
import { readRecentLog, renderDiagnosticsReport, saveDiagnosticsReport, systemFacts, memoryFacts } from './diagnostics-report.js';
import { listSessions, readTurnTraces } from './session/store.js';
import { formatLogAsJson, formatLogForClipboard, getLog, logInfo, logWarn, onLog } from './logger.js';
import { managedWorktreeCleanupOffers, acknowledgeManagedWorktreeCleanupOffer } from './agents.js';
import { listOfferedWorkerWorktrees, disposeOfferedWorkerWorktree, WorkerWorktreeError } from './worktrees/index.js';
import type { WorkerWorktreeCleanupOffer } from '../shared/session.js';
import { unifiedExecManager } from './codex/manager.js';
import { inFlightToolCalls } from './mcp/call-context.js';
import { RESERVED_ROOT_NAMES, uniqueRootName, validateNewRoot, SandboxError, resolvePath } from './sandbox.js';
import { addProject, expireArmedProjectCreates, getSessionProject, listProjects, onProjectLinkChange, projectWorkspace, removeProject, retryProjectCreate, setProjectColor } from './projects.js';
import { createProjectEntry, listProjectDirectory, previewProjectFile, projectFileTarget, renameProjectEntry, revalidateProjectFileTarget, saveProjectTextFile } from './project-files.js';
import { ProjectFileWatchSet } from './project-file-watcher.js';
import { ProjectGitWatchSet, readProjectGitDiff, readProjectGitSnapshot } from './project-git.js';
import { hasSecret, isEncryptionAvailable, secureStorageStatus, setAsideUnreadableSecrets, setSecret, storedSecretsUnreadable } from './secrets.js';
import { setupApiKeySlot } from '../shared/setup-profile.js';
import { addSetupProfile, removeSetupProfile, switchSetupProfile } from './setup-profiles.js';
import { bundledVersion, locateBinary } from './tunnel/locate.js';
import { TUNNEL_ID_PATTERN } from './tunnel/index.js';
import {
  bridgeStatus,
  publishBridgePortChange,
  companionDiagnostics,
  sessionInputActivity,
  recoveryHeldByCalls, recoveryInputAllowed,
  sessionControlsFor, cancelAssistantRecovery, stopSessionTurn, setSessionAutomation, setSessionObjective, compactSession, resumeFromSavedSummary, cancelSessionCompaction,
  cancelWorkerCommands,
  chatUrl,
  revealChatInBrowser,
  pendingCommands,
  onBridgeChange,
  startBridge,
  stopBridge,
  sweepStaleSwarm,
  unpair,
  followChatInBackground
} from './bridge.js';
import { extensionDir } from './extension-path.js';
import { APP_VERSION, extensionDownloadUrl } from './version.js';
import {
  deleteSession,
  clearImageStorage,
  onRecordingStorageFullChange,
  recordingStorageFull,
  clearSessionName,
  renameSession,
  getSession,
  getImageStorage,
  setRecordingStorageLimit,
  readHandoff,
  readToolEditReview,
  withSessionMutationFence
} from './session/store.js';
import { forgetSession, notifyChanged, onSessionChange } from './session/recorder.js';
import { findInSession, locateSearchMatch, searchSessions } from './session/search.js';
import { readSessionEvents, readSessionList, sessionListCursorSchema } from './session/read-model.js';
import { exportSessionMarkdown } from './session/markdown-export.js';
import { blockedChatIds, setChatsBlocked } from './session/blocked-chats.js';
import { setChatsTrusted, trustedChatIds } from './session/trusted-chats.js';
import {
  clearAgent,
  onSwarmChange,
  pauseSwarmForDisable,
  persistAgentAuthorityNow,
  workerPrimeOwner,
  resetSwarm,
  swarmState
} from './agents.js';
import { forgetWorkspaceRoot, renameWorkspaceRoot } from './workspace.js';
import { hostPlatformInfo } from './platform.js';
import {
  MAX_COMMAND_ALLOWLIST_RULES,
  MAX_COMMAND_ALLOWLIST_RULE_CHARS,
  validateCommandAllowlistRule
} from '../shared/command-allowlist.js';
import { cosBrowserSignedIn, onCosBrowserSignInChange } from './cos-browser/sign-in.js';
import { loadCosBrowser, syncCosBrowser } from './cos-browser/selection.js';
import { onConnectorProofChange } from './connector-proof.js';
import { opensInCosBrowser } from '../shared/cos-browser-sites.js';
import { openInPreferredBrowser } from './browser.js';
import { checkForUpdatesIfStale, manualDownloadUrl, markInstallOnQuit, onUpdateChange, updateStatus } from './update.js';
import { updateAll } from './update-all.js';
import {
  getMacOSDesktopAccess,
  onMacOSDesktopAccessChange,
  refreshMacOSDesktopAccess
} from './computer/index.js';

/** Fixed native Settings destinations; authored chat links use the shared web/mail policy. */
const ALLOWED_LINKS = new Set([
  'x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility',
  'x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture'
]);

const capabilityPatch = z.object(
  Object.fromEntries(CAPABILITIES.map((c) => [c, z.boolean()])) as Record<
    (typeof CAPABILITIES)[number],
    z.ZodBoolean
  >
);

const settingsPatch = z.object({
  // This computer's connector name suffix; see shared/connector-names.ts. Spaces are collapsed.
  connectorSuffix: z.string().max(64).transform(value => value.trim().replace(/\s+/g, ' '))
    .refine(value => value.length <= CONNECTOR_SUFFIX_MAX && CONNECTOR_SUFFIX_PATTERN.test(value),
      'Use up to 32 letters, digits, spaces, dots, dashes or underscores').optional(),
  capabilities: capabilityPatch,
  readOnly: z.boolean(),
  commandAllowlist: z.object({
    enabled: z.boolean(),
    mode: z.enum(['allow', 'deny']).optional().default('allow'),
    rules: z.array(z.string().max(MAX_COMMAND_ALLOWLIST_RULE_CHARS).superRefine((rule, ctx) => {
      const message = validateCommandAllowlistRule(rule);
      if (message) ctx.addIssue({ code: 'custom', message });
    })).max(MAX_COMMAND_ALLOWLIST_RULES)
  }),
  tunnel: z.object({
    profileId: z.string().max(64).optional(),
    profileEpoch: z.number().int().nonnegative().optional(),
    pluginsTunnelId: z.string().max(128).refine(v => v === '' || TUNNEL_ID_PATTERN.test(v), 'Expected tunnel_ followed by 32 hex characters').optional(),
    kind: z.enum(['openai', 'cloudflared', 'manual']),
    tunnelId: z
      .string()
      .max(128)
      .refine((v) => v === '' || TUNNEL_ID_PATTERN.test(v), 'Expected tunnel_ followed by 32 hex characters'),
    // The Desktop connector's own tunnel. Empty is normal and means "not published":
    // Desktop is optional, and most users will never create a second Secure Tunnel.
    desktopTunnelId: z
      .string()
      .max(128)
      .refine((v) => v === '' || TUNNEL_ID_PATTERN.test(v), 'Expected tunnel_ followed by 32 hex characters'),
    binaryPath: z.string().max(4096)
  }),
  ui: z.object({
    appearance: appearanceSchema.optional(),
    autoContinue: z.boolean().optional(),
    defaultChatModel: z.string().trim().min(1).max(80).optional(),
    defaultChatReasoning: z.enum(REASONING_EFFORTS).optional(),
    chatBrowser: z.enum(CHAT_BROWSERS).optional(),
    cosBrowserMinimize: z.enum(['taskbar', 'tray']).optional(),
    developerMode: z.boolean().optional(),
    playfulStatus: z.boolean().optional(),
    playfulContinue: z.boolean().optional(),
    followOutput: z.boolean().optional(),
    mentionCore: z.boolean().optional(),
    language: z.enum(UI_LANGUAGES).optional(),
    browserPreferences: z.object({ overwrite: z.boolean(), durations: z.boolean() }).strict().optional(),
    cosBrowserTrayHint: z.boolean().optional(),
    finishTool: z.boolean().optional(),
    planBackend: z.enum(['chatgpt', 'api']).optional(),
    finishAction: z.enum(['notify', 'goal']).optional(),
    finishLeadMinutes: z.number().int().min(3).max(5).optional(),
    backgroundChats: z.boolean().optional(),
    backgroundPlacement: z.enum(['window', 'group']).optional(),
    followUp: z.enum(['steer', 'queue']).optional(),
    enterSends: z.boolean().optional(),
    browserBridgePort: browserBridgePortSchema.optional(),
    browserOnly: z.boolean().optional(),
    autoRefreshPlugins: z.boolean().optional(),
    autoRefreshPluginsAsked: z.boolean().optional(),
    autoSelectSkills: z.boolean().optional(),
    tabsToKeepOpen: z.number().int().min(1).max(50).optional(),
    minimizeToTray: z.boolean(),
    autoConnect: z.boolean(),
    startAtLogin: z.boolean().optional(),
    turnNotifications: z.boolean().optional(),
    rotateTurnMinutes: z.number().int().min(0).max(120).optional(),
    localAppUsage: z.boolean().optional(),
    keepAwake: z.boolean().optional(),
    keepScreenAwake: z.boolean().optional(),
    privacyScreenshots: z.boolean(),
    theme: z.enum(['light', 'dark'])
  }),
  sessions: z.object({
    record: z.boolean(),
    retainDays: z.number().int().min(0).max(3650),
    advisoryTokens: z.number().int().min(10_000).max(4_000_000),
    limitTokens: z.number().int().min(10_000).max(4_000_000),
    storageLimitGiB: z.number().refine(size => (RECORDING_STORAGE_LIMITS_GIB as readonly number[]).includes(size))
      .transform(size => size as RecordingStorageLimitGiB).optional()
  }),
  compaction: z.object({
    auto: z.boolean(),
    // Floored well above what a fresh chat holds, so a threshold cannot be set somewhere
    // every conversation is already past the moment it opens.
    autoTokens: z.number().int().min(10_000).max(4_000_000),
    handoffPrompt: z.string().trim().min(1).max(MAX_HANDOFF_PROMPT_CHARS),
    handoffLength: z.enum(HANDOFF_LENGTHS).optional()
  }),
  multiAgent: z.object({
    enabled: z.boolean(),
    defaultModel: z.string().max(80).optional(),
    defaultReasoning: z.enum(['', ...REASONING_EFFORTS]).optional(),
    maxWorkers: z.number().int().min(1).max(8),
    globalMaxWorkers: z.number().int().min(0).max(64).optional(),
    allowUnattributedCalls: z.boolean(),
    strictChatAllowlist: z.boolean().optional(),
    recoverAgentTabs: z.boolean(),
    waitForSubAgents: z.boolean().optional(),
    autoWorktrees: z.boolean().optional(),
    endSleepingWorkerProcesses: z.boolean().optional(),
    archiveWorkerChats: z.boolean().optional()
  }),
  mcp: z.object({ instructions: z.string().trim().max(MAX_MCP_INSTRUCTIONS_CHARS), persistentUrls: z.boolean().optional() }).strict().optional(),
  controlApi: z.object({ enabled: z.boolean(), allowActions: z.boolean().optional() }).strict().optional(),
  goal: z.object({
    impulseMinutes: z.number().int().min(0).max(60).optional(),
    includeToolCalls: z.boolean().optional(),
      backend: z.enum(['api', 'chatgpt', 'templates']).optional(),
      loopBackend: z.enum(['api', 'chatgpt']).optional(),
      helperModel: z.string().trim().min(1).max(80).optional(),
      helperReasoning: z.enum(REASONING_EFFORTS).optional(),
    enabled: z.boolean(),
    // Which of the two standing modes the switch runs. One field, so the renderer has no way
    // to describe a state where Goal and Loop are both on.
    mode: z.enum(GOAL_MODES),
    // Which LLM endpoint Goal/Loop drafts run on, plus the custom endpoint's base URL.
    // The URL is stored verbatim and validated at draft time (see resolveGoalBaseUrl):
    // a shape check here would either duplicate that logic or silently rewrite the address.
    provider: z.object({
      kind: z.enum(GOAL_PROVIDERS),
      baseUrl: z.string().max(2048)
    }),
    // An OpenRouter model id while the provider is openrouter, validated only as a shape:
    // the catalogue changes weekly, and an allow-list here would mean this app deciding
    // which models exist.
    // The leading `~` is OpenRouter's own marker for an alias that always resolves to the
    // newest model in a family — `~deepseek/deepseek-v4-flash-latest` and eleven others. The
    // picker lists them because the listing does, so refusing them here meant the one kind
    // of entry most worth choosing was the one kind that could not be saved.
    // A custom endpoint names its own models (`llama3.1`, a deployment id), so while custom
    // it is any non-empty id instead.
    model: z.string().min(1).max(160),
    reasoning: z.enum(GOAL_REASONING_LEVELS),
    prompt: z.string().trim().min(1).max(MAX_GOAL_SYSTEM_PROMPT_CHARS),
    objectivePrompt: z.string().trim().min(1).max(MAX_GOAL_SYSTEM_PROMPT_CHARS),
    loopPrompt: z.string().trim().min(1).max(MAX_GOAL_SYSTEM_PROMPT_CHARS)
  }).superRefine((goal, ctx) => {
    if (goal.provider.kind !== 'custom' && !/^~?[a-z0-9._-]+\/[a-z0-9._-]+(:[a-z0-9._-]+)?$/i.test(goal.model)) {
      ctx.addIssue({
        code: 'custom',
        path: ['model'],
        message: 'Expected an OpenRouter model id like vendor/model'
      });
    }
  })
});

const settingsSave = z.object({ base: settingsPatch, patch: settingsPatch }).strict();
type SettingsSnapshot = z.infer<typeof settingsPatch>;

/**
 * Three-way merge for the renderer's settings form.
 *
 * The Chrome extension is a second writer for Goal/Auto Compact. The renderer previously sent
 * a blind full snapshot for every checkbox/theme edit, so a snapshot captured just before an
 * extension write could land just after it and silently undo that newer value. A field which is
 * unchanged between `base` and `wanted` was not edited by this renderer save and therefore keeps
 * the current main-process value. A field that differs was deliberately edited here and wins.
 */
function mergeSettings(current: Config, base: SettingsSnapshot, wanted: SettingsSnapshot): Omit<SettingsSnapshot, 'controlApi'> & { controlApi: Config['controlApi'] } {
  const tunnelEdited = (['tunnelId', 'desktopTunnelId', 'pluginsTunnelId'] as const)
    .some(key => (base.tunnel[key] ?? '') !== (wanted.tunnel[key] ?? ''));
  if (tunnelEdited && ((base.tunnel.profileId ?? 'default') !== (current.tunnel.profileId ?? 'default') ||
      (base.tunnel.profileEpoch ?? 0) !== (current.tunnel.profileEpoch ?? 0))) {
    throw new Error('Setup profile changed. Edit the tunnel ID in the selected profile again.');
  }
  const pick = <T>(live: T, before: T, next: T): T => (Object.is(before, next) ? live : next);
  const pickRules = (live: string[], before: string[], next: string[]): string[] =>
    before.length === next.length && before.every((rule, index) => rule === next[index]) ? live : next;
  const capabilities = Object.fromEntries(
    CAPABILITIES.map((capability) => [
      capability,
      pick(current.capabilities[capability], base.capabilities[capability], wanted.capabilities[capability])
    ])
  ) as Config['capabilities'];
  // The two switches merge independently, and actions never outlive the API. A form that omits
  // `allowActions` leaves it as it is.
  let controlApi = current.controlApi;
  if (wanted.controlApi) {
    const enabled = pick(current.controlApi.enabled, base.controlApi?.enabled ?? false, wanted.controlApi.enabled);
    const allowActions = wanted.controlApi.allowActions === undefined
      ? current.controlApi.allowActions
      : pick(current.controlApi.allowActions, base.controlApi?.allowActions ?? false, wanted.controlApi.allowActions);
    controlApi = { enabled, allowActions: enabled && allowActions === true };
  }
  return {
    ...(wanted.connectorSuffix === undefined ? {} : {
      connectorSuffix: pick(current.connectorSuffix ?? '', base.connectorSuffix ?? '', wanted.connectorSuffix)
    }),
    mcp: wanted.mcp ? { instructions: pick(current.mcp.instructions, base.mcp?.instructions ?? '', wanted.mcp.instructions),
      persistentUrls: pick(current.mcp.persistentUrls === true, base.mcp?.persistentUrls === true, wanted.mcp.persistentUrls ?? current.mcp.persistentUrls === true) } : current.mcp,
    controlApi,
    capabilities,
    readOnly: pick(current.readOnly, base.readOnly, wanted.readOnly),
    commandAllowlist: {
      enabled: pick(current.commandAllowlist.enabled, base.commandAllowlist.enabled, wanted.commandAllowlist.enabled),
      mode: pick(current.commandAllowlist.mode, base.commandAllowlist.mode, wanted.commandAllowlist.mode),
      rules: pickRules(current.commandAllowlist.rules, base.commandAllowlist.rules, wanted.commandAllowlist.rules)
    },
    tunnel: {
      ...current.tunnel,
        pluginsTunnelId: wanted.tunnel.pluginsTunnelId === undefined ? current.tunnel.pluginsTunnelId ?? ''
          : pick(current.tunnel.pluginsTunnelId ?? '', base.tunnel.pluginsTunnelId ?? '', wanted.tunnel.pluginsTunnelId),
      kind: pick(current.tunnel.kind, base.tunnel.kind, wanted.tunnel.kind),
      tunnelId: pick(current.tunnel.tunnelId, base.tunnel.tunnelId, wanted.tunnel.tunnelId),
      desktopTunnelId: pick(
        current.tunnel.desktopTunnelId,
        base.tunnel.desktopTunnelId,
        wanted.tunnel.desktopTunnelId
      ),
      binaryPath: pick(current.tunnel.binaryPath, base.tunnel.binaryPath, wanted.tunnel.binaryPath)
    },
    ui: {
      appearance: mergeAppearance(current.ui.appearance, base.ui.appearance, wanted.ui.appearance),
      autoContinue: pick(current.ui.autoContinue, base.ui.autoContinue, wanted.ui.autoContinue),
      defaultChatModel: pick(current.ui.defaultChatModel, base.ui.defaultChatModel, wanted.ui.defaultChatModel),
      defaultChatReasoning: pick(current.ui.defaultChatReasoning, base.ui.defaultChatReasoning, wanted.ui.defaultChatReasoning),
      chatBrowser: pick(current.ui.chatBrowser, base.ui.chatBrowser, wanted.ui.chatBrowser),
      cosBrowserMinimize: pick(current.ui.cosBrowserMinimize, base.ui.cosBrowserMinimize, wanted.ui.cosBrowserMinimize),
      developerMode: pick(current.ui.developerMode, base.ui.developerMode, wanted.ui.developerMode),
      playfulStatus: pick(current.ui.playfulStatus, base.ui.playfulStatus, wanted.ui.playfulStatus),
      playfulContinue: pick(current.ui.playfulContinue, base.ui.playfulContinue, wanted.ui.playfulContinue),
      followOutput: pick(current.ui.followOutput, base.ui.followOutput, wanted.ui.followOutput),
      mentionCore: pick(current.ui.mentionCore, base.ui.mentionCore, wanted.ui.mentionCore),
      // Not part of the settings form: reported by the window and the extension, carried through.
      language: current.ui.language,
      browserPreferences: current.ui.browserPreferences,
      cosBrowserTrayHint: current.ui.cosBrowserTrayHint,
      finishTool: pick(current.ui.finishTool, base.ui.finishTool, wanted.ui.finishTool),
      planBackend: pick(current.ui.planBackend, base.ui.planBackend, wanted.ui.planBackend),
      finishAction: pick(current.ui.finishAction, base.ui.finishAction, wanted.ui.finishAction),
      finishLeadMinutes: pick(current.ui.finishLeadMinutes, base.ui.finishLeadMinutes, wanted.ui.finishLeadMinutes),
      backgroundChats: pick(current.ui.backgroundChats, base.ui.backgroundChats, wanted.ui.backgroundChats),
      backgroundPlacement: pick(current.ui.backgroundPlacement, base.ui.backgroundPlacement, wanted.ui.backgroundPlacement),
      followUp: pick(current.ui.followUp, base.ui.followUp, wanted.ui.followUp),
      enterSends: pick(current.ui.enterSends, base.ui.enterSends, wanted.ui.enterSends),
      browserBridgePort: wanted.ui.browserBridgePort === undefined ? current.ui.browserBridgePort
        : pick(current.ui.browserBridgePort ?? 'auto', base.ui.browserBridgePort ?? 'auto', wanted.ui.browserBridgePort),
      browserOnly: pick(current.ui.browserOnly, base.ui.browserOnly, wanted.ui.browserOnly),
      autoRefreshPlugins: pick(current.ui.autoRefreshPlugins, base.ui.autoRefreshPlugins, wanted.ui.autoRefreshPlugins),
      // Only the offer's own call answers it; a settings save never takes it back.
      autoRefreshPluginsAsked: current.ui.autoRefreshPluginsAsked === true || wanted.ui.autoRefreshPluginsAsked === true,
      autoSelectSkills: pick(current.ui.autoSelectSkills, base.ui.autoSelectSkills, wanted.ui.autoSelectSkills),
      tabsToKeepOpen: pick(current.ui.tabsToKeepOpen, base.ui.tabsToKeepOpen, wanted.ui.tabsToKeepOpen),
      minimizeToTray: pick(current.ui.minimizeToTray, base.ui.minimizeToTray, wanted.ui.minimizeToTray),
      autoConnect: pick(current.ui.autoConnect, base.ui.autoConnect, wanted.ui.autoConnect),
      startAtLogin: pick(current.ui.startAtLogin, base.ui.startAtLogin, wanted.ui.startAtLogin),
      turnNotifications: pick(current.ui.turnNotifications, base.ui.turnNotifications, wanted.ui.turnNotifications),
      rotateTurnMinutes: pick(current.ui.rotateTurnMinutes, base.ui.rotateTurnMinutes, wanted.ui.rotateTurnMinutes),
      localAppUsage: pick(current.ui.localAppUsage, base.ui.localAppUsage, wanted.ui.localAppUsage),
      keepAwake: pick(current.ui.keepAwake, base.ui.keepAwake, wanted.ui.keepAwake),
      keepScreenAwake: pick(current.ui.keepScreenAwake, base.ui.keepScreenAwake, wanted.ui.keepScreenAwake),
      privacyScreenshots: pick(
        current.ui.privacyScreenshots,
        base.ui.privacyScreenshots,
        wanted.ui.privacyScreenshots
      ),
      theme: pick(current.ui.theme, base.ui.theme, wanted.ui.theme)
    },
    sessions: {
      record: pick(current.sessions.record, base.sessions.record, wanted.sessions.record),
      retainDays: pick(current.sessions.retainDays, base.sessions.retainDays, wanted.sessions.retainDays),
      advisoryTokens: pick(
        current.sessions.advisoryTokens,
        base.sessions.advisoryTokens,
        wanted.sessions.advisoryTokens
      ),
      limitTokens: pick(current.sessions.limitTokens, base.sessions.limitTokens, wanted.sessions.limitTokens),
      storageLimitGiB: pick(current.sessions.storageLimitGiB, base.sessions.storageLimitGiB, wanted.sessions.storageLimitGiB)
    },
    compaction: {
      auto: pick(current.compaction.auto, base.compaction.auto, wanted.compaction.auto),
      autoTokens: pick(current.compaction.autoTokens, base.compaction.autoTokens, wanted.compaction.autoTokens),
      handoffPrompt: pick(
        current.compaction.handoffPrompt,
        base.compaction.handoffPrompt,
        wanted.compaction.handoffPrompt
      ),
      handoffLength: pick(
        current.compaction.handoffLength ?? DEFAULT_HANDOFF_LENGTH,
        base.compaction.handoffLength ?? DEFAULT_HANDOFF_LENGTH,
        wanted.compaction.handoffLength ?? DEFAULT_HANDOFF_LENGTH
      )
    },
    multiAgent: {
      defaultModel: pick(current.multiAgent.defaultModel, base.multiAgent.defaultModel, wanted.multiAgent.defaultModel),
      defaultReasoning: pick(current.multiAgent.defaultReasoning, base.multiAgent.defaultReasoning, wanted.multiAgent.defaultReasoning),
      enabled: pick(current.multiAgent.enabled, base.multiAgent.enabled, wanted.multiAgent.enabled),
      maxWorkers: pick(current.multiAgent.maxWorkers, base.multiAgent.maxWorkers, wanted.multiAgent.maxWorkers),
      globalMaxWorkers: pick(
        current.multiAgent.globalMaxWorkers ?? 0,
        base.multiAgent.globalMaxWorkers ?? 0,
        wanted.multiAgent.globalMaxWorkers ?? 0
      ),
      allowUnattributedCalls: pick(
        current.multiAgent.allowUnattributedCalls,
        base.multiAgent.allowUnattributedCalls,
        wanted.multiAgent.allowUnattributedCalls
      ),
      strictChatAllowlist: pick(
        current.multiAgent.strictChatAllowlist ?? false,
        base.multiAgent.strictChatAllowlist ?? false,
        wanted.multiAgent.strictChatAllowlist ?? false
      ),
      recoverAgentTabs: pick(
        current.multiAgent.recoverAgentTabs,
        base.multiAgent.recoverAgentTabs,
        wanted.multiAgent.recoverAgentTabs
      ),
      waitForSubAgents: pick(
        current.multiAgent.waitForSubAgents,
        base.multiAgent.waitForSubAgents,
        wanted.multiAgent.waitForSubAgents
      ),
      autoWorktrees: pick(
        current.multiAgent.autoWorktrees ?? false,
        base.multiAgent.autoWorktrees ?? false,
        wanted.multiAgent.autoWorktrees ?? false
      ),
      endSleepingWorkerProcesses: pick(
        current.multiAgent.endSleepingWorkerProcesses ?? false,
        base.multiAgent.endSleepingWorkerProcesses ?? false,
        wanted.multiAgent.endSleepingWorkerProcesses ?? false
      ),
      archiveWorkerChats: pick(
        current.multiAgent.archiveWorkerChats ?? false,
        base.multiAgent.archiveWorkerChats ?? false,
        wanted.multiAgent.archiveWorkerChats ?? false
      )
    },
    goal: {
      impulseMinutes: pick(current.goal.impulseMinutes, base.goal.impulseMinutes, wanted.goal.impulseMinutes),
      includeToolCalls: pick(current.goal.includeToolCalls, base.goal.includeToolCalls, wanted.goal.includeToolCalls),
      backend: pick(current.goal.backend, base.goal.backend, wanted.goal.backend),
      loopBackend: pick(current.goal.loopBackend, base.goal.loopBackend, wanted.goal.loopBackend),
      helperModel: pick(current.goal.helperModel, base.goal.helperModel, wanted.goal.helperModel),
      helperReasoning: pick(current.goal.helperReasoning, base.goal.helperReasoning, wanted.goal.helperReasoning),
      enabled: pick(current.goal.enabled, base.goal.enabled, wanted.goal.enabled),
      mode: pick(current.goal.mode, base.goal.mode, wanted.goal.mode),
      provider: {
        kind: pick(current.goal.provider.kind, base.goal.provider.kind, wanted.goal.provider.kind),
        baseUrl: pick(current.goal.provider.baseUrl, base.goal.provider.baseUrl, wanted.goal.provider.baseUrl)
      },
      model: pick(current.goal.model, base.goal.model, wanted.goal.model),
      reasoning: pick(current.goal.reasoning, base.goal.reasoning, wanted.goal.reasoning),
      prompt: pick(current.goal.prompt, base.goal.prompt, wanted.goal.prompt),
      objectivePrompt: pick(
        current.goal.objectivePrompt,
        base.goal.objectivePrompt,
        wanted.goal.objectivePrompt
      ),
      loopPrompt: pick(current.goal.loopPrompt, base.goal.loopPrompt, wanted.goal.loopPrompt)
    }
  };
}

const sessionIdArg = z.object({ id: z.string().min(8).max(64).regex(/^[0-9a-z-]+$/i) });
/** A chat's own name in the app (#1107): one line, no control characters; null or blank clears it. */
const sessionNameArg = sessionIdArg.extend({ title: z.string().max(2000).nullable() });
export function cleanSessionName(title: string | null): string | null {
  const clean = (title ?? '').replace(/[\u0000-\u001f\u007f-\u009f\u2028\u2029]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 120).trim();
  return clean || null;
}
const agentIdArg = z.string().min(1).max(64).regex(/^[0-9a-z-]+$/i);

const renameRoot = z.object({
  name: z.string().min(1).max(32),
  newName: z
    .string()
    .min(1)
    .max(32)
    .regex(/^[a-z0-9][a-z0-9._-]*$/, 'Lowercase letters, digits, dot, dash and underscore only')
});

function resolvedBinary(config: Config): string | null {
  if (config.tunnel.kind === 'cloudflared') return locateBinary('cloudflared', config.tunnel.binaryPath);
  if (config.tunnel.kind === 'openai') return locateBinary('tunnel-client', config.tunnel.binaryPath);
  return null;
}

async function buildState(): Promise<AppState> {
  const config = getConfig();
  return {
    config,
    status: getStatus(),
    connectorSchemas: Object.fromEntries(
      pluginRefreshPublications().map(({ surface, schemaId }) => [surface, schemaId])
    ),
    connectorRefresh: await pluginRefreshStatuses(),
    confirmedConnectorSchemas: confirmedPluginSchemas(),
    pluginRefreshUnreadable: await pluginRefreshUnreadable(),
    recordingStorageFull: recordingStorageFull(),
    platform: hostPlatformInfo(),
    loginStartupAvailable: supportsLoginStartup(process.platform, app.isPackaged),
    secureStorage: await secureStorageStatus(),
    hasApiKey: await hasSecret(setupApiKeySlot(config.tunnel.profileId)),
    hasGoalKey: await hasSecret('openRouterApiKey'),
    hasCustomProviderKey: await hasSecret('customProviderApiKey'),
    // After the reads above: only a read can find the file unreadable.
    credentialsUnreadable: storedSecretsUnreadable(),
    resolvedBinary: resolvedBinary(config),
    bundledTunnelVersion: bundledVersion(),
    bridge: await bridgeStatus(),
    cosBrowserSignedIn: cosBrowserSignedIn(),
    update: updateStatus(),
    desktopAccess: getMacOSDesktopAccess(),
    settingsRecovered: settingsRecovered()
  };
}

/** Wraps a handler so a thrown error becomes a message the UI can show. */
function handle<T>(channel: string, fn: (payload: unknown) => Promise<T>): void {
  ipcMain.handle(channel, async (_event, payload: unknown) => {
    try {
      return { ok: true as const, data: await fn(payload) };
    } catch (err) {
      const message =
        err instanceof SandboxError || err instanceof z.ZodError
          ? err instanceof z.ZodError
            ? (err.issues[0]?.message ?? 'Invalid input')
            : err.message
          : err instanceof Error
            ? err.message
            : String(err);
      return { ok: false as const, error: message };
    }
  });
}

/** Shows a recorded chat's ChatGPT page: its open tab when there is one, else a new one. */
export async function openSessionChat(id: string): Promise<void> {
  const summary = await getSession(id);
  const conversationId = summary?.conversationId;
  if (!conversationId || !/^[0-9a-z-]{8,64}$/i.test(conversationId)) {
    throw new Error('This session has no valid ChatGPT conversation');
  }
  // The selected browser owns this explicit action. In particular, a connected companion in
  // Chrome/Edge must not override the user's choice to open the chat in the CoS browser.
  if (getConfig().ui.chatBrowser === 'cos') {
    await openInPreferredBrowser(chatUrl(conversationId), { reveal: true });
    return;
  }
  // For an explicitly selected external browser, reveal its existing chat first; otherwise open
  // the conversation in that same preferred browser (never the system default by accident).
  if (!(await revealChatInBrowser(conversationId))) await openInPreferredBrowser(chatUrl(conversationId), { reveal: true });
}

export function registerIpc(getWindow: () => BrowserWindow | null, quitToInstall: () => void): void {
  registerWorkspaceTerminalIpc(getWindow);
  registerDictationIpc(getWindow);
  // A session row remains visible until its delete IPC resolves. Fence Trust while deletion is
  // in flight so a second click cannot recreate permission after the row's durable revoke.
  const deletingSessionIds = new Set<string>();
  let watchedWindow: BrowserWindow | null = null;
  const projectFileWatches = new ProjectFileWatchSet(event => {
    const target = getWindow();
    if (!target || target !== watchedWindow || target.isDestroyed() || target.webContents.isDestroyed()) return;
    target.webContents.send('projectFiles:changed', event);
  });
  const projectGitWatches = new ProjectGitWatchSet(event => {
    const target = getWindow();
    if (!target || target !== watchedWindow || target.isDestroyed() || target.webContents.isDestroyed()) return;
    target.webContents.send('projectGit:changed', event);
  });
  let projectWatchRequest = 0;
  const closeProjectWatches = (): void => {
    projectWatchRequest++;
    projectFileWatches.close();
    projectGitWatches.close();
  };
  handle('setup:profile', async payload => {
    const request = z.discriminatedUnion('action', [
      z.object({ action: z.literal('add'), name: z.string().trim().min(1).max(80) }),
      z.object({ action: z.literal('select'), id: z.string().min(1).max(64) }),
      z.object({ action: z.literal('remove'), id: z.string().min(1).max(64) })
    ]).parse(payload);
    await updateConfig(config => request.action === 'add'
      ? addSetupProfile(config, request.name)
      : request.action === 'remove' ? removeSetupProfile(config, request.id) : switchSetupProfile(config, request.id),
    async () => {
      // The committed profile owns the connection even if credential cleanup fails.
      try { if (request.action === 'remove') await setSecret(setupApiKeySlot(request.id), ''); }
      finally { await applySettings(); }
    });
    return buildState();
  });
  handle('usage:get', () => usageOverview());
  handle('usage:providers', (payload) => readProviderUsage({ fresh: z.object({ fresh: z.boolean() }).parse(payload).fresh }));
  handle('plugin-refresh:reset', async () => {
    await resetPluginRefreshLedger();
    return buildState();
  });
  // The renderer asks the person first. Nothing is set aside when the file can be read after all.
  handle('credentials:start-fresh', async () => {
    const setAside = (await setAsideUnreadableSecrets()) !== null;
    return { state: await buildState(), setAside };
  });
  handle('state:get', async () => {
    const state = await buildState();
    // Native package smoke uses this as the end-to-end renderer readiness barrier. Unlike
    // `did-finish-load`, it can only happen after the renderer's first IPC request has completed
    // secure-storage availability/decryption probes and the rest of the initial state snapshot.
    logInfo('renderer state ready');
    return state;
  });

  handle('settings:save', async (payload) => {
    const request = settingsSave.parse(payload);
    const before = getConfig();
    const next = await updateConfig(async config => {
      if (request.patch.ui.browserBridgePort !== undefined &&
          request.patch.ui.browserBridgePort !== (request.base.ui.browserBridgePort ?? 'auto') &&
          bridgePortSelection().overridden) {
        throw new Error('Browser bridge port is controlled by CLF_BRIDGE_PORTS.');
      }
      const proposed = { ...config, ...mergeSettings(config, request.base, request.patch) };
      // If an earlier Off retirement failed, On must retry it before admission.
      if (!config.ui.finishTool && proposed.ui.finishTool) await cancelFinishInputs(false);
      else if (!config.goal.impulseMinutes && (proposed.goal.impulseMinutes ?? 0) > 0) await cancelFinishInputs(true);
      return proposed;
    }, async (published, previous) => {
      if (previous.ui.finishTool && !published.ui.finishTool) await cancelFinishInputs(false);
      else if ((previous.goal.impulseMinutes ?? 0) > 0 && !published.goal.impulseMinutes) await cancelFinishInputs(true);
    }, publishBridgePortChange);
    // Renderer palette changes are immediate, so keep OS/Electron-owned chrome in lock-step too.
    // Without this, selecting Dark on macOS left the title bar, menus and file picker in the
    // system theme until restart (and startup still defaulted to system before index.ts applies it).
    // A changed Goal provider address may be one the system reaches directly.
    void refreshAppProxy();
    setRecordingStorageLimit(next.sessions.storageLimitGiB ?? DEFAULT_RECORDING_STORAGE_GIB);
    if ((before.ui.keepAwake !== false) !== (next.ui.keepAwake !== false) || (before.ui.keepScreenAwake === true) !== (next.ui.keepScreenAwake === true)) refreshKeepAwake();
    nativeTheme.themeSource = next.ui.theme;
    if (process.platform === 'win32') getWindow()?.setTitleBarOverlay(titleBarOverlayForTheme(next.ui.theme, next.ui.appearance));
    // BrowserWindow's native backing color is fixed at construction unless updated explicitly.
    // Keep it in lock-step too: the default macOS application menu exposes Reload, and after a
    // live theme switch an old opposite background otherwise flashes behind the renderer while it
    // paints again. This is also the color Electron shows during any later renderer reload/failure.
    getWindow()?.setBackgroundColor(windowBackgroundForTheme(next.ui.theme, next.ui.appearance));
    refreshPetOverlayAppearance();
    if (
      before.goal.enabled !== next.goal.enabled ||
      // The mode is authority too: a draft started as a gate must not be typed after the user
      // asked for a loop, and a loop draft must not be typed after they asked for a gate.
      before.goal.mode !== next.goal.mode ||
      before.goal.model !== next.goal.model ||
      before.goal.backend !== next.goal.backend ||
      before.goal.loopBackend !== next.goal.loopBackend ||
      before.goal.helperModel !== next.goal.helperModel || before.goal.helperReasoning !== next.goal.helperReasoning ||
      before.goal.provider.kind !== next.goal.provider.kind ||
      before.goal.provider.baseUrl !== next.goal.provider.baseUrl ||
      before.goal.reasoning !== next.goal.reasoning ||
      before.goal.prompt !== next.goal.prompt ||
      before.goal.objectivePrompt !== next.goal.objectivePrompt ||
      before.goal.loopPrompt !== next.goal.loopPrompt
    ) {
      retireGoalDrafts(before.goal.enabled && !next.goal.enabled);
    }
    // The app-wide switch going off is the master stop, and has to actually stop things. Chats
    // carry their own Goal/Loop answer now, so without this the one control that looks like it
    // governs everything would govern only the chats that never disagreed with it — and a loop
    // somebody wanted stopped would go on running with nowhere obvious to switch it off.
    // Turning it *on* deliberately does not reach into a chat that has said no.
    if (before.goal.enabled && !next.goal.enabled) clearAllGoalSwitches();
    // Explicit settings changes replace discovery's monotonic snapshot. Otherwise
    // disabled permissions/finish/session tools remain published and no schema change
    // reaches automatic plugin refresh. Cosmetic saves must not invalidate discovery.
    if (before.multiAgent.enabled !== next.multiAgent.enabled || before.sessions.record !== next.sessions.record ||
        before.ui.finishTool !== next.ui.finishTool ||
        JSON.stringify(effectiveCapabilities(before)) !== JSON.stringify(effectiveCapabilities(next))) forgetExposedSurface();
    // Order matters, and it used to be wrong. Pausing the run and withdrawing worker browser
    // commands has to happen while the bridge can still cancel those transports; stopping the
    // bridge first left queued worker/revival commands behind for a later restart to deliver.
    let authorityPersistError: Error | null = null;
    if (!next.multiAgent.enabled) {
      // Off pauses execution; it is not the destructive Clear swarm action. Preserve every
      // prime-owned worker history so re-enable/restart can still show and revive exact chats.
      pauseSwarmForDisable();
      cancelWorkerCommands('multi-agent mode was turned off');
      try {
        if (!(await persistAgentAuthorityNow())) {
          throw new Error('Multi-agent teardown has no immediate durable persistence sink.');
        }
      } catch (error) {
        authorityPersistError = error instanceof Error ? error : new Error(String(error));
      }
    }
    // Recording, workers and direct browser tools share the same extension transport.
    // Startup and settings saves use one eligibility rule.
    if (browserExtensionRequired(next)) await startBridge();
    else await stopBridge();
    if (before.ui.chatBrowser !== next.ui.chatBrowser) await syncCosBrowser();
    if (before.capabilities.screen !== next.capabilities.screen || before.capabilities.control !== next.capabilities.control || before.readOnly !== next.readOnly) wakeBrowserWork('browser-control');
    // Permissions and the second tunnel id both decide whether the optional Desktop
    // connector should be published. Without this, enabling desktop access or pasting its
    // tunnel id left the connector unpublished until the user happened to reconnect, with
    // the card still saying "not published" and nothing explaining why.
    await applySettings();
    if (before.ui.autoRefreshPlugins !== next.ui.autoRefreshPlugins) wakeBrowserWork();
    logInfo('settings updated');
    // The config and runtime side effects above still complete so the app does not stay half-on,
    // but the UI must not be told the pause was safely accepted when its retained authority
    // snapshot failed to cross disk. Startup with the feature off restores and canonicalizes
    // that same history instead of deleting it.
    // Login registration is an independent OS preference. Cosmetic saves do not rewrite
    // it, and its failure cannot interrupt permission publication or Goal/worker teardown.
    let loginStartupError: unknown;
    if ((before.ui.startAtLogin === true) !== (next.ui.startAtLogin === true)) {
      try { applyLoginStartup(app, next.ui.startAtLogin === true); }
      catch (error) { loginStartupError = error; }
    }
    // The local control API is independent in the same way: only an actual change starts or
    // stops it, and a listener that cannot bind never undoes the rest of the save.
    let controlApiError: unknown;
    if (before.controlApi.enabled !== next.controlApi.enabled) {
      try { await (next.controlApi.enabled ? startControlApi() : stopControlApi()); }
      catch (error) { controlApiError = error; }
    }
    // Stable connector URLs (#924): turning it on keeps the URLs running now, so nothing has to be
    // re-entered in ChatGPT; turning it off forgets them, and the next start rotates again.
    if ((before.mcp.persistentUrls === true) !== (next.mcp.persistentUrls === true)) {
      if (next.mcp.persistentUrls === true) {
        if (!(await rememberRunningSurfaceTokens())) logWarn('connector URLs: secure storage is unavailable, so they still change at the next start');
        else logInfo('connector URLs: kept across restarts from now on');
      } else {
        await forgetSurfaceTokens();
        logInfo('connector URLs: forgotten; the next start gives each connector a new one');
      }
    }
    // The listener reads this switch on every request, so a flip needs no restart; it is logged.
    if (before.controlApi.allowActions !== next.controlApi.allowActions) {
      logInfo('control API: actions ' + (next.controlApi.allowActions ? 'allowed' : 'refused'));
    }
    if (authorityPersistError) throw authorityPersistError;
    if (loginStartupError) throw loginStartupError;
    if (controlApiError) throw controlApiError;
    return buildState();
  });

  /** Approves one folder by path. The picker dialog and the drop zone both end here. */
  const approveRoot = async (folderPath: string): Promise<AppState> => {
    let addedName = '';
    await updateConfig(async (config) => {
      const real = await validateNewRoot(folderPath, config.roots);
      const name = uniqueRootName(real, config.roots);
      addedName = name;
      return { ...config, roots: [...config.roots, { name, path: real }] };
    });
    logInfo(`approved folder /${addedName}`);
    return buildState();
  };

  handle('roots:add', async () => {
    const window = getWindow();
    if (!window) throw new Error('No window');
    const result = await dialog.showOpenDialog(window, {
      title: 'Approve a folder for ChatGPT',
      properties: ['openDirectory']
    });
    if (result.canceled || !result.filePaths[0]) return buildState();
    return approveRoot(result.filePaths[0]);
  });

  handle('projects:list', () => listProjects());
  handle('ui:language', async payload => {
    // The renderer owns the choice; the main process keeps it for the browser extension.
    const language = z.enum(UI_LANGUAGES).parse(payload);
    if (getConfig().ui.language !== language) await updateConfig(config => ({ ...config, ui: { ...config.ui, language } }));
  });
  // The one-time offer to turn automatic plugin refresh on (installs from before it existed have
  // it saved as off). Either answer is kept, so the offer never comes back.
  handle('pluginRefresh:offer', async (payload) => {
    const { turnOn } = z.object({ turnOn: z.boolean() }).strict().parse(payload);
    await updateConfig(config => ({ ...config, ui: { ...config.ui, autoRefreshPluginsAsked: true, ...(turnOn ? { autoRefreshPlugins: true } : {}) } }));
    if (turnOn) wakeBrowserWork();
    return buildState();
  });
  handle('ui:whatsNewSeen', async () => {
    // Only this version can be recorded; the renderer cannot write another one (#1172).
    if (getConfig().ui.lastSeenVersion !== APP_VERSION) await updateConfig(config => ({ ...config, ui: { ...config.ui, lastSeenVersion: APP_VERSION } }));
  });
  handle('ui:stopNoticeTexts', async payload => {
    // The renderer's catalogs translate the stopped-chat notices (#855); bounded and allowlisted.
    setStopNoticeTranslations(z.record(z.string().max(200), z.string().max(400)).refine(value => Object.keys(value).length <= 16).parse(payload));
  });
  handle('ui:mainTexts', async payload => {
    // The tray menu and Session finish notice in the interface language; bounded and allowlisted.
    setMainTextTranslations(z.record(z.string().max(200), z.string().max(200)).refine(value => Object.keys(value).length <= 32).parse(payload));
  });
  handle('pets:list', async () => petLibraryState());
  handle('pets:overlayState', async () => petOverlayControlState());
  handle('pets:overlayVisible', async payload => {
    const { visible } = z.object({ visible: z.boolean() }).strict().parse(payload);
    return setPetOverlayVisible(visible);
  });
  handle('pets:import', async () => {
    const options: Electron.OpenDialogOptions = { title: 'Import CoS Pet folder', properties: ['openDirectory'] };
    const owner = getWindow();
    const selected = owner && !owner.isDestroyed()
      ? await dialog.showOpenDialog(owner, options)
      : await dialog.showOpenDialog(options);
    if (selected.canceled || !selected.filePaths[0]) return null;
    return importPet(selected.filePaths[0]);
  });
  handle('pets:enabled', async payload => {
    const { id, enabled } = z.object({ id: z.string().min(1).max(100), enabled: z.boolean() }).strict().parse(payload);
    const state = setPetEnabled(id, enabled);
    // Enabling shows the overlay, without restoring other pets dismissed for this run.
    if (enabled) await setPetOverlayVisible(true, false);
    return state;
  });
  handle('pets:favorite', async payload => {
    const { id, favorite } = z.object({ id: z.string().min(1).max(100), favorite: z.boolean() }).strict().parse(payload);
    return setPetFavorite(id, favorite);
  });
  handle('pets:delete', async payload => {
    const { id } = z.object({ id: z.string().min(1).max(100) }).strict().parse(payload);
    return deletePet(id);
  });
  handle('pets:asset', async payload => {
    const { id, preview } = z.object({ id: z.string().min(1).max(100), preview: z.boolean() }).strict().parse(payload);
    return loadPetAsset(id, preview);
  });
  handle('skills:list', () => listSkills());
  handle('skills:managed', () => listManagedSkills());
  handle('skills:recommended', () => listRecommendedSkills());
  handle('skills:installRecommended', async payload => {
    const { id } = z.object({ id: z.string().regex(SKILL_ID_PATTERN) }).strict().parse(payload);
    return installRecommendedSkill(id);
  });
  handle('skills:import', async payload => {
    const { kind } = z.object({ kind: z.enum(['folder', 'file']) }).strict().parse(payload);
    const options: Electron.OpenDialogOptions = kind === 'folder'
      ? { title: 'Import Skill folder', properties: ['openDirectory'] }
      : { title: 'Import SKILL.md', properties: ['openFile'], filters: [{ name: 'Markdown skills', extensions: ['md'] }] };
    const owner = getWindow();
    const selected = owner && !owner.isDestroyed()
      ? await dialog.showOpenDialog(owner, options)
      : await dialog.showOpenDialog(options);
    if (selected.canceled || !selected.filePaths[0]) return null;
    if (kind === 'folder') await importSkillPackage(selected.filePaths[0]);
    else await importSkillFile(selected.filePaths[0]);
    return listManagedSkills();
  });
  handle('skills:githubImport', async payload => {
    const { url } = z.object({ url: z.string().trim().min(1).max(2048) }).strict().parse(payload);
    return importGitHubSkill(url);
  });
  handle('skills:githubLink', async payload => {
    const { id, url } = z.object({ id: z.string().regex(SKILL_ID_PATTERN), url: z.string().trim().min(1).max(2048) }).strict().parse(payload);
    return linkGitHubSkill(id, url);
  });
  handle('skills:githubCheck', async payload => {
    const { id } = z.object({ id: z.string().regex(SKILL_ID_PATTERN) }).strict().parse(payload);
    return checkGitHubSkillUpdates(id);
  });
  handle('skills:githubUpdate', async payload => {
    const { id } = z.object({ id: z.string().regex(SKILL_ID_PATTERN) }).strict().parse(payload);
    return updateGitHubSkill(id, directory => shell.trashItem(directory));
  });
  handle('skills:remove', async payload => {
    const { id } = z.object({ id: z.string().regex(SKILL_ID_PATTERN) }).strict().parse(payload);
    await removeSkill(id, directory => shell.trashItem(directory));
    return listManagedSkills();
  });
  handle('skills:library', async payload => {
    const scope = z.object({ sessionId: z.string().min(1).max(80).nullable().optional(), projectId: z.string().uuid().nullable().optional() }).strict().parse(payload ?? {});
    const folder = () => scope.sessionId ? getSessionProject(scope.sessionId)
      : scope.projectId ? projectWorkspace(scope.projectId) : Promise.resolve(null);
    const before = await folder();
    const library = await listSkillLibrary({ projectPath: before?.real ?? null, refreshCodexPlugins: true });
    if ((await folder())?.real !== before?.real) throw new Error('The project changed while Skills were loading');
    return library;
  });
  handle('projects:remove', async (payload) => {
    const { id } = z.object({ id: z.string().uuid() }).parse(payload);
    const project = await removeProject(id);
    push('session:changed');
    return project;
  });
  handle('projects:add', async () => {
    const window = getWindow();
    if (!window) throw new Error('No window');
    const result = await dialog.showOpenDialog(window, { title: 'Choose a project folder for ChatGPT', properties: ['openDirectory'] });
    if (result.canceled || !result.filePaths[0]) return null;
    const folder = result.filePaths[0];
    try { await resolvePath(getConfig().roots, folder); }
    catch (error) {
      if (!(error instanceof SandboxError)) throw error;
      const state = await approveRoot(folder);
      push('state:changed', state);
    }
    const project = await addProject(folder);
    push('session:changed');
    // Its native ChatGPT Project is created by the browser; tell it there is work.
    if (project.chatgpt?.state === 'requested') wakeBrowserWork();
    return project;
  });
  handle('projects:chatgpt-retry', async payload => {
    const { id } = z.object({ id: z.string().uuid() }).strict().parse(payload);
    const project = await retryProjectCreate(id);
    if (project) wakeBrowserWork();
    push('session:changed');
    return project;
  });
  handle('projects:color', async payload => {
    const { id, color } = z.object({ id: z.string().uuid(), color: z.enum(PROJECT_COLORS).nullable() }).strict().parse(payload);
    const project = await setProjectColor(id, color);
    push('session:changed');
    return project;
  });

  // A folder dropped onto the Folders card. The renderer never sees a system path itself:
  // the preload turns the dropped File into one, and the same validation the dialog goes
  // through decides whether it is a folder this app may approve at all.
  handle('roots:addPath', async (payload) => {
    const { path: folderPath } = z.object({ path: z.string().min(1).max(4096) }).parse(payload);
    return approveRoot(folderPath);
  });

  handle('roots:remove', async (payload) => {
    const { name } = z.object({ name: z.string().min(1).max(32) }).parse(payload);
    await updateConfig((config) => {
      if (!config.roots.some((root) => root.name === name)) throw new Error(`/${name} is not an approved folder`);
      return {
        ...config,
        roots: config.roots.filter((r) => r.name !== name)
      };
    });
    forgetWorkspaceRoot(name);
    projectFileWatches.close();
    logInfo(`removed folder /${name}`);
    return buildState();
  });

  handle('roots:rename', async (payload) => {
    const { name, newName } = renameRoot.parse(payload);
    if (RESERVED_ROOT_NAMES.has(newName)) {
      throw new SandboxError(`/${newName} is reserved by Chat On Steroids and cannot be used as a folder name`);
    }
    await updateConfig((config) => {
      if (!config.roots.some((root) => root.name === name)) throw new Error(`/${name} is not an approved folder`);
      if (config.roots.some((r) => r.name !== name && r.name === newName)) {
        throw new Error(`/${newName} is already used`);
      }
      return {
        ...config,
        roots: config.roots.map((r) => (r.name === name ? { ...r, name: newName } : r))
      };
    });
    renameWorkspaceRoot(name, newName);
    return buildState();
  });

  const projectFileId = z.string().uuid();
  const projectRelativePath = z.string().max(4096);
  handle('projectFiles:list', async payload => {
    const { projectId, directory } = z.object({ projectId: projectFileId, directory: projectRelativePath.default('') }).strict().parse(payload);
    return listProjectDirectory(projectId, directory);
  });
  handle('projectFiles:watch', async payload => {
    const { projectId, directories } = z.object({ projectId: projectFileId.nullable(), directories: z.array(projectRelativePath).max(128) }).strict().parse(payload);
    const target = getWindow();
    if (!target || target.isDestroyed()) { closeProjectWatches(); return false; }
    if (target !== watchedWindow) {
      closeProjectWatches();
      watchedWindow = target;
      target.webContents.once('destroyed', () => {
        if (watchedWindow === target) { watchedWindow = null; closeProjectWatches(); }
      });
      target.webContents.on('did-start-loading', () => {
        if (watchedWindow === target) closeProjectWatches();
      });
    }
    const request = ++projectWatchRequest;
    await projectFileWatches.sync(projectId, projectId ? directories : []);
    if (request !== projectWatchRequest || watchedWindow !== target) return false;
    await projectGitWatches.sync(projectId);
    return request === projectWatchRequest && watchedWindow === target;
  });
  handle('projectGit:snapshot', async payload => {
    const { projectId, baseRef } = z.object({ projectId: projectFileId,
      baseRef: z.string().min(1).max(256).optional() }).strict().parse(payload);
    return readProjectGitSnapshot(projectId, baseRef);
  });
  handle('projectGit:diff', async payload => {
    const { projectId, path, baseRef, expectedRevision } = z.object({ projectId: projectFileId, path: projectRelativePath.min(1),
      baseRef: z.string().min(1).max(256).optional(), expectedRevision: z.string().length(64).regex(/^[0-9a-f]+$/).optional() }).strict().parse(payload);
    return readProjectGitDiff(projectId, path, baseRef, expectedRevision);
  });
  handle('sessions:toolEditReview', async payload => {
    const { sessionId, callId, changeIndex } = z.object({
      sessionId: z.string().min(8).max(64).regex(/^[0-9a-z-]+$/i),
      callId: z.string().uuid(),
      changeIndex: z.number().int().min(0).max(63)
    }).strict().parse(payload);
    return readToolEditReview(sessionId, callId, changeIndex);
  });
  handle('projectFiles:preview', async payload => {
    const { projectId, path } = z.object({ projectId: projectFileId, path: projectRelativePath.min(1) }).strict().parse(payload);
    return previewProjectFile(projectId, path);
  });
  handle('projectFiles:create', async payload => {
    const { projectId, directory, name, kind } = z.object({ projectId: projectFileId, directory: projectRelativePath.default(''),
      name: z.string().min(1).max(255), kind: z.enum(['file', 'directory']) }).strict().parse(payload);
    return createProjectEntry(projectId, directory, name, kind);
  });
  handle('projectFiles:rename', async payload => {
    const { projectId, path, name } = z.object({ projectId: projectFileId, path: projectRelativePath.min(1), name: z.string().min(1).max(255) }).strict().parse(payload);
    return renameProjectEntry(projectId, path, name);
  });
  handle('projectFiles:save', async payload => {
    const { projectId, path, text, expectedModifiedAt, expectedBytes, expectedRevision } = z.object({ projectId: projectFileId, path: projectRelativePath.min(1),
      text: z.string().max(256 * 1024), expectedModifiedAt: z.string().min(1).max(64), expectedBytes: z.number().int().min(0).max(256 * 1024),
      expectedRevision: z.string().regex(/^[a-f0-9]{64}$/) }).strict().parse(payload);
    return saveProjectTextFile(projectId, path, text, expectedModifiedAt, expectedBytes, expectedRevision);
  });
  handle('projectFiles:delete', async payload => {
    const { projectId, path } = z.object({ projectId: projectFileId, path: projectRelativePath.min(1) }).strict().parse(payload);
    const target = await projectFileTarget(projectId, path, { allowRoot: false });
    if (target.kind !== 'file' && target.kind !== 'directory') throw new Error('Only regular files and folders can be deleted');
    await revalidateProjectFileTarget(target);
    await shell.trashItem(target.real);
    return true;
  });
  handle('projectFiles:reveal', async payload => {
    const { projectId, path } = z.object({ projectId: projectFileId, path: projectRelativePath.default('') }).strict().parse(payload);
    const target = await projectFileTarget(projectId, path);
    shell.showItemInFolder(target.real);
    return true;
  });
  handle('projectFiles:attach', async payload => {
    const { projectId, path } = z.object({ projectId: projectFileId, path: projectRelativePath.min(1) }).strict().parse(payload);
    const target = await projectFileTarget(projectId, path, { allowRoot: false, fileOnly: true });
    const retained = new Set((await listInputs()).filter(row => !['sent', 'failed', 'cancelled'].includes(row.state)).flatMap(row => row.attachments?.map(file => file.id) ?? []));
    const checked = await projectFileTarget(projectId, path, { allowRoot: false, fileOnly: true });
    if (checked.real !== target.real) throw new Error('The project file changed location');
    return stageInputAttachment(checked.real, retained);
  });

  /**
   * Stores one of the defined provider keys by name.
   *
   * The name is an enum rather than a string, so the renderer can choose *which* credential
   * it is writing but cannot name a slot nobody defined — and the value still only ever
   * travels inwards. Nothing reads a key back out over IPC; the state carries a boolean.
   */
  handle('secret:set', async (payload) => {
    const { value, key, profileId } = z
      .object({
        value: z.string().max(500),
        profileId: z.string().min(1).max(64).optional(),
        key: z.enum(['openaiApiKey', 'openRouterApiKey', 'customProviderApiKey']).default('openaiApiKey')
      })
      .parse(payload);
    if (!(await isEncryptionAvailable())) {
      throw new Error('Secure OS credential storage is unavailable, so the key cannot be stored safely.');
    }
    const owner = profileId ?? 'default';
    const config = getConfig();
    if (key === 'openaiApiKey' && owner !== (config.tunnel.profileId ?? 'default') &&
        !config.setupProfiles?.some(profile => profile.id === owner)) throw new Error('Setup profile not found');
    await setSecret(key === 'openaiApiKey' ? setupApiKeySlot(owner) : key, value);
    const activeGoalKey = getConfig().goal.provider.kind === 'custom' ? 'customProviderApiKey' : 'openRouterApiKey';
    if (key === activeGoalKey) retireGoalDrafts();
    const what = key === 'openRouterApiKey' ? 'openrouter key' : key === 'customProviderApiKey' ? 'custom provider key' : 'api key';
    logInfo(value.trim() === '' ? `${what} cleared` : `${what} stored`);
    return buildState();
  });

  /**
   * The OpenRouter catalogue, newest first, one page at a time.
   *
   * Fetched here rather than in the renderer for the same reason every other network call
   * is: the key that authorises it never crosses this boundary. The page size is the
   * module's own, so the renderer cannot ask for the whole catalogue in one call.
   */
  handle('goal:models', async (payload) => {
    const { offset, query } = z.object({
      offset: z.number().int().min(0).max(2000).default(0),
      query: z.string().max(160).default('')
    }).parse(payload ?? {});
    return listGoalModels(offset, MODEL_PAGE_SIZE, query);
  });

  handle('binary:pick', async () => {
    const window = getWindow();
    if (!window) throw new Error('No window');
    const result = await dialog.showOpenDialog(window, {
      title: 'Select the tunnel executable',
      properties: ['openFile'],
      ...(process.platform === 'win32' ? { filters: [{ name: 'Programs', extensions: ['exe'] }] } : {})
    });
    if (result.canceled || !result.filePaths[0]) return buildState();
    await updateConfig((config) => ({
      ...config,
      tunnel: { ...config.tunnel, binaryPath: result.filePaths[0]! }
    }));
    // This is a Core transport setting just like changing the method/tunnel id in the form.
    // Apply it immediately when connected rather than saving a path the running child never
    // uses until some unrelated future reconnect.
    await applySettings();
    return buildState();
  });

  handle('connection:connect', async () => {
    await connect();
    return buildState();
  });

  handle('connection:disconnect', async () => {
    await disconnect();
    return buildState();
  });

  handle('diagnostics:run', async () => runDiagnostics());
  // "Save diagnostics report": one plain-text file for a bug report, personal details removed
  // (see diagnostics-report.ts). Revealed after saving so the user reads what they would share.
  handle('diagnostics:saveReport', async () => {
    const selfTest = await Promise.race([
      runDiagnostics().catch(() => null),
      new Promise<null>(resolve => setTimeout(() => resolve(null), 10_000).unref())
    ]);
    const workers = swarmState().agents;
    const text = renderDiagnosticsReport({
      app: systemFacts(app), home: app.getPath('home'),
      bridge: await bridgeStatus(), extension: await companionDiagnostics().catch(() => null),
      selfTest: selfTest && { summary: selfTest.summary, checks: selfTest.checks.map(({ name, status, detail }) => ({ name, status, detail })) },
      commands: pendingCommands().map(({ id, what, lastError }) => ({ command: id, what, lastError })),
      workers: workers.map(({ id, role, state, model, reasoningEffort, createdAt, activatedAt, finishedAt, pending, delivered, conversationId, revivable }) =>
        ({ worker: id, role, state, model, reasoningEffort, createdAt, activatedAt, finishedAt, pending, delivered, conversationId, revivable })),
      sessions: await listSessions().catch(() => []),
      projects: await listProjects().catch(() => []),
      workerTexts: workers.flatMap(worker => [worker.task ?? '', worker.label ?? '', worker.result ?? '']),
      log: await readRecentLog(),
      memory: memoryFacts(getWindow()),
      now: Date.now()
    });
    return saveDiagnosticsReport(text, getWindow());
  });
  handle('desktop:requestAccessibility', async () => {
    await refreshMacOSDesktopAccess({ promptAccessibility: true });
    return buildState();
  });

  handle('log:get', async () => getLog());
  handle('log:text', async () => formatLogForClipboard());
  handle('log:json', async () => formatLogAsJson());
  handle('clipboard:write', async (payload) => {
    const { text } = z.object({ text: z.string().max(1_000_000) }).parse(payload);
    await clipboard.writeText(text);
    return true;
  });

  // Copy or save a completed turn's answer, or the session transcript, as Markdown. Main reads
  // the full text of answers that were cut in the log, so neither comes out truncated.
  handle('sessions:exportMarkdown', async (payload) => {
    const request = z.object({
      id: z.string().min(8).max(64).regex(/^[0-9a-z-]+$/i),
      scope: z.enum(['answer', 'session']),
      turnId: z.string().min(1).max(200).optional(),
      target: z.enum(['clipboard', 'file'])
    }).parse(payload);
    return exportSessionMarkdown(request, getWindow());
  });

  // The Install button. The renderer decides nothing about what is installed - it cannot
  // name a file, a version or a path - it only says "now", and only a staged, digest-checked
  // artifact makes that mean anything. The quit is what applies it, at the end of the same
  // shutdown sequence every other quit runs; refusing here is how a press with nothing staged
  // avoids closing the app for no reason.
  // Update all. A downloaded update restarts only for the exact version the person approved in
  // the app's own dialog; any other call answers `confirm`, so the window can ask first.
  handle('update:all', async payload => updateAll(quitToInstall, url => shell.openExternal(url),
    async version => typeof payload === 'string' && payload === version));
  handle('update:install', async () => {
    if (!markInstallOnQuit()) throw new Error('There is no downloaded update to install yet');
    logInfo('update: install requested; quitting to hand the update over');
    quitToInstall();
    return true;
  });

  // "Get update" for an installation that cannot update itself: the exact published file for
  // this machine and the announced version, opened in the user's browser. The renderer names
  // nothing; the URL is built here from the checked release and this process's platform.
  // Opening Settings: ask GitHub again if the last answer is older than ten minutes. The status
  // reaches the window through the ordinary state push; this returns before the check does.
  handle('update:refresh', async () => {
    void checkForUpdatesIfStale();
    return true;
  });

  handle('update:download', async () => {
    await shell.openExternal(manualDownloadUrl(updateStatus().latest));
    return true;
  });

  handle('link:open', async (payload) => {
    const { url, external } = z.object({ url: z.string().max(8192), external: z.boolean().optional() }).parse(payload);
    if (!ALLOWED_LINKS.has(url) && !safeExternalLink(url)) throw new Error('That link is not allowed');
    // Setup's ChatGPT and OpenAI pages open where the user is already signed in, unless the
    // user asked for their own browser instead.
    if (!external && getConfig().ui.chatBrowser === 'cos' && opensInCosBrowser(url)) await openInPreferredBrowser(url, { reveal: true });
    else await shell.openExternal(url);
    return true;
  });

  // Setup's "Open ChatGPT" for Chrome, Edge or Brave: the chosen browser, where the extension is.
  handle('chatgpt:open', async () => {
    await openInPreferredBrowser('https://chatgpt.com/', { reveal: true });
    return true;
  });

  // Setup's button once ChatGPT is surely signed in: ChatGPT's own sign-out, where it runs. The
  // status follows from that browser's own answer, as it does for any sign-out.
  handle('chatgpt:signOut', async () => {
    await openInPreferredBrowser('https://chatgpt.com/auth/logout', { reveal: true });
    return true;
  });

  // Installation does not change the saved execution browser or load the CoS host.
  handle('browser:setupOpen', async (payload) => {
    const { browser, page } = z.object({ browser: z.enum(['chrome', 'edge', 'brave', 'firefox']), page: z.enum(['extensions', 'chatgpt']) }).strict().parse(payload);
    if (page === 'chatgpt') {
      await openInPreferredBrowser('https://chatgpt.com/', { browser, reveal: true });
      return true;
    }
    // Firefox installs the signed add-on from its release download; it asks before adding it.
    if (browser === 'firefox') {
      await openInPreferredBrowser(firefoxAddonUrl(APP_VERSION), { browser, reveal: true });
      return true;
    }
    // A browser opens its own internal pages only from its address bar: given on the command line,
    // chrome://extensions and edge://extensions both open a new tab instead (measured 2026-10-12).
    // So the address goes on the clipboard and the browser comes up with a new tab to paste it into.
    await clipboard.writeText(`${browser}://extensions`);
    await openInPreferredBrowser('about:blank', { browser, reveal: true });
    return true;
  });

  // Setup's first step: the CoS browser on screen, on ChatGPT's login when signed out.
  handle('cosBrowser:show', async () => {
    if (getConfig().ui.chatBrowser !== 'cos') throw new Error('The CoS browser is not the selected ChatGPT browser');
    await (await loadCosBrowser()).showSignIn();
    return true;
  });

  // ------------------------------------------------------------- sessions

  handle('sessions:list', async (payload) => {
    const { cursor, limit, projectId } = z
      .object({
        cursor: sessionListCursorSchema.optional(),
        // Keep one renderer payload small even when the store can index much more history.
        limit: z.number().int().min(1).max(60).optional(),
        // One project's own pages: expanding a project must not page the whole history (#1190).
        projectId: z.string().regex(/^[a-f0-9-]{36}$/i).optional()
      })
      .parse(payload ?? {});
    return readSessionList({ cursor, limit: limit ?? 60, ...(projectId ? { projectId } : {}) });
  });

  handle('sessions:image', async (payload) => {
    const { id, assetId } = z.object({ id: z.string().min(8).max(64).regex(/^[0-9a-z-]+$/i), assetId: z.string().max(100).regex(/^[a-f0-9]{8,64}\.(?:bin|png|jpg)$/) }).parse(payload);
    return recordedInputImage(id, assetId);
  });
  handle('sessions:imageStorage', async () => getImageStorage());
  handle('sessions:clearImageStorage', async (payload) => {
    const { mode } = z.object({ mode: z.enum(['oldest-gib', 'all']) }).parse(payload);
    const result = await clearImageStorage(mode);
    // Retired images can belong to any transcript; this is the explicit global invalidation.
    push('session:changed', { allTranscripts: true } satisfies SessionChange);
    return result;
  });
  handle('sessions:events', async (payload) => {
    const { id, ...options } = z
      .object({
        id: z.string().min(8).max(64).regex(/^[0-9a-z-]+$/i),
        from: z.number().int().min(0).max(10_000_000).optional(),
        before: z.number().int().min(1).max(10_000_000).optional(),
        after: z.number().int().min(0).max(10_000_000).optional(),
        limit: z.number().int().min(1).max(1000).optional()
      })
      .parse(payload);
    const page = await readSessionEvents(id, options);
    if (!page) throw new Error('Session not found');
    return page;
  });

  const stageFiles = async (sources: AttachmentSource[]) => {
    const retained = new Set((await listInputs()).filter(row => !['sent', 'failed', 'cancelled'].includes(row.state)).flatMap(row => row.attachments?.map(file => file.id) ?? []));
    return stageInputAttachments(sources, retained);
  };
  handle('sessions:files', async () => {
    const chosen = await dialog.showOpenDialog({ title: 'Attach files', properties: ['openFile', 'multiSelections'] });
    if (chosen.canceled) return [];
    if (chosen.filePaths.length > 20) throw new Error('Attach up to 20 files per message');
    return stageFiles(chosen.filePaths);
  });
  handle('sessions:dropFiles', async payload => {
    const { files } = z.object({ files: z.array(z.union([
      z.string().min(1).max(32768),
      z.object({ name: z.string().min(1).max(255), bytes: z.instanceof(Uint8Array).refine(bytes => bytes.byteLength > 0 && bytes.byteLength <= 12 * 1024 * 1024) }).strict()
    ])).min(1).max(20) }).strict().parse(payload);
    return stageFiles(files);
  });
  handle('sessions:attachText', async payload => {
    const { text } = z.object({ text: z.string().min(1).max(4 * 1024 * 1024) }).parse(payload);
    return (await stageFiles([{ text }]))[0]!;
  });
  handle('sessions:stopTurn', async payload => {
    const { id, expectedTurnId } = sessionIdArg.extend({ expectedTurnId: z.string().min(1).max(256) }).parse(payload);
    return stopSessionTurn(id, expectedTurnId);
  });
  handle('sessions:releaseFinish', async (payload) => {
    const { id, expectedTurnId } = sessionIdArg.extend({ expectedTurnId: z.string().min(1).max(256) }).parse(payload);
    await sessionControlsFor(id);
    await releaseSessionFinish(id, expectedTurnId);
    return sessionControlsFor(id);
  });
  handle('sessions:generateFinishGoal', async payload => {
    const { id, expectedTurnId } = sessionIdArg.extend({ expectedTurnId: z.string().min(1).max(256) }).parse(payload);
    return requestSessionFinishGoal(id, expectedTurnId);
  });
  handle('chatModels:get', async () => getChatModels());
  handle('browser:preferences', async (payload) => requestBrowserPreferences(payload));
  handle('chatModels:request', async () => startChatModelDiscovery());
  handle('sessions:controls', async (payload) => sessionControlsFor(sessionIdArg.parse(payload).id));
  // #1032: the user keeps this answer from being reloaded; false once the browser claimed it.
  handle('sessions:cancelRecovery', async (payload) => cancelAssistantRecovery(sessionIdArg.parse(payload).id));
  handle('sessions:automation', async (payload) => {
    const { id, automation, afterTurn } = sessionIdArg.extend({ automation: z.enum(['off', 'goal', 'loop']), afterTurn: z.boolean().optional() }).parse(payload);
    return setSessionAutomation(id, automation, afterTurn);
  });
  handle('sessions:objective', async (payload) => {
    const { id, text, mode } = sessionIdArg.extend({ text: z.string().max(16000), mode: z.enum(['goal', 'loop']) }).parse(payload);
    return setSessionObjective(id, text, mode);
  });
  handle('sessions:compact', async (payload) => compactSession(sessionIdArg.parse(payload).id));
  handle('sessions:resumeFromHandoff', async (payload) => {
    const input = sessionIdArg.extend({ handoffId: z.string().min(8).max(64).regex(/^[0-9a-z-]+$/i) }).strict().parse(payload);
    return resumeFromSavedSummary(input.id, input.handoffId);
  });
  handle('sessions:cancelCompaction', async (payload) => cancelSessionCompaction(sessionIdArg.parse(payload).id));
  handle('sessions:plan', async (payload) => {
    const { text, backend, requestId } = z.object({ text: z.string().trim().min(1).max(16000), backend: z.enum(['api', 'chatgpt']), requestId: z.string().uuid().optional() }).parse(payload);
    const publish = (progress: import('../shared/task-progress.js').TaskProgressUpdate) => {
      const target = getWindow();
      if (requestId && target && !target.isDestroyed()) target.webContents.send('task:progress', { requestId, ...progress });
    };
    return runTaskRequest(requestId ?? randomUUID(), JSON.stringify(['plan', text, backend]), signal => draftTaskPlan(text, backend, publish, signal), publish);
  });
  handle('sessions:send', async (payload) => {
    const input = inputArgs.parse(payload);
    await validateInputImages(input.images ?? []);
    return sendDesktopInput(input);
  });
  handle('sessions:outbox', async () => (await listInputs()).filter((row) => row.purpose !== 'decision'));
  handle('sessions:reorderInputs', async (payload) => {
    const { sessionId, ids } = z.object({ sessionId: z.string().min(8).max(64), ids: z.array(z.string().uuid()).min(1).max(10000) }).parse(payload);
    return reorderQueuedInputs(sessionId, ids);
  });
  handle('sessions:retryBrowser', async (payload) => retryQueuedInputBrowser(z.object({ id: z.string().uuid() }).parse(payload).id));
  handle('sessions:pausedHelpers', async () => pausedBrowserHelpers());
  // What a working chat's tool calls are doing right now, for its live caption.
  handle('sessions:runningTools', async (payload) => {
    const { conversationIds } = z.object({ conversationIds: z.array(z.string().min(1).max(200)).max(16) }).parse(payload);
    return runningToolActivity(conversationIds);
  });
  handle('sessions:runningProcesses', async (payload) => {
    const { sessionId } = z.object({
      sessionId: z.string().min(8).max(64).regex(/^[0-9a-z-]+$/i)
    }).parse(payload);
    return runningExecProcesses(sessionId);
  });
  handle('sessions:stopProcess', async (payload) => {
    const { sessionId, processId, incarnation } = z.object({
      sessionId: z.string().min(8).max(64).regex(/^[0-9a-z-]+$/i),
      processId: z.number().int().min(1_000).max(99_999),
      incarnation: z.number().int().positive().max(Number.MAX_SAFE_INTEGER)
    }).parse(payload);
    return stopExecProcess(sessionId, processId, incarnation);
  });
  // The window armed its Keychain notice; the first Keychain read may start.
  handle('keychain:noticeReady', async () => keychainNoticeReady());
  // The round outlines (shared/turn-trace.ts) of the turns a timeline shows.
  handle('sessions:traces', async (payload) => {
    const { id, turnIds } = z.object({
      id: z.string().min(8).max(64).regex(/^[0-9a-z-]+$/i),
      turnIds: z.array(z.string().min(1).max(100)).max(64)
    }).parse(payload);
    return readTurnTraces(id, turnIds);
  });
  handle('sessions:retryHelper', async (payload) => {
    const { id, sourceSessionId } = z.object({ id: z.string().uuid(), sourceSessionId: z.string().min(8).max(64) }).parse(payload);
    return retryGoalBrowserHelper(sourceSessionId, id);
  });
  handle('sessions:sendQueuedNow', async (payload) => {
    const { id } = z.object({ id: z.string().uuid() }).strict().parse(payload);
    const sent = await sendQueuedInputNow(id);
    if (sent) wakeBrowserWork();
    return sent;
  });
  handle('sessions:editInput', async (payload) => { const { id, text, afterTurn } = z.object({ id: z.string().uuid(), text: inputArgs.shape.text, afterTurn: z.boolean().optional() }).parse(payload); return editQueuedInput(id, text, afterTurn); });
  handle('sessions:cancelInput', async (payload) => cancelDesktopInput(z.object({ id: z.string().uuid() }).parse(payload).id));
  handle('sessions:inputAutomation', async payload => {
    const { id, mode, loopAfterTurn } = z.object({ id: z.string().uuid(), mode: z.enum(['off', 'goal', 'loop']), loopAfterTurn: z.boolean().optional() }).parse(payload);
    return setInputAutomation(id, mode, loopAfterTurn);
  });
  handle('window:getZoom', async () => (getWindow()?.webContents.getZoomFactor() ?? UI_BASE_ZOOM) / UI_BASE_ZOOM);
  handle('window:zoom', async (payload) => {
    const { factor } = z.object({ factor: z.number().min(0.75).max(1.5) }).parse(payload);
    getWindow()?.webContents.setZoomFactor(factor * UI_BASE_ZOOM);
    return factor;
  });

  handle('sessions:openChat', async (payload) => {
    const { id } = sessionIdArg.parse(payload);
    await openSessionChat(id);
    return true;
  });

  // ChatGPT's tool approval card, answered in the app (approval-wait.ts). Only a person's click
  // in the renderer reaches `answerApproval`; the page presses the button for that exact card.
  handle('sessions:approvalCard', async (payload) => {
    const { id } = sessionIdArg.parse(payload);
    const conversationId = (await getSession(id))?.conversationId;
    return conversationId ? approvalCardView(conversationId) : null;
  });
  handle('sessions:answerApproval', async (payload) => {
    const { id, cardId, choice } = sessionIdArg.extend({ cardId: z.string().min(8).max(64), choice: z.enum(['allow', 'deny']) })
      .strict().parse(payload);
    const conversationId = (await getSession(id))?.conversationId;
    if (!conversationId) return { ok: false as const, error: 'no_card' as const };
    const answer = requestApprovalAnswer(conversationId, cardId, choice);
    if (answer.ok) {
      logInfo(`approval card: the user chose ${choice} in the app for ${conversationId}`);
      return { ok: true as const };
    }
    return answer;
  });

  // Selecting a chat in the app selects its tab in the Background chats window (#1249). Only
  // the newest selection counts: a slower lookup for an earlier click must not win (#1267).
  let followSelection = 0;
  handle('sessions:followTab', async (payload) => {
    const { id } = sessionIdArg.parse(payload);
    const selection = ++followSelection;
    const conversationId = (await getSession(id))?.conversationId;
    if (selection !== followSelection) return true;
    if (conversationId && /^[0-9a-z-]{8,64}$/i.test(conversationId)) followChatInBackground(conversationId);
    return true;
  });

  /**
   * Blocks or releases the ChatGPT conversation this session is attached to.
   *
   * The renderer names a session, never a conversation, for the same reason `sessions:openChat`
   * does: the stored conversation id is re-read and validated here, so a renderer-supplied id
   * can neither invent a conversation nor block one it is not looking at. A session with no
   * conversation has no rogue turn to stop and is refused rather than silently ignored.
   */
  handle('sessions:block', async (payload) => {
    const { id, blocked } = z
      .object({ id: z.string().min(8).max(64).regex(/^[0-9a-z-]+$/i), blocked: z.boolean() })
      .parse(payload);
    if (deletingSessionIds.has(id)) {
      throw new Error('This session is being deleted; its block cannot be changed');
    }
    const conversationId = await withSessionMutationFence(id, async (summary) => {
      if (deletingSessionIds.has(id)) {
        throw new Error('This session is being deleted; its block cannot be changed');
      }
      const currentConversationId = summary.conversationId;
      if (!currentConversationId || !/^[0-9a-z-]{8,64}$/i.test(currentConversationId)) {
        throw new Error('This session has no valid ChatGPT conversation');
      }
      setChatsBlocked(
        blocked
          ? [currentConversationId]
          : [currentConversationId, ...committedResumeAncestorsFromSummary(summary, currentConversationId)],
        blocked
      );
      return currentConversationId;
    });
    logInfo(
      blocked
        ? `conversation ${conversationId} blocked; its tool calls are refused until it is released`
        : `conversation ${conversationId} released; its tool calls run again`
    );
    // A blocked worker chat frees its swarm slot now, not on the next 30-second pass: the
    // user pressing Block on a worker is usually about to start something in its place.
    if (blocked) await sweepStaleSwarm().catch(() => undefined);
    refreshPetOverlayActivities();
    return blockedChatIds();
  });

  handle('sessions:trust', async (payload) => {
    const { id, expectedConversationId, trusted } = z
      .object({
        id: z.string().min(8).max(64).regex(/^[0-9a-z-]+$/i),
        expectedConversationId: z.string().min(8).max(64).regex(/^[0-9a-z-]+$/i),
        trusted: z.boolean()
      })
      .parse(payload);
    if (deletingSessionIds.has(id)) {
      throw new Error('This session is being deleted; its trust cannot be changed');
    }
    const conversationId = await withSessionMutationFence(id, async (summary) => {
      // Delete may have started while this operation was waiting behind an earlier session write.
      // If Trust entered this queue first it linearizes before Delete; otherwise the tombstone wins.
      if (deletingSessionIds.has(id)) {
        throw new Error('This session is being deleted; its trust cannot be changed');
      }
      const currentConversationId = summary.conversationId;
      if (!currentConversationId || !/^[0-9a-z-]{8,64}$/i.test(currentConversationId)) {
        throw new Error('This session has no valid ChatGPT conversation');
      }
      if (currentConversationId !== expectedConversationId) {
        throw new Error('This session moved to another ChatGPT conversation; refresh the chat list before changing trust');
      }
      const workerOwner = workerPrimeOwner(currentConversationId);
      if (trusted && (workerOwner.owned || summary.origin?.kind === 'worker')) {
        throw new Error('Worker chats cannot be trusted directly; trust the owning prime chat instead');
      }
      // The current resumed row is the only UI handle left after A -> B. Its Untrust action must
      // remove every explicit Trust entry that can still grant B through committed provenance;
      // deleting only B would immediately fall through to a still-trusted A. Worker Untrust is
      // deliberately exact-only so stale pre-fix worker entries can be cleaned without touching
      // the owning prime.
      const trustTargets = !trusted && !workerOwner.owned
        ? [currentConversationId, ...committedResumeAncestorsFromSummary(summary, currentConversationId)]
        : [currentConversationId];
      await setChatsTrusted(trustTargets, trusted);
      return currentConversationId;
    });
    logInfo(trusted
      ? `conversation ${conversationId} trusted for strict chat allowlisting`
      : `conversation ${conversationId} removed from strict chat allowlisting`);
    return trustedChatIds();
  });

  // Search chats by title and by what was said in them (#1107).
  handle('sessions:search', async (payload) => {
    const { query } = z.object({ query: z.string().max(200) }).parse(payload);
    return searchSessions(query);
  });
  // Where a text match is in its chat, so opening the result shows that message.
  handle('sessions:find', async (payload) => {
    const { id, query } = z.object({ id: z.string().min(8).max(64).regex(/^[0-9a-z-]+$/i), query: z.string().max(200) }).strict().parse(payload);
    return findInSession(id, query);
  });
  handle('sessions:locate-match', async (payload) => {
    const { id, query } = sessionIdArg.extend({ query: z.string().max(200) }).parse(payload);
    return locateSearchMatch(id, query);
  });
  handle('sessions:rename', async (payload) => {
    const { id, title } = sessionNameArg.parse(payload);
    if (!await getSession(id)) throw new Error('Session not found');
    const name = cleanSessionName(title);
    if (name) await renameSession(id, name, 'manual');
    else await clearSessionName(id);
    notifyChanged(id);
    return true;
  });
  handle('sessions:delete', async (payload) => {
    const { id } = sessionIdArg.parse(payload);
    if (deletingSessionIds.has(id)) throw new Error('This session is already being deleted');
    deletingSessionIds.add(id);
    try {
      const summary = await getSession(id);
      // Trust is permission. Revoke it durably before any other deletion side effect; otherwise
      // a failed disk commit could leave this chat both trusted and newly unblocked, with its row
      // already gone and no user control left to repair that authority.
      if (summary?.conversationId) {
        await setChatsTrusted([
          summary.conversationId,
          ...committedResumeAncestorsFromSummary(summary, summary.conversationId)
        ], false);
      }
      // Detach first. The recorder maps live ChatGPT conversations to session ids, so
      // deleting the folder underneath a live one left it appending to a session that no
      // longer existed — the events went to a resurrected half-session with no summary.
      // Forgetting the mapping makes the next observation open a fresh session instead.
      const detached = forgetSession(id);
      // Release first. The current resumed row is also the only UI handle for a Block on one of
      // its committed predecessors, so deleting the row must clear that whole policy lineage.
      // Otherwise a hidden source block survives with no remaining row that can release it.
      if (summary?.conversationId) {
        setChatsBlocked([
          summary.conversationId,
          ...committedResumeAncestorsFromSummary(summary, summary.conversationId)
        ], false);
      }
      await deleteSession(id);
      logInfo(
        detached.length > 0
          ? `session ${id} deleted; ${detached.length} live conversation(s) will start a new session`
          : `session ${id} deleted`
      );
      return true;
    } finally {
      deletingSessionIds.delete(id);
    }
  });

  handle('handoff:get', async (payload) => {
    const { id, handoffId } = z
      .object({
        id: z.string().min(8).max(64).regex(/^[0-9a-z-]+$/i),
        handoffId: z.string().min(8).max(64).regex(/^[0-9a-z-]+$/i).optional()
      })
      .parse(payload);
    if (handoffId) return readHandoff(id, handoffId);
    const summary = await getSession(id);
    return summary?.lastHandoffId ? readHandoff(id, summary.lastHandoffId) : null;
  });

  // ---------------------------------------------------------------- bridge

  handle('bridge:unpair', async () => {
    await unpair();
    return buildState();
  });

  handle('bridge:diagnostics', async () => companionDiagnostics());

  handle('bridge:downloadExtension', async () => {
    // This is a recovery path for the extension bundled with *this installed app*. Never use
    // releases/latest here: an old app must not fetch a newer extension with a newer protocol.
    await shell.openExternal(extensionDownloadUrl(app.getVersion()));
    return true;
  });

  /**
   * Opens the folder Chrome should load the extension from.
   *
   * The renderer never learns the path unless it asks for it here, and all it can do
   * with the answer is show it; the open itself happens in the main process against a
   * path the renderer did not choose.
   */
  handle('bridge:openExtensionFolder', async () => {
    const dir = extensionDir();
    if (!dir) {
      throw new Error(
        'The extension folder is missing from this installation. Reinstall the app, or use the extension/ folder from the source checkout.'
      );
    }
    const error = await shell.openPath(dir);
    if (error) throw new Error(`Could not open the extension folder: ${error}`);
    return dir;
  });

  handle('bridge:extensionPath', async () => extensionDir());

  // ----------------------------------------------------------------- swarm

  handle('swarm:get', async () => swarmState());
  handle('swarm:reset', async () => {
    resetSwarm();
    if (!(await persistAgentAuthorityNow())) {
      throw new Error('The cleared run could not be made durable. Retry clearing the swarm.');
    }
    return swarmState();
  });
  /**
   * Clearing one row in the app: the prime ends the run, a worker frees its own slot.
   *
   * The queued bootstrap is withdrawn here rather than from inside the broker. The broker
   * deliberately knows nothing about HTTP or tabs, and `drop()` reaches `failAgent` from
   * inside a delivery — cancelling from there would re-enter it. An IPC call never is.
   * `tidyCommands()` would retire the command on its own at the next poll; doing it now is
   * what stops a tab opening for a slot the user has just cleared.
   */
  handle('swarm:clearAgent', async (payload) => {
    const { id, runId } = z.object({ id: agentIdArg, runId: z.string().min(1).max(200).optional() }).parse(typeof payload === 'string' ? { id: payload } : payload);
    const outcome = clearAgent(id, runId);
    if (outcome.cleared !== 'none') {
      if (!(await persistAgentAuthorityNow())) {
        throw new Error('The agent clear could not be made durable. Retry the clear action.');
      }
      if (outcome.cleared === 'worker') cancelWorkerCommands(outcome.reason, id, runId);
    }
    // The prime's report stays in the main process: the renderer needs the outcome, not
    // the message queued for the prime agent.
    return { cleared: outcome.cleared, reason: outcome.reason, swarm: swarmState() };
  });

  // Retiring a worker must never silently erase its branch, ignored files or uncommitted
  // work. The UI offers a review after finished/failed/cleared (including after restart).
  // Lookup is *on demand*: startup only restores worktrees for still-broker-owned workers.
  const worktreeCleanupId = z.object({
    runId: z.string().uuid(),
    agentId: z.string().regex(/^worker-[1-9][0-9]{0,5}$/)
  }).strict();
  handle('swarm:worktreeCleanupList', async (): Promise<WorkerWorktreeCleanupOffer[]> => {
    try {
      if (!(await persistAgentAuthorityNow())) throw new Error('worker authority could not be persisted');
      const candidates = await listOfferedWorkerWorktrees(getConfig().roots, managedWorktreeCleanupOffers());
      return candidates.map(candidate => ({
        runId: candidate.runId,
        agentId: candidate.agentId,
        reason: candidate.reason,
        label: managedWorktreeCleanupOffers().find(offer =>
          offer.runId === candidate.runId && offer.agentId === candidate.agentId)?.label,
        workspace: candidate.workspace,
        dirty: candidate.dirty,
        ignoredFiles: candidate.ignoredFiles,
        uniqueCommits: candidate.uniqueCommits,
        changeCount: candidate.changes.length
      }));
    } catch (error) {
      // Native paths from Git failures belong to local logs, never the browser/AI surface.
      logInfo(`worktree cleanup inspection failed: ${error instanceof Error ? error.message : String(error)}`);
      throw new Error('Could not review retained worker worktrees. Check the local app logs.');
    }
  });
  handle('swarm:worktreeCleanupRemove', async (payload) => {
    const { runId, agentId } = worktreeCleanupId.parse(payload);
    if (!(await persistAgentAuthorityNow())) throw new Error('Cleanup could not confirm durable worker retirement. No files were removed.');
    const offer = managedWorktreeCleanupOffers().find(entry => entry.runId === runId && entry.agentId === agentId);
    if (!offer) throw new Error('This worker cleanup offer is no longer available. Refresh the list.');
    let candidate: Awaited<ReturnType<typeof listOfferedWorkerWorktrees>>[number] | undefined;
    try {
      candidate = (await listOfferedWorkerWorktrees(getConfig().roots, [offer]))[0];
    } catch (error) {
      logInfo(`worktree cleanup preview failed: ${error instanceof Error ? error.message : String(error)}`);
      throw new Error('Could not verify this worker checkout. No files were removed.');
    }
    if (!candidate) throw new Error('This checkout is missing or has no verified cleanup owner. No files were removed.');
    // The native confirmation must describe a complete, byte-verified snapshot.
    // A bounded/truncated inspection cannot authorize discarding files.
    if (candidate.changesTruncated || !candidate.contentFingerprint) {
      throw new Error('Could not safely inspect all contents of this worker checkout. No files were removed.');
    }
    // The preview is shown only in the trusted desktop confirmation, not the renderer
    // or a model-facing tool. List bounded relative paths instead of native paths.
    const changedFiles = candidate.changes.slice(0, 25).map(name =>
      `  - ${name.replace(/[\x00-\x1f\x7f]/g, '?').slice(0, 180)}`);
    const details = [
      `Checkout: ${candidate.workspace}`,
      candidate.changes.length
        ? `${candidate.changes.length} uncommitted/ignored paths would be discarded:`
        : 'No uncommitted or ignored paths were detected.',
      ...changedFiles,
      candidate.changes.length > changedFiles.length || candidate.changesTruncated
        ? 'Additional paths are not shown; review the checkout before confirming.' : '',
      candidate.ignoredFiles ? 'Ignored files are included in the removal.' : '',
      candidate.uniqueCommits ? 'Commits made only on this branch will remain in Git.' : '',
      'This action removes the entire checkout directory, including tracked working files, ignored files and uncommitted changes. The Git branch and its commits are kept. Uncommitted files cannot be recovered from Git.'
    ].filter(Boolean).join('\n');
    // Approval is acquired in the trusted main process, not supplied as a boolean by renderer
    // or model. Default is cancellation, even for an apparently clean checkout.
    const { response } = await dialog.showMessageBox({
      type: 'warning',
      title: 'Remove worker Git checkout?',
      message: 'Review the worker checkout before removing it',
      detail: details,
      buttons: ['Keep checkout', 'Remove checkout; preserve Git branch'],
      defaultId: 0,
      cancelId: 0,
      noLink: true
    });
    if (response !== 1) return { removed: false, branchPreserved: true };
    // Git's name/size status can stay identical across same-size byte edits.
    // Compare the complete content fingerprint, including ignored/untracked files.
    // The manager also checks this fingerprint inside its mutation fence.
    let fresh: typeof candidate | undefined;
    try {
      fresh = (await listOfferedWorkerWorktrees(getConfig().roots, [offer]))[0];
    } catch (error) {
      logInfo(`worktree cleanup reinspection failed: ${error instanceof Error ? error.message : String(error)}`);
      throw new Error('Could not recheck this checkout after confirmation. No files were removed.');
    }
    if (!fresh || fresh.workspace !== candidate.workspace || fresh.branch !== candidate.branch ||
        fresh.headOid !== candidate.headOid || fresh.dirty !== candidate.dirty ||
        fresh.ignoredFiles !== candidate.ignoredFiles || fresh.uniqueCommits !== candidate.uniqueCommits ||
        fresh.changesTruncated || !fresh.contentFingerprint ||
        fresh.contentFingerprint !== candidate.contentFingerprint ||
        JSON.stringify(fresh.changes) !== JSON.stringify(candidate.changes)) {
      throw new Error('The checkout changed while you were reviewing it. No files were removed.');
    }
    // Root approval and exact broker-offer identity are checked again after user interaction.
    if (!(await persistAgentAuthorityNow())) throw new Error('Cleanup could not reconfirm durable worker retirement. No files were removed.');
    const current = managedWorktreeCleanupOffers().find(entry => entry.runId === runId && entry.agentId === agentId);
    if (!current || current.createdAt !== offer.createdAt || current.reason !== offer.reason) {
      throw new Error('Cleanup ownership changed during confirmation. No files were removed.');
    }
    // A cleared worker's child processes do not stop merely because its broker row was
    // retired. Refuse destructive removal while any tool may still be writing files.
    if (inFlightToolCalls() > 0) {
      throw new Error('Local tools are still executing. No worker files were removed.');
    }
    try {
      const result = await disposeOfferedWorkerWorktree(getConfig().roots, current,
        unifiedExecManager.listProcesses().map(process => process.cwd), candidate.contentFingerprint);
      if (result.removed && acknowledgeManagedWorktreeCleanupOffer(runId, agentId)) {
        // The files are already removed at this point. Failure to persist the acknowledgment
        // is a recoverable stale UI offer, not permission to claim that deletion failed.
        try {
          if (!(await persistAgentAuthorityNow())) logInfo('worktree cleanup acknowledgment could not be persisted');
        } catch (error) {
          logInfo(`worktree cleanup acknowledgment persistence failed: ${error instanceof Error ? error.message : String(error)}`);
        }
      }
      return { removed: result.removed, branchPreserved: !result.branchRemoved };
    } catch (error) {
      logInfo(`worktree cleanup removal refused: ${error instanceof Error ? error.message : String(error)}`);
      if (error instanceof WorkerWorktreeError && error.code === 'WORKTREE_CONTENT_CHANGED') {
        throw new Error('The checkout changed while you were reviewing it. No files were removed.');
      }
      throw new Error('The checkout was not removed safely. Inspect the local app logs for details.');
    }
  });


  // Push updates so the UI reflects tunnel progress without polling. buildState() crosses
  // async secret/bridge reads, so an older snapshot can otherwise resolve after a newer one and
  // repaint stale config/status. Latest-request-wins makes the push stream monotonic.
  /**
   * Sends to the renderer, if there still is one.
   *
   * A null window was always handled; a *destroyed* one was not. Electron keeps the object
   * alive after the window is gone, so `getWindow()` stays truthy and merely reading
   * `.webContents` off it throws. That is not just a missed repaint: `onLog` runs inside
   * `log()`, synchronously, on the caller's own stack — so once the window was destroyed,
   * every log line written during teardown threw into whatever was writing it. The MCP drain's
   * force-close timer died on its own `logWarn` before it could force anything, and the app
   * sat draining a half-closed tunnel socket forever, with no window, no tray, and the
   * single-instance lock still held.
   */
  const push = (channel: string, ...args: unknown[]): void => {
    const target = getWindow();
    if (!target || target.isDestroyed()) return;
    target.webContents.send(channel, ...args);
  };
  configureInputDelivery({
    recoveryAllowed: recoveryInputAllowed,
    callsHoldRecovery: recoveryHeldByCalls,
    activity: sessionInputActivity,
    wakeDecision: async (entry, signal) => {
      signal.throwIfAborted();
      if (!await startBridge()) throw new Error('The browser bridge could not start');
      signal.throwIfAborted();
      const marker = `cos-input=${encodeURIComponent(entry.id)}`;
      await wakeBrowserUrl(entry.conversationId ? `https://chatgpt.com/c/${encodeURIComponent(entry.conversationId)}`
        : `https://chatgpt.com/?${entry.lifetime === 'temporary-planner' ? 'temporary-chat=true&' : ''}${marker}#${marker}`);
    },
    bindHelper: async (conversationId, fromSessionId) => {
      const source = fromSessionId ? await getSession(fromSessionId) : null;
      if (source?.conversationId === conversationId || source?.chatIds.includes(conversationId)) return;
      await noteChatOrigin(conversationId, { kind: 'helper', fromSessionId, agentId: null, task: '' });
    },
    trustOpening: async (sessionId, conversationId) => {
      // Composer openings use the same deletion/rebind fence as an explicit Trust click. The
      // second tombstone check and synchronous queue admission ensure Delete either wins before
      // this grant or durably revokes it afterwards; no orphan permission can survive the row.
      if (deletingSessionIds.has(sessionId)) return false;
      return withSessionMutationFence(sessionId, async (summary) => {
        if (deletingSessionIds.has(sessionId) || summary.conversationId !== conversationId || summary.origin?.kind === 'worker') return false;
        await setChatsTrusted([conversationId], true);
        return true;
      });
    },
    changed: () => push('session:changed'),
    recordDelivered: (entry, anchorCommitted) => getConfig().sessions.record ? recordDeliveredInput(entry, anchorCommitted) : Promise.resolve(true),
    prepareText: async (entry, limits, authored) => {
      const control = entry.conversationId ? goalSwitchFor(entry.conversationId) : getConfig().goal;
      const mode = entry.automation ?? (control.enabled ? control.mode : 'off');
      const text = mode === 'goal' && goalBackendFor('goal') === 'templates' && !entry.text.includes(GOAL_MARKER_INSTRUCTION)
        ? entry.text + GOAL_MARKER_INSTRUCTION : entry.text;
      // Only the opening user input owns executor setup. Existing chats, queued
      // checkpoints and automatic continuations already have their instructions.
      return (entry.opening || !entry.sessionId) && !entry.conversationId && !entry.finishOwner && entry.mode !== 'finish'
        ? prepareSessionPrompt(text, entry, limits, authored)
        : !entry.finishOwner && entry.purpose !== 'decision' ? prepareSkillFollowup(text, authored, limits, entry) : text;
    },
    applyAutomation: async (conversationId, automation, phase, objective, loopAfterTurn) => {
      // This message supersedes the old final; never pick that old final up merely
      // because the composer enabled Goal for the next turn.
      const mode = automation === 'off' ? goalSwitchFor(conversationId).mode : automation;
      // Reserve switch ordering immediately, before awaiting another ledger write.
      // A user Off arriving during persistence must remain later than this attempt.
      const switchWrite = setGoalSwitchNow(conversationId, mode, automation !== 'off', loopAfterTurn);
      const [held] = await Promise.all([switchWrite, setGoalReplyActiveNow(conversationId, false)]);
      // A fresh chat can finish before its send ACK arrives. Its newest final is
      // this message's own response, so it may be picked up after binding.
      // Objective ownership transfers with delivery even if the user switched Off
      // before the fresh chat acquired its identity. The saved Off row remains the
      // execution authority; retaining authored text must never imply reactivation.
      if (objective !== undefined) await setGoalObjectiveNow(conversationId, objective);
      const live = goalSwitchFor(conversationId);
      if (phase === 'after-send' && held.enabled && live.enabled && live.mode === held.mode) await setGoalReplyActiveNow(conversationId, true);
    }
  });

  let statePushGeneration = 0;
  const pushState = (): void => {
    const generation = ++statePushGeneration;
    void buildState().then((state) => {
      if (generation !== statePushGeneration) return;
      push('state:changed', state);
    });
  };
  onStatusChange(pushState);
  onRecordingStorageFullChange(pushState);
  onBridgeChange(pushState);
  onCosBrowserSignInChange(pushState);
  onConnectorProofChange(pushState);
  onPluginRefreshChange(pushState);
  // A project's native ChatGPT Project changes from the browser; the sidebar and a waiting new chat say so.
  onProjectLinkChange(() => push('session:changed'));
  // A creation armed before the app last quit becomes uncertain on time, not on the browser's next pass.
  void expireArmedProjectCreates().catch(() => undefined);
  registerPluginIpc(handle, getWindow, pushState);
  // Draft stages belong to session controls; state:changed only refreshes settings.
  onGoalChange(() => push('session:changed'));
  handle('tasks:cancel', async payload => cancelTaskRequest(z.object({ requestId: z.string().uuid() }).parse(payload).requestId));
  handle('sessions:goalOpening', async payload => {
    const { text, mode, requestId } = z.object({ text: z.string().trim().min(1).max(16000),
      mode: z.enum(['goal', 'loop']), requestId: z.string().uuid() }).parse(payload);
    const backend = goalBackendFor(mode);
    const publish = (progress: import('../shared/task-progress.js').TaskProgressUpdate) => push('task:progress', { requestId, ...progress });
    return runTaskRequest(requestId, JSON.stringify(['goal', text, mode]), async signal => {
      if (goalBackendFor(mode) !== backend) throw new Error('task_settings_changed');
      const drafted = await draftOpeningMessage(text, mode, publish, signal);
      if ('error' in drafted) throw nativeGoalFailure(drafted.error, backend, drafted.retryAfterMs);
      signal.throwIfAborted(); publish({ phase: 'ready', text: drafted.reply.slice(-8000) });
      return drafted;
    }, publish);
  });
  configureChatModelDiscovery({ changed: () => push('chatModels:changed', getChatModels()), wake: async (nonce, allowOpen) => {
    if (!await startBridge()) throw new Error('The browser bridge could not start');
    if (allowOpen) {
      await wakeBrowserUrl(`https://chatgpt.com/?cos-model-catalog=${nonce}`, true, true);
      // The approval prompt it describes comes with ChatGPT's first Core tool call, which needs a Core
      // tunnel. On a fresh install, discovery opened ChatGPT before any of that existed and the
      // reminder read "One last step" at step 0 of 6; Setup's last card keeps it until then.
      if (getConfig().tunnel.tunnelId.trim()) push('setup:toolApprovalNotice');
    }
  } });
  onUpdateChange(pushState);
  onMacOSDesktopAccessChange(pushState);
  onLog((entry) => push('log:entry', entry));
  // Recorder pushes name their exact transcript owners; payload-less pushes are catalog/control only.
  onSessionChange(change => push('session:changed', change));
  onBackgroundExecChange(() => push('sessions:backgroundExecChanged'));
  onSwarmChange(() => push('swarm:changed', swarmState()));
}
