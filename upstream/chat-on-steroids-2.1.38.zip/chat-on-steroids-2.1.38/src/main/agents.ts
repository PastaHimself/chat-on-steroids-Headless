/**
 * Independent prime-owned worker families. Each active incarnation has its own maxWorkers
 * admission limit. Conversation identity resolves an owner; local names such as worker-1
 * never select an owner. Browser transactions additionally carry the exact incarnation ID.
 *
 * When a family's last worker stops, its full history parks under its prime conversation.
 * Waking that family creates a fresh incarnation without changing any worker conversation.
 * The continuation transaction alone can transfer the prime binding to another conversation.
 *
 * Spawn/message/finish plans cross the existing durable snapshot barrier before publication.
 * Every closure retains its exact owner/agent objects, so another owner's work cannot change
 * where a pending transaction commits or rolls back. Slots are admission, never eviction:
 * workers that prove they were still running remain recognized even above the current limit.
 */

import { randomUUID } from 'node:crypto';
import type { AgentInfo, AgentMessage, AgentState, ReasoningEffort, SwarmState } from '../shared/session.js';
import { REASONING_EFFORTS, isReasoningEffort } from '../shared/session.js';
import { getConfig } from './config.js';
import { liveConnectorName } from './mcp/surfaces.js';
import { workerBrief, workerOwnTask } from '../shared/worker-brief.js';
import { getChatModels, refreshForUnoffered } from './chat-models.js';
import { resolveChatModel, type ChatModelOption } from '../shared/chat-models.js';
import { logInfo, logWarn } from './logger.js';
import { inheritWorkspace, releasePrimeWorkspace, bindAgentWorkspace } from './workspace.js';
import { requestCorrelation } from './session/correlation.js';
import { getSession, findSessionByConversation, recordWorkerAssignment } from './session/store.js';
import { continuationForSession } from './session/continuation.js';

export const PRIME_ID = 'prime';

/**
 * Unacknowledged messages held per agent before the broker pushes back.
 *
 * Reached only if an agent stops calling tools entirely while the other side keeps talking.
 * Dropping the oldest to make room quietly destroyed exactly the messages most likely to
 * matter while still telling the sender "Sent", so the limit is a refusal instead.
 */
const MAX_QUEUE = 200;
export const MAX_MESSAGE_CHARS = 4000;
/**
 * Maximum broker prose appended to one MCP result.
 *
 * The queue can legitimately hold 200 × 4k messages. Offering that whole backlog at once
 * makes the delivery mechanism itself an ~800k-character tool result; if the client refuses or
 * truncates it, at-least-once semantics faithfully re-offer the same impossible payload forever.
 * Deliver a bounded oldest-first slice instead. The next authenticated call acknowledges only
 * that offered slice, then the following result advances to the next one.
 */
const MAX_INBOX_OFFER_CHARS = 32_000;
/**
 * Messages one `message` call may carry.
 *
 * Sized to the run rather than to nothing in particular: the worker limit is 8, and the
 * batch that exists to redirect a whole run needs room for one message to each of them plus
 * a couple of corrections.
 */
export const MAX_BATCH_MESSAGES = 16;
const MAX_TASK_CHARS = 4000;
/**
 * A sleeping worker may satisfy an exact repeated spawn only while the original spawn result
 * could realistically still be the result being retried. Beyond this window the same task is
 * new intent: history is persistent now, so lifetime sleeper matching would make it impossible
 * to deliberately create another worker with the same brief.
 */
/**
 * The shared preamble one spawn may put in front of every worker's task.
 *
 * Its own budget rather than a share of the task's: the context is written once and the
 * tasks are written per worker, so charging one against the other would make adding a fourth
 * worker silently shrink the room for the standing instructions all four of them need.
 */
const MAX_CONTEXT_CHARS = 4000;
const MAX_LABEL_CHARS = 60;
/**
 * How long a ChatGPT model slug in a worker's `model` field may be.
 *
 * Slugs are OpenAI's vocabulary, not ours, so this is a transport bound, not a menu: anything
 * shaped like a slug passes through to the fresh-chat URL untouched, and an unknown slug
 * simply opens with the account default rather than failing the spawn.
 */
const MAX_MODEL_CHARS = 80;
const MODEL_SLUG_RE = /^[A-Za-z0-9._-]{1,80}$/;

/** Real work renews this deadline; an open page, reload or status poll does not. */
export const WORKER_SILENCE_MS = 3 * 60_000;

/**
 * How recent a page's "my turn is still running" must be to hold off the silence sleep.
 *
 * A generating page polls every two seconds at most, but Chrome throttles a long-hidden tab's
 * timers to about once a minute, and worker tabs are usually hidden. Shorter than
 * {@link WORKER_SILENCE_MS}, so a page that stops polling never adds more than this to it.
 */
export const PAGE_GENERATING_FRESH_MS = 150_000;

/**
 * The longest an open turn alone keeps a worker awake without a call or new output.
 *
 * ChatGPT can think for half an hour between two tool calls (#882: 30m 18s, slept three
 * times while it worked). The page's own lifecycle already closes a turn that shows no
 * progress for ten minutes; this is the backstop for one that never closes.
 */
export const WORKER_THINKING_MAX_MS = 2 * 60 * 60_000;

/**
 * The context a worker chat may reach before it stops being worth reviving.
 *
 * The same 400k figure the app uses for its own context ceiling, and for the same reason: it
 * is where ChatGPT has actually been observed to stop accepting more. Past it a revival would
 * reopen a chat with no room left to work in, so that worker's next stop is its last one.
 *
 * It is never a stop signal. A worker that crosses the line mid-task keeps its slot, keeps its
 * inbox and keeps working until that work is done; all the crossing changes is that the sleep
 * at the end of it is `finished` instead.
 */
export const WORKER_CONTEXT_CEILING_TOKENS = 400_000;

export class AgentError extends Error {}

/** Raised at every `agents` action reached from a conversation outside the active run. */
export class AgentsBusyError extends AgentError {
  constructor() {
    super(
      'AGENTS_BUSY: no agent family belongs to this conversation. Other primes and their workers are isolated. ' +
        'Call agents action=spawn to create workers owned by this chat.'
    );
  }
}

/**
 * Raised when a call meant for the run could not be placed in any conversation.
 *
 * Every identity here is a conversation, so a call this app cannot place is a call it cannot
 * attribute — and the answer to that is to say so, not to accept a key the model is carrying
 * instead. An unknown caller cannot be promised a caller-specific browser action. The kernel
 * may append the current recovery status; the refusal itself only describes this operation.
 */
export class IdentityLostError extends AgentError {
  constructor(message?: string) {
    super(
      message ?? ('WORKER_IDENTITY_LOST: Chat On Steroids could not tell which conversation this call came from, so it cannot ' +
        'act on the run from here. No agent operation was performed. Wait briefly and retry this operation once. ' +
        'If it is still refused, preserve your result in the chat and report that delivery is unconfirmed; ' +
        'do not claim the message or finish report reached its recipient.')
    );
  }
}

/**
 * An agent that will not act again, whichever way it ended.
 *
 * `finished` and `failed` differ only in what the user is told. Everything that asks "is
 * this run still going", "may this worker still be messaged", "does this worker still owe
 * us a tab" wants both.
 *
 * `detached` is deliberately *not* here. That is the state of a worker whose ChatGPT tab is
 * gone while its turn is not: it still holds its slot, still resolves for its own
 * conversation, still has an inbox, and still reports the ordinary way. Every caller of
 * this function has to keep treating it as live — that is the whole reason the state exists.
 *
 * Nor is `sleeping`. A sleeping worker is a member of the run in every sense except that it
 * is not working: it keeps its conversation, its transcript and its queue, and the prime can
 * wake it by messaging it. Terminal means *this worker will never work again*, and only the
 * context ceiling, a bootstrap that never came up, and a person clearing the row mean that.
 */
export function isOver(state: AgentState): boolean {
  return state === 'finished' || state === 'failed';
}

/**
 * Whether this state consumes one of the run's worker slots.
 *
 * The slot is capacity to be *working*, not membership of the run. `invited` and `waking` are
 * both "a chat is being opened or typed into for this worker right now", and both have to hold
 * a slot or two concurrent revivals could claim the same one. `sleeping` holds nothing: that
 * is what lets a run own more workers than it can ever run at once.
 */
export function occupiesSlot(state: AgentState): boolean {
  return state === 'invited' || state === 'active' || state === 'detached' || state === 'waking';
}

/** Whether this worker's own chat has grown past the point where reviving it buys anything. */
function ceilingCrossed(info: AgentInfo): boolean {
  return info.contextTokens >= WORKER_CONTEXT_CEILING_TOKENS;
}

/**
 * Whether this agent has stopped working, whether or not it can be started again.
 *
 * The question `finish` idempotence asks. A worker that has already reported and gone to sleep
 * must answer a repeated `finish` as the retry it is: taking the second call literally would
 * queue the prime a second copy of the same report with no way to tell that from two genuine
 * ones, which is the bug the original terminal-state check existed to prevent and which
 * sleeping would otherwise reopen.
 */
function hasStopped(state: AgentState): boolean {
  return isOver(state) || state === 'sleeping';
}

/**
 * Whether a stop observed now — a settled answer, a finish call, a chat proved quiet — may end
 * this worker's current work.
 *
 * `waking` says no. The worker is not working, so there is nothing to stop, and the wake that
 * reserved its slot ends only through its own proof (the woken chat's first call or turn) or
 * its own failure. Treating a stop as applicable while waking is how the 2026-09-02 wakes were
 * lost: the page re-reported the settled answer that had put the worker to sleep, the finish
 * landed on the `waking` row as fresh, the worker went back to `sleeping` with the wake
 * command retired as "no longer waiting" — and the message the browser had just typed ran as
 * a turn the app did not own.
 */
function canStop(state: AgentState): boolean {
  return !hasStopped(state) && state !== 'waking';
}

/** A silence-parked ceiling worker may only move through the staged terminal barrier. */
function canStageFinish(agent: Agent): boolean {
  return canStop(agent.info.state) || (
    agent.info.state === 'sleeping' &&
    !agent.info.revivable &&
    agent.info.silenceParked === true &&
    ceilingCrossed(agent.info)
  );
}

interface Agent {
  info: AgentInfo;
  queue: AgentMessage[];
}

/**
 * A continuation-owned prime binding transfer.
 *
 * `primeConversationId` is immutable for the lifetime of a run except through
 * {@link commitPrimeTransfer}, which is only ever reached from the commit step of the app's
 * own Compact & Resume session rebind.
 */
interface PrimeTransfer {
  from: string;
  at: number;
  frozen: boolean;
}

interface Run {
  runId: string;
  /** Earlier incarnations of this family; see {@link MAX_FORMER_RUN_IDS}. */
  formerRunIds?: string[];
  /** Setup profile of the exact MCP endpoint generation that created this family. */
  setupProfileId?: string;
  primeConversationId: string | null;
  /** Inbound HTTP request that created this family before its chat was known. */
  primeRequestId?: string;
  /** Trusted local control API principal; never a claimed ChatGPT conversation. */
  localOwnerId?: string;
  startedAt: number;
  agents: Map<string, Agent>;
  /**
   * An open Compact & Resume handover, at most one.
   *
   * Bookkeeping only: the authority is the session layer's continuation transaction, and
   * this just records that the prime chat is expected to go away right now.
   *
   * It has no clock of its own. The continuation opens it, and the continuation ends it —
   * by committing the move or by cancelling it when the continuation aborts — so it lives
   * exactly as long as the transaction that owns it. An independent ten-minute deadline used
   * to run alongside that transaction, and on 2026-09-01 it won the race: an automatic
   * compaction whose handoff turn took eleven minutes reached its commit with a live
   * continuation and an expired handover, the commit was refused, and the session was left
   * stranded between chat A and chat B. Two clocks for one transaction is how that happens;
   * there is one now.
   *
   * `frozen` marks the handover as committed-to: the session layer freezes it before it
   * starts the durable write, so the run cannot be reactivated or otherwise moved out from
   * under a commit that is already on disk.
   */
  transfer: PrimeTransfer | null;
  /**
   * When the prime's ChatGPT chat was last reported gone, or null while it is there.
   *
   * Telemetry, not a deadline. There is deliberately no clock attached to it: the case this
   * whole mode now exists to serve is a prime that stops, gets feedback from the user hours
   * later, and carries on with the same workers, and any timeout at all would turn a long
   * enough pause back into the destroyed-run bug. Cleared the instant the prime chat proves
   * it exists again.
   */
  primeGoneAt: number | null;
}

const runs = new Map<string, Run>();

/** No implicit selection when more than one owner is executing. */
function scopedRun(runId?: string): Run | null {
  if (runId !== undefined) return runs.get(runId) ?? null;
  return runs.size === 1 ? runs.values().next().value ?? null : null;
}
function runForConversation(conversationId: string | null | undefined): Run | null {
  if (!conversationId) return null;
  let found: Run | null = null;
  for (const owner of runs.values()) {
    if (owner.primeConversationId !== conversationId && ![...owner.agents.values()].some(a => a.info.conversationId === conversationId)) continue;
    if (found) return null;
    found = owner;
  }
  return found;
}
function runForAgent(agent: Agent): Run | null {
  for (const owner of runs.values()) if (owner.agents.get(agent.info.id) === agent) return owner;
  return null;
}
function stampOwner(owner: Run): void {
  for (const agent of owner.agents.values()) {
    agent.info.runId = owner.runId;
    agent.info.primeConversationId = owner.primeConversationId ?? undefined;
  }
}
export function activeRunIds(): string[] { return [...runs.values()].filter(r => !unpublishedRuns.has(r)).map(r => r.runId); }

/** Prime-owned durable history while none of its workers occupies a slot. */
interface DormantRun {
  /** Earlier incarnations of this family; see {@link MAX_FORMER_RUN_IDS}. */
  formerRunIds?: string[];
  /** Preserved connection provenance; absent only for legacy/unproven histories. */
  setupProfileId?: string;
  primeConversationId: string | null;
  primeRequestId?: string;
  localOwnerId?: string;
  startedAt: number;
  parkedAt: number;
  agents: Map<string, Agent>;
  /** Compact & Resume may move ownership while no worker is running. */
  transfer: PrimeTransfer | null;
}

const dormantRuns = new Map<string, DormantRun>();
/**
 * How much parked history the broker keeps. Every dormant family is scanned on every
 * unattributed call and, through hasDormantWorkerLeases(), turns each such call into a
 * fifteen-second identity wait; by 2026-09-01 three days of runs had left twenty-nine
 * families on disk, so every anonymous call waited on chats nobody would ever wake again.
 * A family older than this, or beyond the newest MAX_DORMANT_RUNS, is dropped and its worker
 * chats become ordinary retired leases; its prime spawns afresh if it ever comes back.
 */
const DORMANT_RUN_TTL_MS = 7 * 24 * 60 * 60_000;
const MAX_DORMANT_RUNS = 16;

/**
 * The earliest instant this process can honestly claim to have been watching a conversation.
 *
 * `lastSeenAt` is stamped on every proven call but only written to disk when something else
 * asks for a write, so a restored run can carry a stale one. Failing a detached worker on
 * that number would end a live worker because of a write that never happened; the floor makes
 * a restart start the silence clock again instead.
 */
let livenessFloor = 0;

let spawnRequest: ((workers: WorkerSpawn[]) => void) | null = null;
const listeners = new Set<() => void>();
const endListeners = new Set<(reason: string, retired: RetiredChat[], runId: string) => void>();
const retireListeners = new Set<(conversationIds: readonly string[]) => void>();
let persist: (() => void) | null = null;
let persistNow: ((snapshot: SwarmSnapshot | null) => Promise<void>) | null = null;
let criticalMutationRevision = 0;
let persistedCriticalRevision = 0;
let criticalPersistFlight: Promise<boolean> | null = null;
let retiredPersist: (() => void) | null = null;
let retiredPersistNow: ((snapshot: RetiredWorkersSnapshot) => Promise<void>) | null = null;
const RETIRED_WORKER_TTL_MS = 30 * 60_000;
const retiredWorkers = new Map<string, RetiredChat>();
/**
 * Denial-only worker identity after managed families leave bounded broker history.
 * Recording may be Off, so SessionOrigin cannot be the only durable fence.
 * No entry can authorize a checkout; snapshots preserve exact browser-bound IDs.
 */
const retiredManagedWorkerConversations = new Set<string>();
/** Cheap negative guard for the common feature-off installation, where no worker ever had a checkout. */
let managedWorktreeHistoryPossible = false;
/**
 * Durable cleanup authority for accepted worker checkouts after their broker family is
 * cleared or evicted. A filesystem marker alone cannot authorize a retired allocation.
 * This contains only identity, never a path or permission to delete any worker data.
 */
export interface ManagedWorktreeCleanupOffer {
  runId: string;
  agentId: string;
  reason: 'completed' | 'failed' | 'cleared' | 'evicted';
  createdAt: number;
  /** Human-readable job name retained after the broker row is cleared or evicted. */
  label?: string;
}
const managedWorktreeCleanupHistory = new Map<string, ManagedWorktreeCleanupOffer>();
const managedAllocationRunPattern = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const managedAllocationAgentPattern = /^worker-[1-9][0-9]{0,5}$/;

function cleanupIdentity(info: AgentInfo): { runId: string; agentId: string } | null {
  const runId = info.workerAllocationRunId;
  if (info.role !== 'worker' || info.managedWorktree !== true ||
      typeof runId !== 'string' || !managedAllocationRunPattern.test(runId) ||
      !managedAllocationAgentPattern.test(info.id)) return null;
  return { runId: runId.toLowerCase(), agentId: info.id };
}

function cleanupAcknowledged(info: AgentInfo): boolean {
  return (info as AgentInfo & { managedWorktreeCleaned?: boolean }).managedWorktreeCleaned === true;
}

function cleanupOfferKey(identity: { runId: string; agentId: string }): string {
  return `${identity.runId}:${identity.agentId}`;
}

/** A task-first row label, even when a worker was spawned without a custom label. */
function cleanupDisplayLabel(info: AgentInfo): string {
  // A wake replaces `task` with the waking message; the checkout keeps the job's own name.
  const title = info.label && info.label !== info.id ? info.label : info.jobTitle || workerOwnTask(info.task);
  return (title?.split(/[\r\n]/, 1)[0]?.trim() || info.label || info.id).slice(0, 160);
}

/** Preserve accepted cleanup authority before the last owner row is removed. */
function retireManagedWorktreeCleanupOffers(agents: Iterable<Agent>, reason: 'cleared' | 'evicted'): void {
  for (const agent of agents) {
    if (unpublishedAgents.has(agent)) continue;
    const identity = cleanupIdentity(agent.info);
    if (!identity) continue;
    const key = cleanupOfferKey(identity);
    if (cleanupAcknowledged(agent.info)) {
      managedWorktreeCleanupHistory.delete(key);
      continue;
    }
    const existing = managedWorktreeCleanupHistory.get(key);
    managedWorktreeCleanupHistory.set(key, {
      ...identity, reason, createdAt: existing?.createdAt ?? Date.now(),
      label: cleanupDisplayLabel(agent.info) || existing?.label
    });
  }
  // Preserve every pending authorization until an explicit cleanup acknowledgement exists.
  // Truncating by count would strand older checkouts: their markers may not independently
  // authorize a delete once their broker family has been evicted.
}
/** Worker objects created by a spawn whose public durable acceptance has not succeeded yet. */
const unpublishedAgents = new WeakSet<Agent>();
/** A brand-new run is itself unpublished until its staged spawn crosses the acceptance barrier. */
const unpublishedRuns = new Set<Run>();
interface SpawnStageState {
  run: Run;
  created: Agent[];
  /** Resource allocation is complete; foreign critical writes must not admit an earlier stage. */
  durableReady: boolean;
  becamePrime: boolean;
  /** Existing dormant history temporarily reactivated for this staged spawn, if any. */
  resumedDormant: DormantRun | null;
  /** True only when this staged spawn created a brand-new owner history. */
  createdFreshRun: boolean;
  settled: boolean;
}
/** Only one topology transaction per owner may be open; independent owners may stage concurrently. */
const activeSpawnStages = new Map<Run, SpawnStageState>();
/**
 * Messages that are present in the broker snapshot but are not visible to their recipient yet.
 *
 * `agents action=message` has a real durable acceptance barrier. The message has to be part of
 * the snapshot *before* that barrier can write it, but exposing it to offerMessages() before
 * the write succeeds lets a recipient consume work the sender was just told failed. Keep the
 * actual queue object staged until disk accepts the revision. This bit is intentionally not
 * serialized: restoring a message from a durable snapshot is itself proof that acceptance won.
 */
const unpublishedMessages = new WeakSet<AgentMessage>();
/**
 * Worker finishes waiting for their immediate durable acceptance barrier.
 *
 * Unlike a staged message, a finish changes both an AgentInfo row and the prime's queue. Keep
 * neither mutation in the live objects until disk accepts the exact projected snapshot. The
 * critical snapshot overlays these plans; ordinary/debounced snapshots, status and inbox
 * readers continue to see the pre-finish state until commit.
 */
interface FinishStageState {
  run: Run;
  agent: Agent;
  info: AgentInfo;
  report: AgentMessage;
  /**
   * Normal inbox rows whose delivery this finish observation itself proves.
   *
   * Explicit `agents finish` gets this proof later from the kernel's ordinary
   * acknowledgeOffers() call. Browser-owned finalization has no next MCP call, so its settled
   * assistant answer is the only acknowledgement point. Keep these ids in the same staged
   * durability projection as the sleeping state/report; mutating the live queue before that
   * write succeeds would silently lose work on a crash/rejected write.
   */
  acknowledgedMessageIds: string[];
  settled: boolean;
}
const activeFinishStages = new Map<Agent, FinishStageState>();

// ------------------------------------------------------------------ listeners

export function onSwarmChange(listener: () => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

type SwarmMutationDurability = 'critical' | 'telemetry';

function changed(durability: SwarmMutationDurability = 'critical'): void {
  if (durability === 'critical') criticalMutationRevision += 1;
  persist?.();
  for (const listener of listeners) listener();
}

/** The store registers here so the broker needs to know nothing about files. */
export function onSwarmPersist(handler: (() => void) | null): void {
  persist = handler;
}

/**
 * Registers the durable barrier for broker mutations whose loss changes identity, topology,
 * terminal state, or accepted messages. The existing `onSwarmPersist` callback remains the
 * cheap/debounced path for every mutation; this second hook is explicit so callers performing
 * a user-visible critical transition can await disk durability before publishing success.
 *
 * The callback receives the exact snapshot for the revision being drained. That avoids a
 * persistence adapter re-reading mutable broker state after an await and accidentally claiming
 * a different generation durable.
 */
export function onSwarmPersistNow(handler: ((snapshot: SwarmSnapshot | null) => Promise<void>) | null): void {
  persistNow = handler;
}

/**
 * Durably drains all critical broker revisions observed through the end of the write loop.
 * Returns false when the host has not wired an immediate persistence sink yet; it never
 * silently treats the debounced callback as an fsync-equivalent barrier.
 */
export async function persistCriticalSwarmNow(): Promise<boolean> {
  if (!persistNow) return false;
  if (persistedCriticalRevision >= criticalMutationRevision) return true;
  if (!criticalPersistFlight) {
    criticalPersistFlight = (async () => {
      while (persistedCriticalRevision < criticalMutationRevision) {
        const handler = persistNow;
        if (!handler) return false;
        const targetRevision = criticalMutationRevision;
        // Critical acceptance is the one persistence lane allowed to see staged messages.
        // The ordinary/debounced snapshot deliberately hides them: its write can reach disk
        // while this fsync-equivalent barrier is still waiting, and recovering an unpublished
        // message after a crash would make a send durable before the sender was told it
        // succeeded. See snapshotSwarm() and stageMessages().
        const snapshot = snapshotSwarmIncludingUnpublished();
        await handler(snapshot);
        // Presentation only (names and tasks for history): it follows the durable write and never
        // holds up the acceptance this barrier exists for.
        void archiveWorkerAssignments(snapshot);
        persistedCriticalRevision = Math.max(persistedCriticalRevision, targetRevision);
      }
      return true;
    })().finally(() => {
      criticalPersistFlight = null;
    });
  }
  return criticalPersistFlight;
}

export function onRetiredWorkersPersist(handler: (() => void) | null): void {
  retiredPersist = handler;
}

/** Immediate persistence sink for the post-run worker authority fences. */
export function onRetiredWorkersPersistNow(
  handler: ((snapshot: RetiredWorkersSnapshot) => Promise<void>) | null
): void {
  retiredPersistNow = handler;
}

/**
 * Makes the current retired-worker fence set durable before a caller publishes teardown.
 *
 * A run ending creates two pieces of authority state: the active swarm disappears and every
 * bound worker conversation becomes a short-lived retired lease. Persisting only the first is
 * unsafe: after a crash the old worker chat can otherwise come back as an ordinary chat and use
 * local mutation tools. The lease file is deliberately written first; an extra/stale fence is a
 * temporary refusal, while a missing fence is unintended authority.
 */
export async function persistRetiredWorkersNow(): Promise<boolean> {
  const handler = retiredPersistNow;
  if (!handler) return false;
  await handler(snapshotRetiredWorkers());
  return true;
}

/** Durability barrier for a user-visible broker/worker-authority transition. */
export async function persistAgentAuthorityNow(): Promise<boolean> {
  if (!(await persistRetiredWorkersNow())) return false;
  return persistCriticalSwarmNow();
}

/**
 * Called when a run ends, for any reason.
 *
 * The bridge listens so worker bootstraps queued for the run that just ended are cancelled
 * in the same tick; without it the browser kept opening tabs for workers of a swarm that no
 * longer existed.
 */
export function onSwarmEnd(listener: (reason: string, retired: RetiredChat[], runId: string) => void): () => void {
  endListeners.add(listener);
  return () => endListeners.delete(listener);
}

/**
 * Worker chats that just became retired: the broker will never wake or message them again.
 *
 * Covers both ways a worker retires: its run ends (cleared, or the prime closed with nothing left
 * to come back to) and Clear workers retiring parked histories. A parked run is not retirement;
 * its prime can still wake those workers. Used to archive them in ChatGPT (#1460).
 */
export function onWorkerChatsRetired(listener: (conversationIds: readonly string[]) => void): () => void {
  retireListeners.add(listener);
  return () => retireListeners.delete(listener);
}

function announceRetired(conversationIds: readonly string[]): void {
  if (conversationIds.length === 0) return;
  for (const listener of retireListeners) listener(conversationIds);
}

/** A worker chat whose run ended and whose conversation must not immediately become an ordinary chat. */
export interface RetiredChat {
  id: string;
  conversationId: string;
  reason: string;
  retiredAt: number;
}

/** A worker whose chat still has to be opened. Carries no credential. */
export interface WorkerSpawn {
  runId: string;
  primeConversationId: string | null;
  id: string;
  task: string;
  /** Requested ChatGPT model slug, or null for the account default. */
  model: string | null;
  /** Requested reasoning level, or null to inherit the default. */
  reasoningEffort: ReasoningEffort | null;
}

/** Workers that exist but have not joined: their chat is still owed. */
export function pendingWorkerSpawns(): WorkerSpawn[] {
  return [...runs.values()].flatMap(run => [...run.agents.values()]
    .filter(
      (agent) =>
        agent.info.role === 'worker' && agent.info.state === 'invited' && !unpublishedAgents.has(agent)
    )
    .map((agent) => ({ runId: run.runId, primeConversationId: run.primeConversationId, id: agent.info.id, task: agent.info.task, model: agent.info.model, reasoningEffort: agent.info.reasoningEffort })));
}

/**
 * The bridge registers here, so the broker never has to know about HTTP or tabs.
 *
 * Registration replays whatever is already owed: startup restores the run before the bridge
 * exists, so the restore itself has nobody to ask for a tab.
 */
export function onSpawnRequest(handler: (workers: WorkerSpawn[]) => void): () => void {
  spawnRequest = handler;
  const owed = pendingWorkerSpawns();
  if (owed.length > 0) {
    handler(owed);
    logInfo(`multi-agent: ${owed.length} worker chat(s) still owed a tab`);
  }
  return () => {
    if (spawnRequest === handler) spawnRequest = null;
  };
}

// ------------------------------------------------------------------ identity

/**
 * What a caller can offer as proof of who it is. No field is ever an agent id.
 */
export interface Caller {
  /** Set only by the authenticated local control API, absent from MCP caller arguments. */
  localOwnerId?: string;
  /**
   * The ChatGPT conversation this call was proven to come from. A permitted unresolved
   * prime keeps its separate requestId until that proof arrives.
   *
   * Only ever set from evidence gathered for the call being handled: ChatGPT's own message
   * model naming this exact tool request, in exactly one conversation. Never from anything
   * the model wrote, and never from "the chat that has been active lately".
   */
  conversationId?: string | null;
  /** Transport-provided request ID, never a model argument. */
  requestId?: string | null;
  sessionId?: string | null;
  /** Setup profile of the MCP endpoint generation that accepted this call. */
  setupProfileId?: string | null;
  /** Optional family selection; ownership is checked independently. */
  runId?: string;
}

type Family = Run | DormantRun;
type FamilyOwner = Pick<Run, 'primeConversationId' | 'primeRequestId' | 'localOwnerId' | 'setupProfileId'>;

/** Parked fleets keep their last incarnation, even when several have the same prime. */
function familyKey(owner: Family): string {
  return 'runId' in owner ? owner.runId : owner.agents.get(PRIME_ID)!.info.runId!;
}

/**
 * Earlier run ids retained by one family.
 *
 * Every wake of a parked family is a new incarnation with a new id, and that id is a fence for
 * browser commands. But two existing contracts need older opaque ids after that fence rotates:
 * the family's own prime may answer a worker report carrying one of its recent run ids (#881,
 * #882), and a foreign prime may hold the source_run_id printed on an unacknowledged cross-prime
 * message. Keep the latter as one stable family reply alias and preserve the historical eight
 * recent incarnation selectors beside it. Neither kind can select a foreign worker or move the
 * current browser-command fence.
 */
const MAX_RECENT_FORMER_RUN_IDS = 8;
const MAX_FORMER_RUN_IDS = MAX_RECENT_FORMER_RUN_IDS + 1;

function boundedFormerRunIds(ids: readonly string[]): string[] {
  const unique = [...new Set(ids)];
  if (unique.length <= MAX_FORMER_RUN_IDS) return unique;
  const stableReplyAddress = unique[0]!;
  return [stableReplyAddress, ...unique.slice(-MAX_RECENT_FORMER_RUN_IDS)];
}

/** Whether a caller's run_id names this family, now or in one of its earlier incarnations. */
function answersTo(owner: Family, runId: string): boolean {
  return familyKey(owner) === runId || Boolean(owner.formerRunIds?.includes(runId));
}

/** Opaque cross-prime reply address that remains valid while incarnation fences rotate. */
function familyReplyAddress(owner: Family): string {
  return owner.formerRunIds?.[0] ?? familyKey(owner);
}

function allFamilies(): Family[] {
  return [...runs.values(), ...dormantRuns.values()];
}

/** Setup-profile ids come from validated config/endpoint state, never model arguments. */
function setupProfileId(value: unknown): string | undefined {
  return typeof value === 'string' && value.length >= 1 && value.length <= 64 ? value : undefined;
}

/**
 * A legacy family with no recorded profile stays unclaimed rather than being guessed later.
 * When both sides have provenance, however, a different endpoint profile cannot acquire it.
 */
function setupProfileMatches(caller: Caller, owner: FamilyOwner): boolean {
  const current = setupProfileId(caller.setupProfileId);
  return !current || !owner.setupProfileId || current === owner.setupProfileId;
}

/**
 * Resolves an explicit prime-family address without changing caller ownership.
 *
 * A foreign run id is intentionally usable only by the prime-to-prime message path. Status,
 * workers and every ordinary message still resolve through familiesForCaller(), so knowing this
 * opaque address grants no control over the destination family.
 */
function familyForAddress(runId: string): Family | null {
  const matches = allFamilies().filter(
    owner => !unpublishedRuns.has(owner as Run) && answersTo(owner, runId)
  );
  return matches.length === 1 ? matches[0]! : null;
}

function exactCaller(caller: Caller): Caller {
  const proof = requestCorrelation(caller.requestId);
  return proof && !caller.conversationId
    ? { ...caller, conversationId: proof.conversationId, sessionId: proof.sessionId }
    : caller;
}

function hasCallerIdentity(caller: Caller): boolean {
  if (caller.localOwnerId) return validLocalOwner(caller.localOwnerId) && !caller.conversationId && !caller.requestId;
  return Boolean(caller.conversationId || (getConfig().multiAgent.allowUnattributedCalls && caller.requestId));
}

function validLocalOwner(value: unknown): value is string {
  return typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(value);
}

function ownsPrime(caller: Caller, owner: FamilyOwner): boolean {
  if (owner.localOwnerId) return hasCallerIdentity(caller) && caller.localOwnerId === owner.localOwnerId;
  if (caller.localOwnerId) return false;
  // Once attached, only the current frontend owns the fleet. In particular, an old request
  // from A cannot recover prime authority after the durable session has moved to B.
  if (owner.primeConversationId) return caller.conversationId === owner.primeConversationId;
  return Boolean(owner.primeRequestId && !requestCorrelation(owner.primeRequestId) &&
    !caller.conversationId && getConfig().multiAgent.allowUnattributedCalls && caller.requestId === owner.primeRequestId);
}

function belongsToFamilyIdentity(caller: Caller, owner: Family): boolean {
  return ownsPrime(caller, owner) || Boolean(caller.conversationId && [...owner.agents.values()]
    .some(agent => agent.info.role === 'worker' && agent.info.conversationId === caller.conversationId));
}

function mismatchedSetupProfile(input: Caller): Family | null {
  const caller = exactCaller(input);
  const current = setupProfileId(caller.setupProfileId);
  if (!current) return null;
  return allFamilies().find(owner =>
    belongsToFamilyIdentity(caller, owner) &&
    Boolean(owner.setupProfileId) && owner.setupProfileId !== current
  ) ?? null;
}

function requireMatchingSetupProfile(caller: Caller): void {
  const mismatch = mismatchedSetupProfile(caller);
  if (!mismatch) return;
  throw new AgentError(
    'CONNECTION_PROFILE_MISMATCH: this worker family belongs to a different Setup profile. ' +
      'No agent operation was performed. Switch back to the connection that created this family; ' +
      'cross-profile worker routing is not automatic.'
  );
}

function familiesForCaller(input: Caller, includeUnpublished = false): Family[] {
  const caller = exactCaller(input);
  return allFamilies().filter(owner => {
    const unpublished = unpublishedRuns.has(owner as Run);
    if (unpublished && !includeUnpublished) return false;
    // Proof can arrive during a staged spawn's disk barrier. Admission must still see that
    // exact in-flight request instead of creating a second fleet while its first is hidden.
    const stagedRequest = includeUnpublished && unpublished && owner.primeRequestId &&
      (owner.primeRequestId === caller.requestId || Boolean(caller.conversationId &&
        requestCorrelation(owner.primeRequestId)?.conversationId === caller.conversationId));
    return setupProfileMatches(caller, owner) && (stagedRequest || belongsToFamilyIdentity(caller, owner));
  });
}

function selectedFamily(input: Caller, includeUnpublished = false): Family | null {
  const owned = familiesForCaller(input, includeUnpublished);
  if (input.runId) return owned.find(owner => familyKey(owner) === input.runId) ?? owned.find(owner => answersTo(owner, input.runId!)) ?? null;
  return owned.length === 1 ? owned[0]! : null;
}

function requireFamilySelection(caller: Caller): void {
  requireMatchingSetupProfile(caller);
  const owned = familiesForCaller(caller, true);
  if (caller.runId && !owned.some(owner => answersTo(owner, caller.runId!))) throw new AgentsBusyError();
  if (!caller.runId && owned.length > 1) {
    throw new AgentError('RUN_SELECTION_REQUIRED: this caller owns several worker fleets. Use agents action=status and select the intended run_id; worker names are local to each fleet. No agent operation was performed.');
  }
}

let requestOwnerRecovery: Promise<void> | null = null;
let requestOwnerRecoveryAgain = false;
let requestOwnerEpoch = 0;

/** Rebuild the fleet projection from exact request proof and the durable current frontend.
 * No request is relabelled as a newer turn. Workers discovered after an anonymous spawn keep
 * their worker role; their already-accepted fleet is entrusted to the real root prime. */
export function reconcileAgentRequestOwners(): Promise<void> {
  requestOwnerRecoveryAgain = true;
  if (requestOwnerRecovery) return requestOwnerRecovery;
  const epoch = requestOwnerEpoch;
  const work = (async () => {
    do {
      requestOwnerRecoveryAgain = false;
      let attached = false;
      for (const owner of allFamilies()) {
        if (owner.primeConversationId || !owner.primeRequestId || unpublishedRuns.has(owner as Run)) continue;
        const proof = requestCorrelation(owner.primeRequestId);
        if (!proof) continue;
        const session = await getSession(proof.sessionId);
        if (!session?.conversationId || !session.chatIds.includes(proof.conversationId)) continue;
        let target = session.conversationId;
        let targetSessionId = session.id;
        // Existing worker custody outranks a provisional prime. Walk only actual broker
        // bindings, not model-supplied ids; an unresolved parent waits for its own proof.
        const visited = new Set<Family>([owner]);
        const parentBindings = new Map<Family, string>();
        while (isWorkerConversation(target)) {
          const parents = allFamilies().filter(family => [...family.agents.values()]
            .some(agent => agent.info.role === 'worker' && agent.info.conversationId === target));
          const parent = parents.length === 1 ? parents[0]! : null;
          if (!parent || visited.has(parent) || !parent.primeConversationId) { target = ''; break; }
          visited.add(parent);
          target = parent.primeConversationId;
          parentBindings.set(parent, target);
          const parentSession = await findSessionByConversation(target, { requireUnique: true });
          if (parentSession?.conversationId && parentSession.chatIds.includes(target)) {
            target = parentSession.conversationId;
            targetSessionId = parentSession.id;
          }
        }
        if (epoch !== requestOwnerEpoch) return;
        if (!target || retiredWorkerForConversation(target) || !allFamilies().includes(owner) ||
          owner.primeConversationId || unpublishedRuns.has(owner as Run)) continue;
        // Worker ACKs can precede the prime's exact request proof. Their recorded
        // sessions then have no parent, even after the worker has already slept.
        // Complete that existing origin before publishing the family attachment;
        // a failed write remains retryable while this owner is still provisional.
        const parentSession = await getSession(targetSessionId);
        if (parentSession?.chatIds.includes(target)) {
          const { noteChatOrigin } = await import('./session/recorder.js');
          for (const agent of owner.agents.values()) {
            if (epoch !== requestOwnerEpoch) return;
            if (!allFamilies().includes(owner) || owner.primeConversationId) break;
            if (agent.info.role !== 'worker' || !agent.info.conversationId) continue;
            await noteChatOrigin(agent.info.conversationId, { kind: 'worker',
              fromSessionId: parentSession.id, agentId: agent.info.id, task: agent.info.task });
          }
        }
        // Reread after the parent walk: a concurrent A -> B commit cannot leave this fleet
        // attached to a superseded source merely because its earlier read returned A.
        const latest = await getSession(proof.sessionId);
        if (epoch !== requestOwnerEpoch) return;
        if (!latest) continue;
        if (latest.conversationId !== session.conversationId || [...parentBindings].some(([parent, binding]) =>
          !allFamilies().includes(parent) || parent.primeConversationId !== binding)) { requestOwnerRecoveryAgain = true; continue; }
        if (!allFamilies().includes(owner) || owner.primeConversationId || isWorkerConversation(target)) continue;
        const handoff = continuationForSession(targetSessionId);
        // The durable session can already name B while the same handoff still owns the
        // broker's A -> B publication. Join its source projection so that publication moves
        // every fleet together; attaching directly to B here would veto A as a collision.
        const transferring = handoff && allFamilies().some(family => family !== owner &&
          family.primeConversationId === handoff.from && family.transfer?.from === handoff.from);
        if (transferring) target = handoff!.from;
        owner.primeConversationId = target;
        owner.agents.get(PRIME_ID)!.info.conversationId = target;
        for (const agent of owner.agents.values()) agent.info.primeConversationId = target;
        // A handoff already in progress owns fleets discovered before its commit too.
        const transfer = allFamilies().find(family => family !== owner && family.primeConversationId === target && family.transfer)?.transfer;
        if (transfer) owner.transfer = { ...transfer };
        else if (handoff?.from === target) owner.transfer = { from: target, at: handoff.openedAt, frozen: handoff.state === 'committing' };
        attached = true;
        changed();
      }
      // A parent may have been attached after its provisional descendants were visited.
      if (attached) requestOwnerRecoveryAgain = true;
    } while (requestOwnerRecoveryAgain && epoch === requestOwnerEpoch);
  })();
  requestOwnerRecovery = work;
  void work.finally(() => { if (requestOwnerRecovery === work) requestOwnerRecovery = null; }).catch(() => undefined);
  return work;
}

function runForCaller(input: Caller, includeUnpublished = false): Run | null {
  const selected = selectedFamily(input, includeUnpublished);
  return selected && 'runId' in selected ? selected : null;
}

function dormantRunForCaller(input: Caller): DormantRun | null {
  const selected = selectedFamily(input);
  return selected && !('runId' in selected) ? selected : null;
}

/** Family selection never falls back to the globally active run. */
export function currentRunForCaller(caller: Caller): string | null {
  return runForCaller(caller)?.runId ?? null;
}

export function agentFamiliesForCaller(input: Caller): Array<{ run_id: string; running: boolean }> {
  return familiesForCaller(input).map(owner => ({ run_id: familyKey(owner), running: 'runId' in owner }));
}

function requireEnabled(): void {
  if (!getConfig().multiAgent.enabled) {
    throw new AgentError('Multi-agent mode is switched off in Chat On Steroids. Ask the user to enable it.');
  }
}

/** The live agent bound to a conversation, prime included. */
function agentForConversationId(conversationId: string): Agent | null {
  const run = runForConversation(conversationId);
  if (!run) return null;
  if (conversationId === run.primeConversationId) return run.agents.get(PRIME_ID) ?? null;
  for (const agent of run.agents.values()) {
    if (agent.info.conversationId === conversationId && !isOver(agent.info.state)) return agent;
  }
  return null;
}

/**
 * Dormant ownership lookup by exact ChatGPT conversation, prime or worker.
 *
 * Conversation ids are bound exactly once, so a duplicate across owners would indicate
 * corrupted state. Fail closed by returning null rather than choosing an arbitrary owner in
 * that impossible shape.
 */
function dormantAgentForConversation(
  conversationId: string | null | undefined
): { owner: DormantRun; agent: Agent } | null {
  if (!conversationId) return null;
  let found: { owner: DormantRun; agent: Agent } | null = null;
  for (const dormant of dormantRuns.values()) {
    if (dormant.primeConversationId === conversationId) {
      const prime = dormant.agents.get(PRIME_ID);
      if (!prime || found) return null;
      found = { owner: dormant, agent: prime };
      continue;
    }
    for (const agent of dormant.agents.values()) {
      if (agent.info.role !== 'worker' || agent.info.conversationId !== conversationId) continue;
      if (found) return null;
      found = { owner: dormant, agent };
    }
  }
  return found;
}

/**
 * Reclaims one dormant owner into its own active incarnation.
 *
 * The worker family survives; the run incarnation does not. A fresh UUID is mandatory because
 * independently durable browser commands carry the old run id as their stale-command fence.
 */
function reactivateDormantRun(dormant: DormantRun): Run | null {
  if (dormantRuns.get(familyKey(dormant)) !== dormant) return null;
  // A parked family with an open handover belongs to the continuation moving its prime; it
  // comes back under the new prime chat when that commits, or here once it is cancelled.
  if (dormant.transfer) return null;
  const prime = dormant.agents.get(PRIME_ID);
  if (!prime) return null;
  dormantRuns.delete(familyKey(dormant));
  const now = Date.now();
  prime.info.state = 'active';
  prime.info.detachedAt = null;
  prime.info.lastSeenAt = now;
  const run: Run = {
    runId: randomUUID(),
    formerRunIds: boundedFormerRunIds([...(dormant.formerRunIds ?? []), familyKey(dormant)]),
    setupProfileId: dormant.setupProfileId,
    primeConversationId: dormant.primeConversationId,
    primeRequestId: dormant.primeRequestId,
    localOwnerId: dormant.localOwnerId,
    // The browser-command fence gets a new incarnation id, but this is still the same prime's
    // worker history. Keep the original history start instead of pretending the workers were
    // created again when one of them wakes.
    startedAt: dormant.startedAt,
    agents: dormant.agents,
    transfer: dormant.transfer,
    primeGoneAt: null
  };
  runs.set(run.runId, run);
  stampOwner(run);
  logInfo(`multi-agent: reactivated workers owned by conversation ${dormant.primeConversationId} as run ${run.runId}`);
  changed();
  return run;
}

/**
 * Kernel ingress hook: a proven tool call from a parked *sleeping* worker reclaims its family
 * independently of other primes, so that the noteAgentAlive() call right after it
 * can revive the worker the same way it would inside a live run.
 *
 * Inside a live run a sleeping worker that keeps calling is revived on the spot ("it never
 * actually stopped"). Parking happens the moment the last worker is thought asleep, so the
 * last worker of every run used to be refused WORKER_SLEEPING mid-turn for exactly the calls
 * that would have revived any of its siblings — on 2026-09-01 six workers hit that. Whether a
 * chat that is visibly running gets its tools must not depend on that bookkeeping accident.
 *
 * Nothing else reactivates here: a prime's ordinary calls, a finished or failed worker, or
 * a family whose prime is mid-handover leave the slot alone, and a lookup never reactivates.
 */
export function reactivateDormantRunForConversation(conversationId: string | null | undefined): boolean {
  if (runForConversation(conversationId) || !conversationId) return false;
  const found = dormantAgentForConversation(conversationId);
  if (!found || found.agent.info.role !== 'worker') return false;
  if (found.agent.info.state !== 'sleeping' || !found.agent.info.revivable) return false;
  return reactivateDormantRun(found.owner) !== null;
}

/** Turn identity retained after a ceiling-crossed worker is parked by ambiguous silence. */
export function silentCeilingRecoveryTurn(conversationId: string | null | undefined): string | null {
  if (!conversationId) return null;
  const agent = boundAgent(conversationId) ?? dormantAgentForConversation(conversationId)?.agent ?? null;
  return agent?.info.role === 'worker' && agent.info.state === 'sleeping' && !agent.info.revivable && agent.info.silenceParked
    ? agent.info.silenceRecoveryTurnId ?? null
    : null;
}

/** Pre-silence request/turn authority required before an MCP call may reclaim the worker slot. */
export function silentCeilingRecoveryAuthority(
  conversationId: string | null | undefined
): { turnId: string; requestOriginMax: number } | null {
  if (!conversationId) return null;
  const agent = boundAgent(conversationId) ?? dormantAgentForConversation(conversationId)?.agent ?? null;
  const turnId = agent?.info.silenceRecoveryTurnId ?? null;
  const requestOriginMax = agent?.info.silenceRecoveryRequestOriginMax;
  if (
    !agent ||
    agent.info.role !== 'worker' ||
    agent.info.state !== 'sleeping' ||
    agent.info.revivable ||
    !agent.info.silenceParked ||
    !turnId ||
    !Number.isFinite(requestOriginMax)
  ) {
    return null;
  }
  return { turnId, requestOriginMax: requestOriginMax! };
}

/**
 * Refusal for a context-limited worker whose old turn was parked by silence but whose arriving
 * call did not prove ownership of that exact turn. The marker is recovery eligibility, never
 * execution authority: a new turn in the same conversation must not inherit the old turn's tools.
 */
export function silentCeilingWorkerNotice(conversationId: string | null | undefined): string | null {
  if (!conversationId) return null;
  const agent = boundAgent(conversationId) ?? dormantAgentForConversation(conversationId)?.agent ?? null;
  if (
    !agent ||
    agent.info.role !== 'worker' ||
    agent.info.state !== 'sleeping' ||
    agent.info.revivable ||
    !agent.info.silenceParked
  ) {
    return null;
  }
  const recovery = silentCeilingRecoveryAuthority(conversationId);
  return (
    `WORKER_CONTEXT_LIMITED: ${agent.info.id} is parked because its previous turn went silent after reaching the context limit. ` +
    (recovery
      ? 'Nothing was run. New work is not allowed in this chat. Only a provenance-matched call from that exact unresolved turn may resume it; otherwise stop and return to the prime conversation.'
      : 'Nothing was run. New work is not allowed in this chat. No complete pre-park request/turn recovery proof was retained, so wait for durable terminal evidence and return to the prime conversation.')
  );
}

/**
 * Reclaims a ceiling-crossed worker only after the caller independently proved that the
 * arriving request belongs to the exact unresolved turn retained above.
 */
export function recoverSilentCeilingWorker(
  conversationId: string,
  turnId: string,
  announce = true
): AliveResult | null {
  let run = runForConversation(conversationId);
  let agent = boundAgent(conversationId);
  if (!agent) {
    const dormant = dormantAgentForConversation(conversationId);
    if (!dormant || !dormant.agent.info.silenceParked || dormant.agent.info.silenceRecoveryTurnId !== turnId) return null;
    run = reactivateDormantRun(dormant.owner);
    agent = run ? boundAgent(conversationId) : null;
  }
  if (
    !run ||
    !agent ||
    agent.info.role !== 'worker' ||
    agent.info.state !== 'sleeping' ||
    agent.info.revivable ||
    !agent.info.silenceParked ||
    agent.info.silenceRecoveryTurnId !== turnId
  ) {
    return null;
  }
  agent.info.state = 'active';
  agent.info.sleptAt = null;
  agent.info.finishedAt = null;
  agent.info.detachedAt = null;
  agent.info.silenceParked = false;
  agent.info.silenceRecoveryTurnId = null;
  agent.info.silenceRecoveryRequestOriginMax = null;
  agent.info.lastSeenAt = Date.now();
  const report = announce
    ? newMessage(
        agent.info.id,
        PRIME_ID,
        `[${agent.info.id} is still working] Its context-limited chat was parked after silence, but an exact call from the same unresolved turn arrived. It holds its worker slot again. Do not assign new work to this chat; wait for this turn to finish.`
      )
    : null;
  if (report) {
    const prime = primeAgent(run);
    prime.queue.push(report);
    recount(prime);
  }
  logInfo(`multi-agent: ${agent.info.id} resumed its exact ceiling-silenced turn ${turnId}`);
  changed('critical');
  return { agentId: agent.info.id, revived: true, report };
}

/**
 * Makes a parked owner's map available to the existing staged-finish barrier without granting
 * the worker execution authority. The row itself stays sleeping/context-fenced until commit.
 * Callers must independently hold terminal evidence.
 */
export function reactivateSilentCeilingRunForTerminal(
  conversationId: string | null | undefined
): boolean {
  if (!conversationId) return false;
  let agent = boundAgent(conversationId);
  if (agent) {
    return agent.info.role === 'worker' && agent.info.state === 'sleeping' &&
      !agent.info.revivable && agent.info.silenceParked === true && ceilingCrossed(agent.info);
  }
  const dormant = dormantAgentForConversation(conversationId);
  if (
    !dormant ||
    dormant.agent.info.role !== 'worker' ||
    dormant.agent.info.state !== 'sleeping' ||
    dormant.agent.info.revivable ||
    !dormant.agent.info.silenceParked ||
    !ceilingCrossed(dormant.agent.info)
  ) {
    return false;
  }
  if (!reactivateDormantRun(dormant.owner)) return false;
  agent = boundAgent(conversationId);
  return Boolean(agent && agent.info.state === 'sleeping' && agent.info.silenceParked);
}

/** Explicitly ends a ceiling-silenced worker, including while its family is parked. */
export function finishSilentCeilingWorker(
  conversationId: string | null | undefined,
  reason: string
): FinishResult | null {
  if (!conversationId) return null;
  const agent = boundAgent(conversationId) ?? dormantAgentForConversation(conversationId)?.agent ?? null;
  if (
    !agent ||
    agent.info.role !== 'worker' ||
    agent.info.state !== 'sleeping' ||
    !agent.info.silenceParked ||
    !ceilingCrossed(agent.info)
  ) {
    return null;
  }
  const report = finishStoppedWorkerAtCeiling(
    agent,
    reason,
    agent.info.sleptAt ?? Date.now()
  );
  changed('critical');
  return { info: { ...agent.info }, report: { ...report }, repeat: false };
}

/**
 * Caller-scoped history state. Unlike the renderer's global `swarmState()`, this never exposes
 * another prime's workers merely because that other prime currently owns the execution slot.
 */
export function swarmStateForCaller(caller: Caller): SwarmState {
  caller = exactCaller(caller);
  requireEnabled();
  if (!hasCallerIdentity(caller)) throw new IdentityLostError();
  requireMatchingSetupProfile(caller);
  const owned = familiesForCaller(caller).filter(owner => !caller.runId || answersTo(owner, caller.runId));
  return { enabled: true, running: owned.some(owner => 'runId' in owner),
    retainedHistory: owned.some(owner => !('runId' in owner)),
    agents: owned.flatMap(owner => stateForAgents(owner.agents, 'runId' in owner).agents) };
}

export interface CallerSwarmStatus {
  self: AgentInfo | null;
  state: SwarmState;
  /** Null while this owner's history is parked. */
  runId: string | null;
  /** Capacity available inside this caller's own worker family, before any optional global cap. */
  freeWorkerSlots: number;
}

/** One caller-scoped status snapshot, so no global run id/slot count can leak across owners. */
export function statusForCaller(caller: Caller): CallerSwarmStatus {
  caller = exactCaller(caller);
  const run = runForCaller(caller);
  requireEnabled();
  if (!hasCallerIdentity(caller)) throw new IdentityLostError();
  requireMatchingSetupProfile(caller);
  if (caller.runId && !selectedFamily(caller)) throw new AgentsBusyError();
  if (run) {
    const member = resolve(caller);
    if (member) {
      return {
        self: { ...member.info },
        state: stateForAgents(run.agents, true),
        runId: run.runId,
        freeWorkerSlots: freeWorkerSlots(run.runId)
      };
    }
  }
  const dormant = dormantRunForCaller(caller);
  const member = dormant && (ownsPrime(caller, dormant) ? dormant.agents.get(PRIME_ID) :
    [...dormant.agents.values()].find(agent => agent.info.role === 'worker' && agent.info.conversationId === caller.conversationId));
  if (dormant && member) {
    return {
      self: { ...member.info },
      state: stateForAgents(dormant.agents, false),
      runId: null,
      freeWorkerSlots: getConfig().multiAgent.maxWorkers
    };
  }
  return { self: null, state: stateForAgents(new Map(), false, false), runId: null,
    freeWorkerSlots: getConfig().multiAgent.maxWorkers };
}

/**
 * Who is calling, or null.
 *
 * One lookup, because there is one identity: the conversation this call was proven to come
 * from. A call that could not be placed in a conversation belongs to nobody, and saying so
 * is what keeps an unidentified call from being filed under whichever agent was busiest.
 */
function resolve(caller: Caller): Agent | null {
  caller = exactCaller(caller);
  const run = runForCaller(caller);
  if (!run) return null;
  if (ownsPrime(caller, run)) return run.agents.get(PRIME_ID) ?? null;
  return [...run.agents.values()].find(agent => agent.info.conversationId === caller.conversationId && !isOver(agent.info.state)) ?? null;
}

/** Attribution for an ordinary tool call: only ever a binding, never a claim. */
export function agentForCaller(caller: Caller): string | null {
  if (!getConfig().multiAgent.enabled) return null;
  if (!caller.runId && familiesForCaller(caller).some(owner => ownsPrime(exactCaller(caller), owner))) return PRIME_ID;
  return resolve(caller)?.info.id ?? null;
}

/**
 * Identity for the one control call a terminal worker is allowed to retry: `agents finish`.
 *
 * Ordinary resolution deliberately hides terminal workers so an ended chat cannot keep using
 * local tools as a live member of the run. A lost `finish` result is different: the broker must
 * recognise the same conversation's tombstone so the dispatcher can re-offer anything that
 * rode on that lost result without reviving the worker or authorising another action.
 *
 * Keep this as a separate lookup rather than widening {@link agentForCaller}. The dispatcher
 * selects it only for the literal finish action; every other call retains the fail-closed live
 * membership rule.
 */
export function agentForFinishCaller(caller: Caller): string | null {
  if (!getConfig().multiAgent.enabled) return null;
  return (resolve(caller) ?? retiredAgent(caller))?.info.id ?? null;
}

/**
 * Resolves the caller to a member of the active run, or refuses in the one honest way.
 *
 * Three refusals, deliberately different. A caller with no run at all is told how to start
 * one. A chat that *was* identified and is not in the run learns only `AGENTS_BUSY` — never
 * who the prime is, how many workers there are, or what they are doing. And a call whose
 * conversation could not be established at all is a different failure entirely: it is not a
 * stranger, it is an agent whose identity this app could not read, so it is told that in
 * those words rather than being handed a credential to carry instead.
 */
/**
 * This install's Core connector, named in agent protocol text when a computer name is set (#1091).
 * One ChatGPT account then holds several computers' Cores, and a worker told only "the agents
 * tool" reported to the other computer's Core (seen live, 2026-10-04: refused there as "no run").
 */
export function ownCoreHint(): string {
  return getConfig().connectorSuffix ? ` of ${liveConnectorName('core')}` : '';
}

function requireMember(caller: Caller): Agent {
  caller = exactCaller(caller);
  const run = runForCaller(caller);
  requireEnabled();
  if (!hasCallerIdentity(caller)) throw new IdentityLostError();
  if (!run && runs.size > 0) throw new AgentsBusyError();
  if (!run) {
    throw new AgentError(
      `No sub-agent run is active in ${liveConnectorName('core')}. ` +
        'The chat that calls agents action=spawn becomes the prime agent of a new run.'
    );
  }
  const agent = resolve(caller);
  if (!agent) throw new AgentsBusyError();
  return agent;
}

/** Resolves who is calling, or refuses with something the model can act on. */
export function identify(caller: Caller): AgentInfo {
  caller = exactCaller(caller);
  requireEnabled();
  if (!hasCallerIdentity(caller)) throw new IdentityLostError();
  const active = resolve(caller);
  if (active) return { ...active.info };
  const dormant = dormantRunForCaller(caller);
  const prime = dormant?.agents.get(PRIME_ID);
  if (prime) return { ...prime.info };
  if (runs.size > 0) throw new AgentsBusyError();
  throw new AgentError(
    'No sub-agent run or worker history belongs to this conversation. Call agents action=spawn to start one.'
  );
}

// -------------------------------------------------------------------- state

/**
 * The one message a worker is opened with: the run's shared context, then its own task.
 *
 * Labelled, because the two halves are addressed differently — the context is standing
 * instruction for everyone in the run, the task is this worker's job — and a worker that
 * cannot tell them apart is one that reports back on the house rules.
 */
const briefFor = workerBrief;
function makeWorker(id: string, label: string, task: string, model: string | null, reasoningEffort: ReasoningEffort | null): Agent {
  return {
    info: {
      id,
      role: 'worker',
      label,
      task,
      jobTitle: (workerOwnTask(task).split(/[\r\n]/, 1)[0]?.trim() ?? '').slice(0, 160) || undefined,
      model,
      reasoningEffort,
      state: 'invited',
      createdAt: Date.now(),
      activatedAt: null,
      finishedAt: null,
      result: null,
      pending: 0,
      awaitingAck: 0,
      delivered: 0,
      conversationId: null,
      detachedAt: null,
      lastSeenAt: null,
      revivable: false,
      silenceParked: false,
      silenceRecoveryTurnId: null,
      silenceRecoveryRequestOriginMax: null,
      sleptAt: null,
      contextTokens: 0
    },
    queue: []
  };
}

function makePrime(conversationId: string | null): Agent {
  return {
    info: {
      id: PRIME_ID,
      role: 'prime',
      label: 'Prime',
      task: 'Coordinates the workers',
      model: null,
      reasoningEffort: null,
      state: 'active',
      createdAt: Date.now(),
      activatedAt: Date.now(),
      finishedAt: null,
      result: null,
      pending: 0,
      awaitingAck: 0,
      delivered: 0,
      conversationId,
      detachedAt: null,
      lastSeenAt: Date.now(),
      revivable: false,
      silenceParked: false,
      silenceRecoveryTurnId: null,
      silenceRecoveryRequestOriginMax: null,
      sleptAt: null,
      contextTokens: 0
    },
    queue: []
  };
}

// --------------------------------------------------------------------- slots

/** Workers currently holding one of the run's slots, awake or being woken. */
function workingWorkers(run: Run | null): Agent[] {
  if (!run) return [];
  return [...run.agents.values()].filter(
    (agent) => agent.info.role === 'worker' && occupiesSlot(agent.info.state) && !unpublishedAgents.has(agent)
  );
}

/**
 * How many more workers this run may have awake at once.
 *
 * Sleeping workers are deliberately not counted. A run that has spawned eight workers and put
 * seven of them to sleep has seven free slots and eight chats it can go back to, which is the
 * whole shape this mode is now built around.
 */
export function freeWorkerSlots(runId?: string): number {
  const run = scopedRun(runId);
  if (!run) return runId === undefined && runs.size === 0 ? getConfig().multiAgent.maxWorkers : 0;
  return Math.max(0, getConfig().multiAgent.maxWorkers - workingWorkers(run).length);
}

/**
 * Slot-holding workers across every active prime family, including a staged spawn that has
 * reserved topology but has not crossed its durable publication barrier yet.
 *
 * Public caller status deliberately excludes those staged rows and stays family-scoped. Global
 * admission cannot: two independent primes may stage concurrently, so ignoring an unpublished
 * reservation here would let both calls accept the same final global slot.
 */
function globalOccupiedWorkerSlots(): number {
  let occupied = 0;
  for (const run of runs.values()) {
    for (const agent of run.agents.values()) {
      if (agent.info.role === 'worker' && occupiesSlot(agent.info.state)) occupied += 1;
    }
  }
  return occupied;
}

/** Remaining broker-wide worker admissions, or Infinity while the opt-in cap is disabled. */
function globalFreeWorkerSlots(): number {
  const limit = getConfig().multiAgent.globalMaxWorkers ?? 0;
  if (limit <= 0) return Number.POSITIVE_INFINITY;
  return Math.max(0, limit - globalOccupiedWorkerSlots());
}

/**
 * Whether the family owning this conversation still has workers holding a slot.
 *
 * A prime that delegated work is not finished with it: the next step it asks for would be
 * decided and typed into the same chat while its own workers are still running. This is the
 * same accounting `freeWorkerSlots` and `parkRun` already use, including a worker that is
 * mid-spawn and about to be real — a reservation is work. A conversation with no family
 * resolves no run and is never busy: unknown ownership must not be able to block a chat
 * that has no workers to wait for.
 */
function familyWorkersBusy(conversationId: string | null | undefined): boolean {
  return workingWorkers(runForConversation(conversationId)).length > 0;
}

/**
 * Whether this chat's automatic next step is deliberately waiting for its own workers.
 *
 * A prime that delegated half its task is not finished with it. Its workers report back into
 * this same conversation, so asking for the next Goal/Loop step while they run decides it from
 * a context that is about to change and then types the instruction into a chat that is still
 * being worked on. Off by default: a chat with no run, and a run with no workers, behave
 * exactly as they did before.
 *
 * This is the one rule, owned here because worker state lives here. The page asks it over
 * `/goal/draft`, the pickup tree asks it through `owedPickups`, and both describe the wait to
 * the user through the same `goalWaitFor` reason.
 */
export function waitingForSubAgents(conversationId: string | null | undefined): boolean {
  return getConfig().multiAgent.waitForSubAgents === true && familyWorkersBusy(conversationId);
}

function recount(agent: Agent): void {
  const live = agent.queue.filter((message) => message.ackedAt === null && !unpublishedMessages.has(message));
  agent.info.pending = live.length;
  agent.info.awaitingAck = live.filter((message) => message.offeredAt !== null).length;
}

function primeAgent(run: Run | null): Agent {
  const agent = run?.agents.get(PRIME_ID);
  if (!agent) throw new AgentError('No sub-agent run is active.');
  return agent;
}

/**
 * Ends the run: agents, queues, credentials, and — through the end listeners — any worker
 * bootstrap the browser has not opened yet.
 *
 * Half-clearing is what produced the worst observed behaviour, a browser opening tabs for
 * workers of a run that no longer had a prime to report to.
 */
function endRun(run: Run, reason: string): void {
  if (!run) return;
  retireManagedWorktreeCleanupOffers(run.agents.values(), 'cleared');
  // The prime's tool calls switch from `agent:prime` back to its conversation identity the
  // instant this run disappears. Collapse that temporary workspace identity first so the next
  // relative path cannot revive the project the chat was using before it spawned workers.
  releasePrimeWorkspace(run.primeConversationId, run.runId);
  const retired: RetiredChat[] = [...run.agents.values()]
    // Keep the conversation fence after the active-run tombstone disappears. A terminal
    // worker is still a worker chat: `finish` stops its broker role, not the ChatGPT turn or
    // document itself. Once the prime ACKs the final report, releaseQuiescentRun() destroys the
    // run, so excluding finished/failed workers here also destroyed the only identity record
    // that made endedWorkerNotice() reject their later local-tool calls. The kernel's retired
    // lease is the post-run continuation of that same boundary and therefore applies to every
    // worker conversation the run had bound, terminal or not.
    .filter((agent) => agent.info.role === 'worker' && agent.info.conversationId)
    .map((agent) => ({
      id: agent.info.id,
      conversationId: agent.info.conversationId as string,
      reason,
      retiredAt: Date.now()
    }));
  for (const worker of retired) retiredWorkers.set(worker.conversationId, worker);
  for (const agent of run.agents.values()) {
    if (agent.info.role === 'worker' && agent.info.managedWorktree && agent.info.conversationId)
      retiredManagedWorkerConversations.add(agent.info.conversationId);
  }
  retiredPersist?.();
  const what = `${run.runId} (${[...run.agents.keys()].join(', ')})`;
  runs.delete(run.runId);
  for (const worker of retired) { consecutiveWakeFailures.delete(worker.conversationId); transientWakeRetries.delete(worker.conversationId); }
  logInfo(`multi-agent: ended run ${what} — ${reason}`);
  for (const listener of endListeners) listener(reason, retired, run.runId);
  announceRetired(retired.map((worker) => worker.conversationId));
}

/**
 * Parks the active incarnation while preserving the prime's complete worker
 * history. No worker is retired and no browser command is cancelled here: callers may park
 * only after every slot-holder (invited/active/detached/waking) is gone.
 */
function parkRun(run: Run | null, reason: string): boolean {
  if (!run || workingWorkers(run).length > 0) return false;
  const current = run;
  releasePrimeWorkspace(current.primeConversationId, current.runId);
  dormantRuns.set(familyKey(current), {
    formerRunIds: current.formerRunIds,
    setupProfileId: current.setupProfileId,
    primeConversationId: current.primeConversationId,
    primeRequestId: current.primeRequestId,
    localOwnerId: current.localOwnerId,
    startedAt: current.startedAt,
    parkedAt: Date.now(),
    agents: current.agents,
    transfer: current.transfer
  });
  runs.delete(run.runId);
  logInfo(
    `multi-agent: parked run ${current.runId} for conversation ${current.primeConversationId} — ${reason}`
  );
  pruneDormantRuns();
  changed();
  return true;
}

/**
 * Drops parked families past DORMANT_RUN_TTL_MS or beyond MAX_DORMANT_RUNS, oldest parked
 * first. A family whose prime is mid-handover is never dropped: the continuation owns it.
 * Evicted worker chats keep the ordinary retired-worker fence so a stale tab cannot become an
 * anonymous chat with tools the moment its history is forgotten.
 */
function pruneDormantRuns(now = Date.now()): boolean {
  const candidates = [...dormantRuns.values()]
    .filter((dormant) => !dormant.transfer)
    .sort((a, b) => a.parkedAt - b.parkedAt);
  const evict = candidates.filter(
    (dormant, index) => now - dormant.parkedAt >= DORMANT_RUN_TTL_MS || candidates.length - index > MAX_DORMANT_RUNS
  );
  if (evict.length === 0) return false;
  const expired: string[] = [];
  for (const dormant of evict) {
    dormantRuns.delete(familyKey(dormant));
    retireManagedWorktreeCleanupOffers(dormant.agents.values(), 'evicted');
    for (const agent of dormant.agents.values()) {
      if (agent.info.role !== 'worker' || !agent.info.conversationId) continue;
      if (agent.info.managedWorktree) retiredManagedWorkerConversations.add(agent.info.conversationId);
      retiredWorkers.set(agent.info.conversationId, {
        id: agent.info.id,
        conversationId: agent.info.conversationId,
        reason: 'its parked worker history was dropped',
        retiredAt: now
      });
      expired.push(agent.info.conversationId);
    }
    logInfo(`multi-agent: dropped the parked worker history of ${dormant.primeConversationId ? `conversation ${dormant.primeConversationId}` : 'a prime chat that never got a conversation'}`);
  }
  retiredPersist?.();
  // These workers are retired for good too: the archive setting (#1460) must hear about them.
  announceRetired(expired);
  return true;
}

function pruneRetiredWorkers(): void {
  const cutoff = Date.now() - RETIRED_WORKER_TTL_MS;
  let changed = false;
  for (const [conversationId, worker] of retiredWorkers) {
    if (worker.retiredAt >= cutoff) continue;
    retiredWorkers.delete(conversationId);
    changed = true;
  }
  if (changed) retiredPersist?.();
}

export function retiredWorkerForConversation(conversationId: string | null | undefined): RetiredChat | null {
  pruneRetiredWorkers();
  if (!conversationId) return null;
  const worker = retiredWorkers.get(conversationId);
  return worker ? { ...worker } : null;
}

export function hasRetiredWorkerLeases(): boolean {
  pruneRetiredWorkers();
  return retiredWorkers.size > 0;
}

// -------------------------------------------------------------------- spawn

export interface SpawnInput {
  workers: ReadonlyArray<{ label?: string; task: string; model?: string | null; reasoning_effort?: string | null }>;
  /**
   * What every worker in this spawn needs to know, written once.
   *
   * A worker starts with none of the prime's conversation, so the repository, the house
   * rules, the branch, the things it must not touch and how to validate had to be repeated
   * inside every single task. That is the prime paying output tokens to say the same
   * paragraph four times, and it is the paragraph most likely to drift between copies.
   * Written here, this app puts it in front of each worker's own task instead.
   */
  context?: string | null;
  caller: Caller;
}

export interface SpawnResult {
  created: AgentInfo[];
  /** True on the call that established the run, so the caller can say what happened. */
  becamePrime: boolean;
  runId: string;
  /** App defaults from Settings that this account does not offer, and what was used instead. */
  defaultNotes?: string[];
}

/**
 * A spawn planned in memory but not yet accepted publicly.
 *
 * The immediate persistence lane can see this topology; ordinary/debounced snapshots and
 * browser bootstrap readers cannot until commit. Rollback removes the plan and emits a newer
 * safe snapshot, exactly like staged agent messages.
 */
export interface StagedSpawn extends SpawnResult {
  /** A replay of already accepted workers does not own a new allocation. */
  newlyStaged: boolean;
  /** Exact newly reserved workers, excluding existing matches and sleeping workers. */
  newlyStagedWorkerIds: readonly string[];
  /** Makes this stage eligible for critical snapshots only after resource setup completes. */
  prepareDurability: () => void;
  commit: () => void;
  rollback: () => void;
}

interface SpawnOptions {
  /** Keep browser side effects behind an explicit durable acceptance barrier. */
  deferDelivery?: boolean;
  /** Internal half of stageSpawn(): hide new topology from ordinary publication until commit. */
  stageTopology?: boolean;
}

function settleSpawnStage(stage: SpawnStageState, accepted: boolean): void {
  if (stage.settled) return;
  stage.settled = true;
  if (activeSpawnStages.get(stage.run) === stage) activeSpawnStages.delete(stage.run);
  for (const agent of stage.created) unpublishedAgents.delete(agent);
  unpublishedRuns.delete(stage.run);

  if (accepted) {
    // The exact topology already crossed the immediate durable barrier. Publishing it changes
    // only live readers and the ordinary/debounced mirror, not the critical durability revision.
    if (runs.get(stage.run.runId) === stage.run) changed('telemetry');
    return;
  }

  const run = stage.run;
  if (runs.get(stage.run.runId) === stage.run) {
    for (const agent of stage.created) {
      if (run.agents.get(agent.info.id) === agent) run.agents.delete(agent.info.id);
    }
    // A rejected first spawn had no accepted owner state at all; a rejected spawn into dormant
    // history must instead put that exact history back where it came from. Treating both as
    // `run = null` loses every old worker of the resumed prime.
    if (stage.createdFreshRun) {
      runs.delete(run.runId);
    } else if (stage.resumedDormant) {
      const current = run;
      releasePrimeWorkspace(current.primeConversationId, current.runId);
      dormantRuns.set(familyKey(stage.resumedDormant), {
        ...stage.resumedDormant,
        agents: current.agents,
        transfer: current.transfer
      });
      runs.delete(run.runId);
    }
    // A failed write generation can remain queued for retry in durable.ts. This newer public
    // snapshot supersedes it so a rejected spawn cannot resurrect after restart.
    changed();
  }
}

/**
 * Normalizes a worker's requested ChatGPT model slug: trimmed, or null for the account
 * default when omitted or blank.
 *
 * Malformed input fails the whole spawn rather than opening a worker under a model nobody
 * asked for: like every other spawn validation, this runs before the first mutation, so a
 * rejection leaves zero workers behind. Account membership is checked separately once
 * both requested settings have been resolved.
 */
function normalizeModel(index: number, value: string | null | undefined): string | null {
  if (value === undefined || value === null) return null;
  const model = value.trim();
  if (!model) return null;
  if (!isModelSlug(model)) {
    throw new AgentError(
      `Worker ${index + 1}'s model is not a ChatGPT model slug (letters, digits, dot, underscore, hyphen; limit ${MAX_MODEL_CHARS} characters)`
    );
  }
  return model;
}

/**
 * Whether a string is shaped like a ChatGPT model slug. The single vocabulary check for
 * worker models, shared by the broker and the bridge's durable restore. Syntax does not
 * prove availability; admission checks observed choices and the browser confirms at Send.
 */
export function isModelSlug(value: unknown): value is string {
  return typeof value === 'string' && MODEL_SLUG_RE.test(value);
}

/**
 * Normalizes a worker's requested reasoning level: trimmed and lowercased, or null to
 * inherit the default when omitted or blank.
 *
 * Unknown values fail the whole spawn rather than opening a worker under a level nobody
 * asked for: like every other spawn validation, this runs before the first mutation, so
 * a rejection leaves zero workers behind. There is deliberately no silent downgrade to a
 * default — a status line claiming one level while the worker runs another is exactly the
 * lie this refuses to tell.
 */
function normalizeReasoningEffort(index: number, value: string | null | undefined): ReasoningEffort | null {
  if (value === undefined || value === null) return null;
  const effort = value.trim().toLowerCase();
  if (!effort) return null;
  if (!isReasoningEffort(effort)) {
    throw new AgentError(
      `Worker ${index + 1}'s reasoning_effort must be one of: ${REASONING_EFFORTS.join(', ')}`
    );
  }
  return effort;
}

/** Reject known-invalid choices before reserving any workers or opening browser documents. */
/**
 * Drops an app default that the observed catalog does not offer, instead of failing the spawn.
 *
 * Explicit tool arguments stay strict (validateWorkerModel below). A default saved in Settings is
 * different: after 2.1.15 read model ids from the picker's lanes, a default saved earlier (for
 * example a display slug) could stop matching, and every spawn in the account then failed until
 * someone found the setting (#499). The worker runs with ChatGPT's current selection instead;
 * its row records no model, so nothing claims a model it does not run, and the caller is told.
 */
function usableDefaults(
  model: string | null, effort: ReasoningEffort | null, defaultModel: boolean, defaultEffort: boolean,
  models: ChatModelOption[], notes: Set<string>
): { model: string | null; effort: ReasoningEffort | null } {
  if (!models.length) return { model, effort };
  // A saved display label resolves to its unique observed family before the offer
  // check, same as the Settings badge. Exact ids and lane aliases keep their lane; a
  // resolved label canonicalizes to the family. An ambiguous label stays a dropped default.
  const resolved = defaultModel && model ? resolveChatModel(models, model) : undefined;
  if (defaultModel && model && !resolved) {
    notes.add(`The default worker model "${model}" saved in Settings is not offered by this ChatGPT account, so workers use ChatGPT's current model. Choose an available model in Settings → Agents & automation.`);
    model = null;
  } else if (resolved && resolved.id !== model && !resolved.aliases?.includes(model!)) model = resolved.id;
  const offered = model ? (resolved ? [resolved] : models.filter(choice => choice.id === model || choice.aliases?.includes(model!))) : models;
  if (defaultEffort && effort && !offered.some(choice => choice.efforts.includes(effort!))) {
    notes.add(`The default worker reasoning "${effort}" saved in Settings is not offered${model ? ` for model "${model}"` : ''} by this ChatGPT account, so workers use ChatGPT's current reasoning. Choose an available level in Settings → Agents & automation.`);
    effort = null;
  }
  if (notes.size) refreshForUnoffered(`default worker ${[...notes].join(',')}`);
  return { model, effort };
}

function validateWorkerModel(index: number, model: string | null, effort: ReasoningEffort | null, models: ChatModelOption[]): void {
  // No observation is not an empty entitlement list. Preserve the requested settings for
  // native confirmation; never guess an account default or manufacture a model alias.
  if (!models.length) return;
  const choices = model ? models.filter(choice => choice.id === model || choice.aliases?.includes(model)) : models;
  const available = models.map(choice => `${choice.id} (${choice.efforts.join(', ')})`).join('; ');
  if (model && choices.length !== 1) {
    throw new AgentError(`Worker ${index + 1}'s model "${model}" is ${choices.length ? 'ambiguous' : 'not observed'} in the ChatGPT account. Observed model ids and reasoning: ${available}`);
  }
  if (effort && !choices.some(choice => choice.efforts.includes(effort))) {
    throw new AgentError(`Worker ${index + 1}'s reasoning_effort "${effort}" is not observed${model ? ` for model "${model}"` : ' in the ChatGPT account'}. Observed model ids and reasoning: ${available}`);
  }
  // Keep provider aliases exact: reducing a lane-specific slug to its family without an
  // explicit effort can change the requested lane. The native picker still proves the pair.
}

/**
 * Plans a worker spawn behind the same durable acceptance boundary used by agents::message.
 *
 * Production must call persistCriticalSwarmNow(), then commit() on success or rollback() on
 * any failure, and only after commit ask the browser to open the returned worker ids.
 */
export function stageSpawn(input: SpawnInput): StagedSpawn {
  const result = spawn(input, { deferDelivery: true, stageTopology: true });
  const owner = runs.get(result.runId);
  const stage = owner ? activeSpawnStages.get(owner) : undefined;
  // An exact retry can match workers that were already accepted earlier. That is not a new
  // mutation and therefore needs no publication transaction.
  if (!stage) return { ...result, newlyStaged: false, newlyStagedWorkerIds: [], prepareDurability: () => undefined, commit: () => undefined, rollback: () => undefined };
  return {
    ...result,
    newlyStaged: true,
    newlyStagedWorkerIds: stage.created.map(agent => agent.info.id),
    prepareDurability: () => {
      if (stage.settled || activeSpawnStages.get(stage.run) !== stage) {
        throw new AgentError('SPAWN_STAGE_EXPIRED: the worker reservation is no longer pending');
      }
      if (stage.durableReady) return;
      stage.durableReady = true;
      // B's in-flight writer could have flushed before this stage completed allocation.
      // A new revision forces A's own acceptance barrier to publish its prepared topology.
      changed();
    },
    commit: () => settleSpawnStage(stage, true),
    rollback: () => settleSpawnStage(stage, false)
  };
}

/** A worktree lease is durable only after this same staged spawn crosses its write barrier. */
export function markStagedWorkerWorktree(runId: string, agentId: string): void {
  const run = runs.get(runId);
  const stage = run ? activeSpawnStages.get(run) : undefined;
  const agent = stage?.created.find(worker => worker.info.id === agentId);
  if (!stage || stage.settled || !agent || agent.info.role !== 'worker') {
    throw new AgentError('WORKTREE_OWNER_NOT_STAGED: only a newly reserved worker may claim a managed worktree');
  }
  if (agent.info.workerAllocationRunId !== runId) {
    throw new AgentError('WORKTREE_OWNER_MISMATCH: worker allocation identity changed during staging');
  }
  agent.info.managedWorktree = true;
  managedWorktreeHistoryPossible = true;
  // Another family's acceptance writer may already be draining the staged topology. This
  // policy change needs its own critical revision so that writer cannot certify an earlier
  // snapshot lacking the worktree requirement as the final accepted spawn state.
  changed();
}

/** Require isolation only for workers whose accepted broker record says it was allocated. */
export function managedWorkerWorktreeRequired(input: Caller): boolean {
  if (!managedWorktreeHistoryPossible) return false;
  const caller = exactCaller(input);
  if (!caller.conversationId) return false;
  // Even a corrupt or multiply claimed restored conversation must retain its isolation
  // requirement. Ambiguous identity must fail instead of reaching the prime's project.
  return allFamilies().some(owner => [...owner.agents.values()].some(member =>
    member.info.role === 'worker' && member.info.conversationId === caller.conversationId &&
    member.info.managedWorktree === true));
}

/**
 * The managed allocation is an accepted broker fact, not a property of a worker-origin
 * recording. Legacy workers never allocated a worktree and retain their original cwd, even
 * after their broker history expires. An isolated worker, by contrast, must remain fenced
 * after its family and ordinary retired lease expire. The snapshot's exact-chat tombstones
 * survive those limits even when recording is Off; they never restore checkout ownership.
 *
 * This is a synchronous, in-memory check on every workspace lookup. In particular, it must
 * not touch the session store: ordinary chats and pre-feature worker chats can call this
 * before the session store is initialized, or after their histories have been pruned.
 */
export function managedWorkerIsolationRequired(input: Caller): boolean {
  if (!managedWorktreeHistoryPossible && retiredManagedWorkerConversations.size === 0) return false;
  const caller = exactCaller(input);
  if (managedWorkerWorktreeRequired(caller)) return true;
  return Boolean(caller.conversationId && retiredManagedWorkerConversations.has(caller.conversationId));
}

/**
 * A marker may be restored only if the accepted broker still owns a worker that could execute.
 * Retained terminal rows remain isolation fences and cleanup offers, never startup leases.
 * A non-revivable sleeper can still finish its original turn only with the exact durable
 * turn/request authority captured when it was parked at the context ceiling.
 * This projection never reconstructs ownership from marker filenames, display slots or
 * recorded sessions. Duplicate/corrupt allocation identities are excluded fail-closed.
 */
export function managedWorkerRecoveryIdentities(): Array<{ runId: string; agentId: string }> {
  const families = allFamilies();
  const candidates = families.flatMap(owner => [...owner.agents.values()]
    .filter(agent => agent.info.role === 'worker' && agent.info.managedWorktree === true &&
      !cleanupAcknowledged(agent.info) &&
      managedAllocationAgentPattern.test(agent.info.id) &&
      (occupiesSlot(agent.info.state) ||
        (agent.info.state === 'sleeping' && (agent.info.revivable === true ||
          (agent.info.silenceParked === true && Boolean(agent.info.conversationId) &&
            Boolean(agent.info.silenceRecoveryTurnId) &&
            Number.isFinite(agent.info.silenceRecoveryRequestOriginMax))))) &&
      !unpublishedAgents.has(agent) && !unpublishedRuns.has(owner as Run))
    .map(agent => ({ runId: agent.info.workerAllocationRunId, agentId: agent.info.id, owner })));
  return candidates.filter(candidate =>
    typeof candidate.runId === 'string' &&
    managedAllocationRunPattern.test(candidate.runId) &&
    candidates.filter(other => other.runId === candidate.runId && other.agentId === candidate.agentId).length === 1 &&
    families.filter(owner => owner.agents.get(candidate.agentId)?.info.workerAllocationRunId === candidate.runId).length === 1
  ).map(candidate => ({ runId: candidate.runId!, agentId: candidate.agentId }));
}

/** Resolve worktree identity solely from unique, published, broker-owned conversation proof. */
export function managedWorkerAllocationIdentity(input: Caller): { runId: string; agentId: string } | null {
  const caller = exactCaller(input);
  if (!caller.conversationId) return null;
  const member = resolve({ ...caller, runId: undefined });
  if (!member || member.info.role !== 'worker' || member.info.conversationId !== caller.conversationId ||
      member.info.managedWorktree !== true || unpublishedAgents.has(member)) return null;
  const owner = runForAgent(member);
  if (!owner || unpublishedRuns.has(owner)) return null;
  const allocation = member.info.workerAllocationRunId;
  if (typeof allocation !== 'string' || !managedAllocationRunPattern.test(allocation)) return null;
  const owners = allFamilies().filter(family =>
    family.agents.get(member.info.id)?.info.workerAllocationRunId === allocation);
  if (owners.length !== 1 || owners[0] !== owner) return null;
  return { runId: allocation, agentId: member.info.id };
}

/**
 * The bridge redeems a worker's first browser message before that worker has a conversation
 * id. Its durable spawn command has the exact broker run + worker id instead. Never infer a
 * checkout from the display slot or Prime's project: only this published worker can name its
 * immutable allocation identity. A corrupt managed owner must not fall back to Prime's cwd.
 */
export function workerBootstrapWorktreeIdentity(runId: string, agentId: string): { runId: string; agentId: string } | null {
  const run = runs.get(runId);
  const member = run?.agents.get(agentId);
  // A leased bootstrap can be redeemed again by its original browser document after
  // binding was durably accepted but the HTTP reply was lost. Bridge command restoration
  // already permits that exact `active` state; do not break that existing recovery path.
  const awaitingBootstrap = member?.info.state === 'invited' ||
    ((member?.info.state === 'waking' || member?.info.state === 'active') && Boolean(member.info.conversationId));
  if (!run || unpublishedRuns.has(run) || !member || unpublishedAgents.has(member) ||
      member.info.role !== 'worker' || !awaitingBootstrap) {
    throw new AgentError('WORKTREE_BOOTSTRAP_OWNER_UNAVAILABLE: worker has no published bootstrap or revival owner in this run');
  }
  if (member.info.managedWorktree !== true) return null;
  const allocation = member.info.workerAllocationRunId;
  if (!allocation || !managedAllocationRunPattern.test(allocation) ||
      allFamilies().filter(owner => owner.agents.get(agentId)?.info.workerAllocationRunId === allocation).length !== 1) {
    throw new AgentError('WORKTREE_BOOTSTRAP_OWNER_INVALID: managed worker allocation identity could not be proven');
  }
  return { runId: allocation, agentId };
}

/**
 * Publishes browser bootstraps only for worker ids that are still genuinely invited.
 *
 * Production MCP spawn uses this as the second half of its transaction: broker state is
 * planned first, that exact revision is made durable, and only then are browser tabs requested.
 * A retry after a failed disk barrier is safe because already-running workers are ignored.
 */
export function requestWorkerBootstraps(ids: readonly string[], runId?: string): number {
  const run = scopedRun(runId);
  if (!run || ids.length === 0) return 0;
  const wanted = new Set(ids);
  const owed = [...run.agents.values()]
    .filter(
      (agent) =>
        agent.info.role === 'worker' &&
        agent.info.state === 'invited' &&
        !unpublishedAgents.has(agent) &&
        wanted.has(agent.info.id)
    )
    .map((agent) => ({ runId: run.runId, primeConversationId: run.primeConversationId, id: agent.info.id, task: agent.info.task, model: agent.info.model, reasoningEffort: agent.info.reasoningEffort }));
  if (owed.length === 0) return 0;
  if (spawnRequest) spawnRequest(owed);
  else logWarn('multi-agent: no browser extension is paired, so worker chats cannot be opened automatically');
  return owed.length;
}

/**
 * Claims the calling conversation as prime and creates its workers, atomically.
 *
 * Every step that can fail happens before the first mutation, in a fixed order:
 *
 *   1. the request itself is valid (all of it, not the prefix that happened to parse);
 *   2. this app has *proven* which conversation is calling;
 *   3. that conversation is not a worker of the active run;
 *   4. this owner's quota and topology transaction permit the complete request;
 *   5. only then is the prime bound and the workers created.
 *
 * So a spawn that fails for any reason leaves zero workers behind, and no conversation ever
 * becomes prime as a by-product of some other outcome.
 */
export function spawn(input: SpawnInput, options: SpawnOptions = {}): SpawnResult {
  requireEnabled();
  input = { ...input, caller: exactCaller(input.caller) };
  requireFamilySelection(input.caller);
  let run = runForCaller(input.caller, true);
  if (run && activeSpawnStages.has(run)) {
    throw new AgentError(
      'SPAWN_IN_PROGRESS: another worker spawn is still crossing its durable acceptance barrier. Retry this spawn after that call finishes.'
    );
  }
  const max = getConfig().multiAgent.maxWorkers;
  if (input.workers.length === 0) throw new AgentError('At least one worker is required');

  const context = input.context?.trim() ?? '';
  if (context.length > MAX_CONTEXT_CHARS) {
    throw new AgentError(`The shared context is too long (limit ${MAX_CONTEXT_CHARS} characters)`);
  }

  const observedModels = getChatModels().models;
  const defaultNotes = new Set<string>();
  const planned = input.workers.map((worker, index) => {
    const task = worker.task.trim();
    if (!task) throw new AgentError(`Worker ${index + 1} has no task. Every worker needs one.`);
    if (task.length > MAX_TASK_CHARS) throw new AgentError(`Worker ${index + 1}'s task is too long`);
    const label = worker.label?.trim() ?? '';
    if (label.length > MAX_LABEL_CHARS) {
      throw new AgentError(`Worker ${index + 1}'s label is too long (limit ${MAX_LABEL_CHARS} characters)`);
    }
    const requested = usableDefaults(
      normalizeModel(index, worker.model === undefined ? getConfig().multiAgent.defaultModel : worker.model),
      normalizeReasoningEffort(index, worker.reasoning_effort === undefined ? getConfig().multiAgent.defaultReasoning : worker.reasoning_effort),
      worker.model === undefined, worker.reasoning_effort === undefined, observedModels, defaultNotes);
    const model = requested.model, reasoningEffort = requested.effort;
    validateWorkerModel(index, model, reasoningEffort, observedModels);
    // Composed once, here, and stored as *the* task. Everything downstream — the bootstrap
    // the browser types, the repeated-spawn match, the status table, the snapshot — then
    // sees the same single string a worker actually receives, with no second field to keep
    // in step and no way for the two halves to be delivered apart.
    return { label, task: briefFor(context, task), model, reasoningEffort };
  });

  const conversationId = input.caller.conversationId ?? null;
  if (!hasCallerIdentity(input.caller)) {
    throw new IdentityLostError(
      'UNIDENTIFIED_CALLER: this app could not prove which ChatGPT conversation this call came from, so it will not ' +
        'make this chat the prime agent of a run. No workers were created. The paired browser extension has to be ' +
        'connected and this conversation has to be showing its connector activity; wait a moment and call ' +
        'agents action=spawn again.'
    );
  }

  if (run) {
    const caller = resolve(input.caller);
    if (caller && caller.info.role === 'worker') {
      throw new AgentError(
        `${caller.info.id} is a worker in this run. Workers must not create workers of their own — send the prime ` +
          'agent a message instead and let it decide.'
      );
    }
    if (!ownsPrime(input.caller, run)) throw new AgentsBusyError();
    if (run.transfer) throw new AgentError("PRIME_TRANSFER_IN_PROGRESS: this prime is being compacted/resumed.");
  }

  if (conversationId && (isWorkerConversation(conversationId) || retiredWorkerForConversation(conversationId) ||
      retiredManagedWorkerConversations.has(conversationId))) {
    throw new AgentError('WORKTREE_OWNER_UNAVAILABLE: retired worker conversations cannot create new prime runs or workers.');
  }
  if (input.caller.runId && !run && !dormantRunForCaller(input.caller)) throw new AgentsBusyError();
  const becamePrime = run === null;
  let resumedDormant: DormantRun | null = null;
  let createdFreshRun = false;
  if (!run) {
    resumedDormant = dormantRunForCaller(input.caller);
    if (resumedDormant) {
      if (!(run = reactivateDormantRun(resumedDormant))) {
        throw new AgentError(
          'PRIME_TRANSFER_IN_PROGRESS: this conversation is being compacted/resumed, so its worker history cannot start a new active incarnation until that handoff settles.'
        );
      }
    } else {
      run = {
        // This is an incarnation key, not a display id. Browser bootstrap commands persist
        // independently and quote it so a late `worker-1` from run A can never bind `worker-1`
        // in run B. Truncating a UUID to eight hex characters made that safety boundary only
        // 32 bits wide; keep the full UUID and shorten it only where a UI chooses to render it.
        runId: randomUUID(),
        setupProfileId: setupProfileId(input.caller.setupProfileId),
        primeConversationId: conversationId,
        primeRequestId: conversationId ? undefined : input.caller.requestId!,
        localOwnerId: input.caller.localOwnerId,
        startedAt: Date.now(),
        agents: new Map([[PRIME_ID, makePrime(conversationId)]]),
        transfer: null,
        primeGoneAt: null
      };
      runs.set(run.runId, run);
      stampOwner(run);
      createdFreshRun = true;
    }
  }
  const activeRun = run;
  if (!activeRun) throw new AgentError('The worker history could not acquire the active run slot.');

  // Slot accounting, not membership. Sleeping workers are part of the run and are not counted:
  // a run may own far more of them than it can ever have awake at once, and that is the point.
  const live = workingWorkers(run);
  // The same request arriving twice is one request. A tool result that never reached
  // ChatGPT leaves a model with no idea its workers exist, and the obvious thing for it to
  // do is ask again; creating a second identical set is how a user ends up with four
  // sub-agent chats they asked for twice. This fold applies only while those workers are still
  // slot-holding/in flight. Once a worker has stopped and become part of durable history,
  // `spawn` means exactly what it says: create a fresh worker. Reusing an old sleeper is an
  // explicit `message` operation, never an implicit side effect of another spawn.
  const repeat = matchExistingRequest(planned, live);
  if (repeat) {
    const runId = activeRun.runId;
    if (!options.deferDelivery) requestWorkerBootstraps(repeat.map((agent) => agent.info.id), run.runId);
    logInfo(`multi-agent: repeated spawn matched ${repeat.length} existing worker(s) in run ${runId}`);
    return { created: repeat.map((agent) => ({ ...agent.info })), becamePrime, runId, ...(defaultNotes.size ? { defaultNotes: [...defaultNotes] } : {}) };
  }

  if (live.length + planned.length > max) {
    const total = live.length + planned.length;
    if (resumedDormant) parkRun(run, 'a new spawn was rejected before changing its dormant history');
    else if (createdFreshRun) runs.delete(run.runId);
    throw new AgentError(`That would make ${total} live workers; the limit set in the app is ${max}.`);
  }

  const globalMax = getConfig().multiAgent.globalMaxWorkers ?? 0;
  const globalTotal = globalOccupiedWorkerSlots() + planned.length;
  if (globalMax > 0 && globalTotal > globalMax) {
    if (resumedDormant) parkRun(run, 'a new spawn was rejected by the global worker admission cap');
    else if (createdFreshRun) runs.delete(run.runId);
    throw new AgentError(
      `GLOBAL_WORKER_LIMIT: that would make ${globalTotal} live workers across all prime families; ` +
        `the global worker admission limit set in the app is ${globalMax}. Wait for a worker to stop and try again.`
    );
  }

  const ids: string[] = [];
  // Historical rows are intentionally never reused or deleted merely because the worker is
  // asleep/terminal. The old fixed 64-id scan therefore became a lifetime cap on one prime,
  // even though maxWorkers is only a *concurrency* limit. The first free positive suffix is
  // bounded by history size + this request, so this loop remains finite without an artificial
  // lifetime ceiling.
  for (let n = 1; ids.length < planned.length; n++) {
    const id = `worker-${n}`;
    if (!activeRun.agents.has(id)) ids.push(id);
  }

  const created: AgentInfo[] = [];
  const createdAgents: Agent[] = [];
  for (const [index, worker] of planned.entries()) {
    const id = ids[index] as string;
    const agent = makeWorker(id, worker.label || id, worker.task, worker.model, worker.reasoningEffort);
    agent.info.workerAllocationRunId = activeRun.runId;
    activeRun.agents.set(id, agent);
    stampOwner(activeRun);
    // A worker starts in the folder the prime was working in, so its first call can use the
    // same shorthand. It is a copy: a worker sent into another project overwrites its own
    // entry and never the prime's.
    inheritWorkspace(id, activeRun.primeConversationId, activeRun.runId, activeRun.primeRequestId);
    createdAgents.push(agent);
    created.push({ ...agent.info });
  }

  if (options.stageTopology) {
    const stage: SpawnStageState = {
      run: activeRun,
      created: createdAgents,
      // Old direct/unit staging has no resource transaction; managed Git allocation does.
      durableReady: getConfig().multiAgent.autoWorktrees !== true,
      becamePrime,
      resumedDormant,
      createdFreshRun,
      settled: false
    };
    activeSpawnStages.set(activeRun, stage);
    for (const agent of createdAgents) unpublishedAgents.add(agent);
    if (becamePrime) unpublishedRuns.add(activeRun);
  }

  logInfo(
    becamePrime
      ? `multi-agent: run ${activeRun.runId} started by conversation ${conversationId} with ${created.length} worker(s)`
      : `multi-agent: created ${created.length} worker(s) in run ${activeRun.runId}`
  );
  changed();
  if (!options.deferDelivery) requestWorkerBootstraps(created.map((agent) => agent.id), activeRun.runId);
  return { created, becamePrime, runId: activeRun.runId, ...(defaultNotes.size ? { defaultNotes: [...defaultNotes] } : {}) };
}

/**
 * Finds the workers a repeated spawn is really asking about.
 *
 * All or nothing, matched on the request as written. A request that asks for anything new is
 * a new request and creates everything it asks for, so a prime that genuinely wants a third
 * worker still gets one; only an exact repetition of work already under way is folded back.
 */
function matchExistingRequest(
  requested: ReadonlyArray<{ label: string; task: string; model: string | null; reasoningEffort: ReasoningEffort | null }>,
  live: readonly Agent[]
): Agent[] | null {
  if (requested.length === 0 || live.length === 0) return null;
  // An unambiguous encoding of the (label, task, model, reasoning) tuple rather than a separator character.
  // Any separator is only as good as the assumption that it cannot occur in the operands, and
  // the first two are free text a model wrote; JSON removes the assumption entirely, so
  // ("a", "b c") and ("a b", "c") can never shape-collide into one match. It also keeps this
  // file plain text: the NUL that used to do this job was a literal byte, which made every
  // text tool treat the source as binary. Model and reasoning ride along because a retry that
  // asks for a different model or level is new intent, not the same request arriving twice.
  const shape = (label: string, task: string, model: string | null, reasoningEffort: ReasoningEffort | null): string =>
    JSON.stringify([label.trim(), task.trim(), model, reasoningEffort]);
  const taken = new Set<Agent>();
  const matched: Agent[] = [];
  for (const worker of requested) {
    // The stored label defaults to the worker id, so an unlabelled request has to match the
    // way spawn would have written it.
    const found = live.find(
      (agent) =>
        !taken.has(agent) &&
        (shape(agent.info.label, agent.info.task, agent.info.model, agent.info.reasoningEffort) ===
          shape(worker.label || agent.info.id, worker.task, worker.model, worker.reasoningEffort) ||
          shape(agent.info.label, agent.info.task, agent.info.model, agent.info.reasoningEffort) ===
            shape(worker.label, worker.task, worker.model, worker.reasoningEffort))
    );
    if (!found) return null;
    taken.add(found);
    matched.push(found);
  }
  return matched;
}

// ----------------------------------------------------------------- recovery

/**
 * The over-and-done slot a caller belongs to, if it belongs to one.
 *
 * Terminal agents are invisible to ordinary resolution on purpose — nothing in a run should
 * route to them — but a retried `finish` still has to be answered honestly. This is the one
 * lookup that can see them.
 */
function retiredAgent(caller: Caller): Agent | null {
  const run = runForConversation(caller.conversationId);
  if (!run || !caller.conversationId) return null;
  for (const agent of run.agents.values()) {
    if (agent.info.conversationId === caller.conversationId && isOver(agent.info.state)) return agent;
  }
  return null;
}

// ------------------------------------------------------------------ routing

/**
 * Star topology, enforced.
 *
 * Two workers talking directly is the thing this mode must not allow: it is how a swarm
 * silently negotiates a plan the user never sees and the prime cannot report.
 */
function assertRoute(from: Agent, to: Agent): void {
  if (from.info.id === to.info.id) throw new AgentError('An agent cannot message itself');
  if (from.info.role === 'worker' && to.info.role !== 'prime') {
    throw new AgentError('Workers may only message the prime agent. Send it there and let the prime decide.');
  }
  if (from.info.role === 'prime' && to.info.role !== 'worker') {
    throw new AgentError('The prime agent can only message workers');
  }
}

/**
 * Adds a message to a recipient's queue, or refuses.
 *
 * Refusing is the point. Dropping the oldest waiting message to make room would throw away a
 * task or a result while still telling the sender it was sent.
 */
function assertRoom(to: Agent, incoming: number): void {
  const waiting = to.queue.filter((item) => item.ackedAt === null).length;
  if (waiting + incoming > MAX_QUEUE) {
    throw new AgentError(
      `QUEUE_FULL: ${to.info.id} already has ${waiting} unacknowledged messages, which is the limit. Nothing was sent ` +
        'and nothing was discarded. A queue this deep normally means that agent has stopped calling tools.'
    );
  }
}

function enqueue(to: Agent, message: AgentMessage): void {
  assertRoom(to, 1);
  to.queue.push(message);
  if (to.queue.length > MAX_QUEUE * 2) {
    const settled = to.queue.filter((item) => item.ackedAt !== null).slice(-MAX_QUEUE);
    to.queue = [...settled, ...to.queue.filter((item) => item.ackedAt === null)];
  }
  recount(to);
}

function newMessage(from: string, to: string, text: string): AgentMessage {
  return {
    id: randomUUID().slice(0, 8),
    from,
    to,
    time: Date.now(),
    text,
    offeredAt: null,
    offers: 0,
    offeredOnFinish: false,
    offeredViaRevival: false,
    ackedAt: null
  };
}

/**
 * Sends a message from the caller — whoever the broker says that is — to `toId`.
 *
 * There is deliberately no "from" parameter. The sender is derived from the caller's
 * binding, so the star topology cannot be sidestepped by writing someone else's id.
 */
export function sendMessage(caller: Caller, toId: string, text: string): AgentMessage {
  return sendMessages(caller, [{ to: toId, text }])[0] as AgentMessage;
}

export interface StagedAgentMessages {
  /** Incarnation actually reserved, which may differ after reviving parked history. */
  runId: string;
  /** Stable copies for the caller to record/report after commit. */
  messages: AgentMessage[];
  /**
   * Sleeping workers this batch reserved a slot for.
   *
   * Their chats are reopened only after commit, for the same reason worker tabs are: a browser
   * side effect must never happen for a broker revision that disk went on to reject.
   */
  waking: string[];
  /** Makes the already-durable queue entries visible to the recipient. Pure in-memory publish. */
  commit: () => void;
  /** Removes an unaccepted batch and supersedes any failed durable snapshot with the safe state. */
  rollback: () => void;
}

export interface StagedPrimeMessage {
  /** Address the recipient can use to reply to this prime family. */
  sourceRunId: string;
  /** Current canonical address of the destination family. */
  targetRunId: string;
  /** Stable copy for the caller to record after acceptance. */
  message: AgentMessage;
  /** Publishes the already-durable row. False only if the destination disappeared meanwhile. */
  commit: () => boolean;
  /** Removes an unaccepted row and queues a newer safe snapshot. */
  rollback: () => void;
}

/**
 * Queues one message from an existing prime to another existing prime family.
 *
 * The destination is an explicit opaque run address, not discovery authority. Only a prime may
 * use it, only the destination prime receives the row, and workers remain invisible/unreachable
 * across the family boundary. The source address rides with the durable message so the recipient
 * can reply even after either family parks and wakes under a newer incarnation id.
 */
export function stagePrimeMessage(
  input: Caller,
  targetRunId: string,
  text: string
): StagedPrimeMessage {
  requireEnabled();
  const caller = exactCaller(input);
  requireFamilySelection(caller);
  if (!hasCallerIdentity(caller)) throw new IdentityLostError();

  const source = selectedFamily(caller);
  if (!source) {
    throw new AgentError(
      'No prime family belongs to this conversation. Call agents action=spawn before messaging another prime.'
    );
  }
  if (!ownsPrime(caller, source)) {
    throw new AgentError('Only a prime agent may message another prime family.');
  }
  if (source.transfer) {
    throw new AgentError('PRIME_TRANSFER_IN_PROGRESS: this prime is being compacted/resumed.');
  }

  const address = targetRunId.trim();
  const target = address ? familyForAddress(address) : null;
  if (!target) {
    throw new AgentError(
      'TARGET_RUN_UNAVAILABLE: no addressable prime family matches target_run_id. Nothing was sent.'
    );
  }
  if (ownsPrime(caller, target)) {
    throw new AgentError('A prime cannot message one of its own families through target_run_id.');
  }
  const targetPrime = target.agents.get(PRIME_ID);
  if (!targetPrime) {
    throw new AgentError(
      'TARGET_RUN_UNAVAILABLE: the addressed prime family has no reachable prime. Nothing was sent.'
    );
  }

  const trimmed = text.trim();
  if (!trimmed) throw new AgentError('The message is empty');
  if (trimmed.length > MAX_MESSAGE_CHARS) {
    throw new AgentError(`Message is too long (limit ${MAX_MESSAGE_CHARS} characters)`);
  }
  assertRoom(targetPrime, 1);

  const sourceRunId = familyReplyAddress(source);
  const canonicalTargetRunId = familyKey(target);
  const message: AgentMessage = {
    ...newMessage(PRIME_ID, PRIME_ID, trimmed),
    fromRunId: sourceRunId
  };
  unpublishedMessages.add(message);
  enqueue(targetPrime, message);
  changed();

  let settled: boolean | null = null;
  const remove = (): void => {
    unpublishedMessages.delete(message);
    const index = targetPrime.queue.indexOf(message);
    if (index >= 0) targetPrime.queue.splice(index, 1);
    recount(targetPrime);
  };
  const destinationStillOwnsPrime = (): boolean =>
    allFamilies().some(
      owner => owner.agents.get(PRIME_ID) === targetPrime && answersTo(owner, address)
    );

  return {
    sourceRunId,
    targetRunId: canonicalTargetRunId,
    message: { ...message },
    commit: () => {
      if (settled !== null) return settled;
      if (!destinationStillOwnsPrime()) {
        remove();
        settled = false;
        changed();
        return false;
      }
      unpublishedMessages.delete(message);
      recount(targetPrime);
      settled = true;
      changed('telemetry');
      return true;
    },
    rollback: () => {
      if (settled !== null) return;
      remove();
      settled = false;
      changed();
    }
  };
}

/**
 * Sends several messages from the caller in one operation, all or nothing.
 *
 * One `agents` call is one proof of who is calling. Sending three corrections used to be
 * three MCP round trips and three separate identity resolutions — each of which can be
 * refused on its own, so a prime redirecting its whole run could get two of its three
 * messages delivered and no way to tell which.
 *
 * Everything that can be checked is checked across the whole batch before anything is
 * queued, including how much room each recipient has left, so a batch either lands complete
 * or changes nothing. Two messages to the same worker keep their written order.
 */
export function stageMessages(
  caller: Caller,
  items: ReadonlyArray<{ to: string; text: string; label?: string }>
): StagedAgentMessages {
  caller = exactCaller(caller);
  requireFamilySelection(caller);
  if (items.length === 0) throw new AgentError('No messages were given');
  if (items.length > MAX_BATCH_MESSAGES) {
    throw new AgentError(`Too many messages in one call (limit ${MAX_BATCH_MESSAGES})`);
  }
  let run = runForCaller(caller);
  let resumedDormant = false;
  if (!run && hasCallerIdentity(caller)) {
    const dormant = dormantRunForCaller(caller);
    if (dormant) {
      if (!(run = reactivateDormantRun(dormant))) {
        throw new AgentError(
          'PRIME_TRANSFER_IN_PROGRESS: this conversation is being compacted/resumed, so its sleeping workers cannot be woken until that handoff settles.'
        );
      }
      resumedDormant = true;
      caller = { ...caller, runId: run.runId };
    }
  }
  try {
    return stageMessagesActive(caller, items, resumedDormant);
  } catch (error) {
    if (resumedDormant) parkRun(run, 'a dormant-owner message was rejected before any worker was woken');
    throw error;
  }
}

function stageMessagesActive(
  caller: Caller,
  items: ReadonlyArray<{ to: string; text: string; label?: string }>,
  resumedDormant: boolean
): StagedAgentMessages {
  const run = runForCaller(caller);
  const from = requireMember(caller);
  if (run && (activeSpawnStages.has(run) || run.transfer)) throw new AgentError('OWNER_TRANSITION_IN_PROGRESS: wait for this run spawn or prime transfer to settle.');
  if (activeFinishStages.has(from)) {
    throw new AgentError(
      `FINISH_IN_PROGRESS: ${from.info.id} is still crossing its durable finish barrier and cannot send another message yet.`
    );
  }
  // A finished worker keeps its conversation so a lost finish result can be recognised as a
  // retry. Without this guard that same binding let it go on queueing work for the prime
  // after it had reported and stopped.
  if (isOver(from.info.state)) {
    throw new AgentError(
      `${from.info.id} has ${from.info.state === 'failed' ? 'failed' : 'finished'} and cannot send messages.`
    );
  }

  const planned: Array<{ to: Agent; message: AgentMessage }> = [];
  const perRecipient = new Map<string, number>();
  /** Sleeping recipients this batch is about to wake, and therefore about to take a slot for. */
  const reserved = new Set<Agent>();
  const labels = new Map<Agent, string>();
  for (const [index, item] of items.entries()) {
    const where = items.length > 1 ? ` (message ${index + 1} of ${items.length})` : '';
    const trimmed = item.text?.trim() ?? '';
    if (!trimmed) throw new AgentError(`The message is empty${where}`);
    if (trimmed.length > MAX_MESSAGE_CHARS) {
      throw new AgentError(`Message is too long (limit ${MAX_MESSAGE_CHARS} characters)${where}`);
    }
    const toId = item.to?.trim() ?? '';
    const to = toId ? run?.agents.get(toId) : undefined;
    if (!to) {
      throw new AgentError(`Unknown agent "${toId}"${where}. Call agents action=status to see who exists.`);
    }
    if (unpublishedAgents.has(to)) {
      throw new AgentError(
        `SPAWN_IN_PROGRESS: ${toId} has not crossed its durable spawn acceptance barrier yet${where}. Retry after the spawn call finishes.`
      );
    }
    if (activeFinishStages.has(to)) {
      throw new AgentError(
        `FINISH_IN_PROGRESS: ${toId} is still crossing its durable finish barrier${where}. Retry after that finish call settles.`
      );
    }
    assertRoute(from, to);
    if (item.label !== undefined) {
      const label = item.label.trim();
      if (!label || label.length > MAX_LABEL_CHARS) throw new AgentError('Worker label must contain 1–60 characters.');
      if (from.info.role !== 'prime' || to.info.role !== 'worker' || to.info.state !== 'sleeping') {
        throw new AgentError('label is only valid when the prime wakes a sleeping worker.');
      }
      if (labels.has(to) && labels.get(to) !== label) throw new AgentError('Conflicting labels for the same worker.');
      labels.set(to, label);
    }
    if (isOver(to.info.state)) {
      throw new AgentError(
        to.info.state === 'failed'
          ? `${toId} has failed and is no longer listening${where}`
          : `${toId} is finished for good — its own chat reached the context limit, so it cannot be woken` +
            `${where}. Spawn a new worker for this work.`
      );
    }
    // A revival already crossing the browser is its own in-flight transaction, exactly like a
    // spawn or a finish, and for the same reason: this call's `waking` list is what causes the
    // browser to be asked for anything at all. A second message would see the worker already
    // reserved, report nothing to wake, and be durably queued behind a revival that may yet
    // roll back to `sleeping` — leaving the prime's words in a chat nothing is going to open.
    if (to.info.state === 'waking') {
      throw new AgentError(
        `REVIVE_IN_PROGRESS: ${toId} is being woken right now${where}. Nothing was sent; send this again once it is ` +
          'awake, or once you are told the revival failed.'
      );
    }
    if (to.info.state === 'sleeping') {
      if (to.info.silenceParked && !to.info.revivable) {
        throw new AgentError(
          `${toId} is context-limited and its previous turn is still unresolved${where}. Nothing was sent. Spawn a new worker for new work.`
        );
      }
      if (!to.info.conversationId) {
        throw new AgentError(
          `${toId} is asleep but this app never learned which chat it is in, so it cannot be woken${where}.`
        );
      }
      // Waking is the one send that needs capacity, because the recipient is not running. The
      // slot is reserved here, synchronously, so two messages to two sleeping workers cannot
      // both be told the same last slot is theirs. Refused rather than queued: a message that
      // sits unread in a chat nobody is going to open is worse than being told to wait.
      if (!reserved.has(to)) {
        if (freeWorkerSlots(run?.runId) - reserved.size <= 0) {
          throw new AgentError(
            `NO_FREE_SLOT: ${toId} is asleep and all ${getConfig().multiAgent.maxWorkers} worker slots are busy, so it ` +
              `cannot be woken right now${where}. Nothing was sent. Wait for a worker to report and try again.`
          );
        }
        const globalMax = getConfig().multiAgent.globalMaxWorkers ?? 0;
        if (globalMax > 0 && globalFreeWorkerSlots() - reserved.size <= 0) {
          throw new AgentError(
            `GLOBAL_WORKER_LIMIT: ${toId} is asleep and all ${globalMax} globally admitted worker slots are busy, so it ` +
              `cannot be woken right now${where}. Nothing was sent. Wait for a worker to stop and try again.`
          );
        }
      }
      reserved.add(to);
    }
    // Counted per recipient across the batch: three messages to one worker with two slots
    // left has to be refused here, not half-delivered and then refused by enqueue.
    const already = perRecipient.get(to.info.id) ?? 0;
    assertRoom(to, already + 1);
    perRecipient.set(to.info.id, already + 1);
    planned.push({ to, message: newMessage(from.info.id, to.info.id, trimmed) });
  }

  for (const { to, message } of planned) {
    unpublishedMessages.add(message);
    enqueue(to, message);
  }
  // Reservation is part of the same all-or-nothing plan as the queue entries: every check
  // above has passed by now, so no recipient can still turn out to be unreachable.
  const previousAssignments = new Map([...reserved].map((agent) => [agent, beginRevival(agent, labels.get(agent))]));
  changed();
  const messages = planned.map(({ message }) => ({ ...message }));
  let settled = false;
  const recipients = [...new Set(planned.map(({ to }) => to))];
  return {
    runId: run!.runId,
    messages,
    waking: [...reserved].map((agent) => agent.info.id),
    commit: () => {
      if (settled) return;
      settled = true;
      if (!run || !runProjectionStillOwned(run)) return;
      for (const { message } of planned) unpublishedMessages.delete(message);
      for (const recipient of recipients) recount(recipient);
      // No new durable fact: the exact queue entries were already in the snapshot that crossed
      // the acceptance barrier. This only publishes them to live inbox readers and the UI.
      changed('telemetry');
    },
    rollback: () => {
      if (settled) return;
      settled = true;
      if (!run || !runProjectionStillOwned(run)) return;
      for (const { to, message } of planned) {
        unpublishedMessages.delete(message);
        const index = to.queue.indexOf(message);
        if (index >= 0) to.queue.splice(index, 1);
      }
      // The slot goes back with the message it was reserved for. A rejected write must not
      // leave a worker `waking` with nothing on its way to wake it.
      for (const agent of reserved) {
        if (agent.info.state !== 'waking') continue;
        Object.assign(agent.info, previousAssignments.get(agent));
        returnWakingWorkerToStopped(
          agent,
          Date.now(),
          'Its pending revival was rolled back before any new work was accepted.'
        );
      }
      for (const recipient of recipients) recount(recipient);
      // writeDurableNow deliberately retains a failed generation for retry. Queue a *newer*
      // safe snapshot immediately so that failed generation can never later persist a message
      // whose tool call reported failure.
      changed();
      if (resumedDormant) parkRun(run, 'a dormant-owner message rolled back before its worker was woken');
    }
  };
}

/** Immediate broker API used by internal/unit callers that do not expose a durable-acceptance result. */
export function sendMessages(
  caller: Caller,
  items: ReadonlyArray<{ to: string; text: string; label?: string }>
): AgentMessage[] {
  const staged = stageMessages(caller, items);
  staged.commit();
  return staged.messages;
}

/**
 * Messages to put in this agent's next tool result, including anything already offered but
 * not yet acknowledged.
 *
 * That is the deliberate at-least-once trade: if the previous result never reached ChatGPT —
 * the connector dropping mid-turn is a failure this project has reproduced — the message
 * comes round again instead of vanishing. `offers > 1` lets the caller label a repeat.
 *
 * `onFinish` records that this offer rode on a `finish` result, the one result whose loss is
 * answered by an identical retry and whose acknowledgement therefore proves nothing.
 */
export function offerMessages(id: string, onFinish = false, runId?: string): AgentMessage[] {
  const run = scopedRun(runId);
  const agent = run?.agents.get(id);
  if (!agent) return [];
  return offerAgentMessages(agent, onFinish);
}

function offerAgentMessages(agent: Agent, onFinish = false, maxChars = MAX_INBOX_OFFER_CHARS): AgentMessage[] {
  // Once the browser owns a wake, its queued text has exactly one delivery path: the real user
  // message the content script is about to submit. Letting an MCP result carry the same inbox
  // while `waking` would duplicate that instruction before the browser ACK. And after the ACK,
  // `offeredViaRevival` is stronger evidence than an ordinary result offer: that text was
  // already accepted by ChatGPT and must never be injected into a tool result again.
  const browserOwnsWake = agent.info.role === 'worker' && agent.info.state === 'waking' && !agent.info.revivable;
  if (browserOwnsWake) return [];
  const waiting: AgentMessage[] = [];
  let offeredChars = 0;
  for (const message of agent.queue) {
    if (message.ackedAt !== null || message.offeredViaRevival || unpublishedMessages.has(message)) continue;
    if (offeredChars + message.text.length > maxChars) break;
    waiting.push(message);
    offeredChars += message.text.length;
  }
  if (waiting.length === 0) return [];
  const now = Date.now();
  for (const message of waiting) {
    message.offeredAt = now;
    message.offers += 1;
    message.offeredOnFinish = onFinish;
  }
  recount(agent);
  changed('telemetry');
  return waiting.map((message) => ({ ...message }));
}

/** Caller-scoped inbox offer that remains safe when another owner has an active worker-1. */
export function offerMessagesForConversation(
  conversationId: string | null | undefined,
  onFinish = false,
  allowDormantWorkerFinishRetry = false
): { agentId: string; messages: AgentMessage[] } | null {
  if (!conversationId) return null;
  if (allFamilies().some(owner => owner.primeConversationId === conversationId)) {
    if (!familiesForCaller({ conversationId }).length) return null;
    return offerMessagesForCaller({ conversationId }, onFinish, allowDormantWorkerFinishRetry);
  }
  const active = boundAgent(conversationId);
  if (active) return { agentId: active.info.id, messages: offerAgentMessages(active, onFinish) };
  const dormant = dormantAgentForConversation(conversationId);
  if (!dormant) return null;
  // A dormant worker is stopped and must never receive ordinary broker work through an MCP
  // result. The sole exception is an exact retry of its own finish call after the first finish
  // result was lost: rows offered on that finish result must be re-offered rather than silently
  // abandoned merely because the same finish also parked the run.
  if (dormant.agent.info.role === 'worker') {
    if (!allowDormantWorkerFinishRetry || !onFinish || !hasStopped(dormant.agent.info.state)) return null;
    return { agentId: dormant.agent.info.id, messages: offerAgentMessages(dormant.agent, true) };
  }
  return { agentId: PRIME_ID, messages: offerAgentMessages(dormant.agent, onFinish) };
}

/** A missing browser attachment does not interrupt a request-owned prime's inbox. */
export function offerMessagesForCaller(
  input: Caller, onFinish = false, allowDormantWorkerFinishRetry = false
): { agentId: string; messages: Array<AgentMessage & { runId?: string }> } | null {
  const caller = exactCaller(input);
  const owned = familiesForCaller(caller).filter(owner => ownsPrime(caller, owner) && (!caller.runId || answersTo(owner, caller.runId)));
  if (owned.length) {
    let budget = MAX_INBOX_OFFER_CHARS;
    const messages = owned.flatMap(owner => offerAgentMessages(owner.agents.get(PRIME_ID)!, onFinish, budget).map(message => {
      budget -= message.text.length;
      return owned.length > 1 || caller.localOwnerId ? { ...message, runId: familyKey(owner) } : message;
    }));
    return { agentId: PRIME_ID, messages };
  }
  if (caller.runId && !selectedFamily(caller)) return null;
  return offerMessagesForConversation(caller.conversationId, onFinish, allowDormantWorkerFinishRetry);
}

/**
 * Retires everything previously offered to this agent, except what this call cannot honestly
 * be said to have proven.
 *
 * Called at the start of that agent's next authenticated call, because that call is the best
 * evidence available that the previous tool result made it back into the conversation.
 * Evidence, not proof — so a message offered on a `finish` result is not retired by another
 * `finish`, which would otherwise let a worker's own retry count an unread message as
 * delivered and then terminalise it.
 */
export function acknowledgeOffers(id: string, byFinish = false, callStartedAt = Number.POSITIVE_INFINITY, runId?: string): AgentMessage[] {
  const run = scopedRun(runId);
  const agent = run?.agents.get(id);
  if (!agent) return [];
  return acknowledgeAgentOffers(agent, byFinish, callStartedAt);
}

function acknowledgeAgentOffers(
  agent: Agent,
  byFinish = false,
  callStartedAt = Number.POSITIVE_INFINITY,
  messageIds?: ReadonlySet<string>
): AgentMessage[] {
  const offered = agent.queue.filter(
    (message) =>
      message.ackedAt === null &&
      (!messageIds || messageIds.has(message.id)) &&
      message.offeredAt !== null &&
      // A call proves only what was already delivered before that call began. This matters for
      // revival ACKs because the browser can submit the user message while an older MCP handler
      // is still running. Letting that older call retire the newly offered row would make a
      // post-crash retry indistinguishable from successful acknowledgement. Strictly earlier,
      // rather than <=, also closes the same-millisecond ordering ambiguity.
      message.offeredAt < callStartedAt &&
      !(byFinish && message.offeredOnFinish)
  );
  if (offered.length === 0) return [];
  const now = Date.now();
  for (const message of offered) message.ackedAt = now;
  agent.info.delivered += offered.length;
  recount(agent);
  changed('telemetry');
  return offered.map((message) => ({ ...message }));
}

/** Caller-scoped acknowledgement counterpart to {@link offerMessagesForConversation}. */
export function acknowledgeOffersForConversation(
  conversationId: string | null | undefined,
  byFinish = false,
  callStartedAt = Number.POSITIVE_INFINITY,
  allowDormantWorkerFinishRetry = false
): { agentId: string; messages: AgentMessage[] } | null {
  if (!conversationId) return null;
  if (allFamilies().some(owner => owner.primeConversationId === conversationId)) {
    if (!familiesForCaller({ conversationId }).length) return null;
    return acknowledgeOffersForCaller({ conversationId }, byFinish, callStartedAt, allowDormantWorkerFinishRetry);
  }
  const active = boundAgent(conversationId);
  if (active) {
    return { agentId: active.info.id, messages: acknowledgeAgentOffers(active, byFinish, callStartedAt) };
  }
  const dormant = dormantAgentForConversation(conversationId);
  if (!dormant) return null;
  if (dormant.agent.info.role === 'worker') {
    if (!allowDormantWorkerFinishRetry || !byFinish || !hasStopped(dormant.agent.info.state)) return null;
    return {
      agentId: dormant.agent.info.id,
      messages: acknowledgeAgentOffers(dormant.agent, true, callStartedAt)
    };
  }
  return { agentId: PRIME_ID, messages: acknowledgeAgentOffers(dormant.agent, byFinish, callStartedAt) };
}

export function acknowledgeOffersForCaller(
  input: Caller, byFinish = false, callStartedAt = Number.POSITIVE_INFINITY, allowDormantWorkerFinishRetry = false
): { agentId: string; messages: AgentMessage[] } | null {
  const caller = exactCaller(input);
  const owned = familiesForCaller(caller).filter(owner => ownsPrime(caller, owner) && (!caller.runId || answersTo(owner, caller.runId)));
  if (owned.length) return { agentId: PRIME_ID, messages: owned.flatMap(owner =>
    acknowledgeAgentOffers(owner.agents.get(PRIME_ID)!, byFinish, callStartedAt)) };
  if (caller.runId && !selectedFamily(caller)) return null;
  return acknowledgeOffersForConversation(caller.conversationId, byFinish, callStartedAt, allowDormantWorkerFinishRetry);
}

/** Explicit local receipts retire only report ids the caller says it consumed. */
export function acknowledgeLocalReports(caller: Caller, messageIds: readonly string[]): AgentMessage[] {
  requireEnabled();
  if (!caller.localOwnerId || !hasCallerIdentity(caller)) throw new IdentityLostError();
  requireFamilySelection(caller);
  const ids = new Set(messageIds);
  const acknowledged = familiesForCaller(caller).filter(owner => ownsPrime(caller, owner) && (!caller.runId || answersTo(owner, caller.runId)))
    .flatMap(owner => acknowledgeAgentOffers(owner.agents.get(PRIME_ID)!, false, Number.POSITIVE_INFINITY, ids));
  if (acknowledged.length) changed('critical');
  return acknowledged;
}

export function pendingCount(id: string, runId?: string): number {
  const run = scopedRun(runId);
  return run?.agents.get(id)?.info.pending ?? 0;
}

/**
 * Parks an owner once none of its workers consumes a slot.
 *
 * Ownership and execution are intentionally different lifetimes. Prime reports, sleeping
 * workers, terminal rows and their exact conversation bindings all remain in the caller's
 * dormant history. What disappears is only the active incarnation, so another ChatGPT
 * conversation may start its own workers immediately.
 *
 * The legacy options remain in the signature for bridge callers compiled against the previous
 * terminal-only release policy; pending reports are never discarded now.
 */
export function releaseQuiescentRun(options: { allowPendingReports?: boolean; reason?: string } = {}, runId?: string): boolean {
  if (runId === undefined) { let parked = false; for (const id of [...runs.keys()]) parked = releaseQuiescentRun(options, id) || parked; return parked; }
  const run = scopedRun(runId);
  if (!run) return false;
  if (activeSpawnStages.has(run)) return false;
  // `pending` intentionally hides messages that are still behind an immediate durability
  // barrier. That visibility rule must not make them look nonexistent to lifecycle teardown:
  // a parallel worker finish + prime ACK can otherwise make pending=0 and destroy the run while
  // another agents::message call is still staged. Its later commit would then report success
  // into an Agent object no longer reachable from the broker. A staged queue entry is therefore
  // outstanding work even though it is not yet an offerable inbox item.
  if ([...run.agents.values()].some((agent) => agent.queue.some((message) => unpublishedMessages.has(message)))) {
    return false;
  }
  if (workingWorkers(run).length > 0) return false;
  return parkRun(run, options.reason ?? 'no worker is currently running');
}

// ------------------------------------------------------------------- finish

export interface FinishResult {
  info: AgentInfo;
  /** The report produced for the prime, so the caller can record it durably after acceptance. */
  report: AgentMessage | null;
  /** This call found the agent already terminal and changed nothing. */
  repeat: boolean;
}

/** A finish planned for the critical persistence lane but not yet published to live readers. */
export interface StagedFinish extends FinishResult {
  commit: () => void;
  rollback: () => void;
}

function finishTarget(caller: Caller): Agent {
  caller = exactCaller(caller);
  requireEnabled();
  requireFamilySelection(caller);
  if (!hasCallerIdentity(caller)) throw new IdentityLostError();
  // The one call that also answers from a conversation whose slot has already ended: this
  // connector loses tool results, so a retry of *this* call is exactly what that looks like,
  // and telling the chat that had genuinely finished that it was a stranger was worse than
  // useless.
  const agent = resolve(caller) ?? retiredAgent(caller);
  if (agent) {
    if (agent.info.role !== 'worker') {
      throw new AgentError(
        'The prime agent does not finish: the run ends when its workers have reported and the user is done with it.'
      );
    }
    return agent;
  }

  const dormant = dormantAgentForConversation(caller.conversationId)?.agent ?? null;
  // A dormant worker may only be here as a retry of a finish that already stopped it. Never
  // treat an unexpected dormant worker call as authority to resume or mutate its history.
  if (dormant?.info.role === 'worker' && hasStopped(dormant.info.state)) return dormant;
  if (runs.size > 0) throw new AgentsBusyError();
  if (!dormant) throw new AgentError('No sub-agent run or worker history belongs to this conversation.');
  if (dormant.info.role !== 'worker') {
    throw new AgentError(
      'The prime agent does not finish: the run ends when its workers have reported and the user is done with it.'
    );
  }
  throw new AgentError(`${dormant.info.id} is dormant but has not finished, so finish cannot be retried from this state.`);
}

function planFinish(agent: Agent, result: string): { info: AgentInfo; report: AgentMessage } {
  const run = runForAgent(agent);
  // What the prime told this worker and cannot be shown to have reached it. Taken before
  // terminalisation and said out loud, because this app cannot prove a tool result arrived —
  // the guarantee it can keep is "either the worker got it or you are told it may not have".
  // This finish call is itself the acknowledgement for anything that was offered on the
  // worker's preceding *ordinary* tool result. Kernel retires those rows immediately after the
  // handler returns; counting them here produces a final report that says "never confirmed"
  // about the very messages this call confirms. A row never offered is still uncertain, and a
  // row offered on an earlier finish result is deliberately still uncertain because this may be
  // the retry of that lost finish result (see acknowledgeOffers(byFinish=true)).
  const unconfirmed = agent.queue
    .filter(
      (message) =>
        message.ackedAt === null && (message.offeredAt === null || message.offeredOnFinish)
    )
    .map((message) => message.id);
  // A finish is evidence that this piece of work is over, and nothing more than that. The
  // worker's chat is still there, still holds everything it learned, and is still the cheapest
  // place to put the next piece of work — so it sleeps rather than ends, unless its own context
  // has grown past the point where reopening it would achieve anything.
  const terminal = ceilingCrossed(agent.info);
  const now = Date.now();
  const info: AgentInfo = {
    ...agent.info,
    state: terminal ? 'finished' : 'sleeping',
    finishedAt: terminal ? now : null,
    sleptAt: now,
    detachedAt: null,
    result: result.slice(0, MAX_MESSAGE_CHARS),
    revivable: !terminal,
    silenceParked: false,
    silenceRecoveryTurnId: null,
    silenceRecoveryRequestOriginMax: null
  };
  // A message never offered to the worker is not lost: it stays in this inbox and reaches the
  // worker next, either on this finish result or through the revival that wakes it for exactly
  // that unread work. Calling it unread made the prime distrust a result that was fine (#551).
  // Only a message already offered on an earlier finish (a possibly lost retry), or any message
  // to a worker that ends for good, is genuinely uncertain.
  const queuedNext = terminal ? [] : unconfirmed.filter(id => agent.queue.some(message => message.id === id && message.offeredAt === null));
  const uncertain = unconfirmed.filter(id => !queuedNext.includes(id));
  const list = (ids: string[]) => `${ids.slice(0, 5).join(', ')}${ids.length > 5 ? ', …' : ''}`;
  const caveat =
    (uncertain.length > 0
      ? `\n(${agent.info.id} ended without ever confirming ${uncertain.length} message(s) you sent it — ` +
        `${list(uncertain)}. Assume it may not have read them and check the result against what you asked for.)`
      : '') +
    (queuedNext.length > 0
      ? `\n(${queuedNext.length} message(s) you sent ${agent.info.id} arrived after its last step — ${list(queuedNext)}. ` +
        'They are still queued for it and reach it next; there is no need to send them again.)'
      : '');
  // A worker that stops is a freed slot, and the prime is the only party that can use it —
  // but nothing in the final report ever said so. The recorded runs show the consequence: a
  // prime that has just been told a worker ended sits on remaining work rather than putting
  // that capacity back to use, because "finished" reads as an ending rather than as capacity
  // coming back. Counting is done against the workers that outlive this one, since `agent`
  // still holds its slot at plan time.
  const max = getConfig().multiAgent.maxWorkers;
  const stillWorking = run
    ? [...run.agents.values()].filter(
        (other) =>
          other.info.role === 'worker' &&
          other.info.id !== agent.info.id &&
          occupiesSlot(other.info.state)
      ).length
    : 0;
  const free = Math.max(0, max - stillWorking);
  const slots =
    free > 0
      ? `${free} of ${max} worker slot${max === 1 ? '' : 's'} ${free === 1 ? 'is' : 'are'} free. `
      : '';
  // The one line in this whole file the prime reliably acts on, so it says the thing that
  // changed: this worker is reusable. Spawning a replacement for work its own chat already
  // understands is both the expensive answer and the one that fills ChatGPT with abandoned
  // conversations, which is the behaviour reusable workers exist to stop.
  const capacity = terminal
    ? `
(${agent.info.id} is finished for good: its own chat has reached the context limit, so it cannot be woken again. ` +
      `${slots}Spawn a new worker for any remaining work.)`
    : `
(${agent.info.id} sleeping; ${slots}Reuse first: agents action=message to="${agent.info.id}". ` +
      'Spawn only when no sleeping worker is suitable or more parallel capacity is needed.)';
  const report = newMessage(
    agent.info.id,
    PRIME_ID,
    `[${agent.info.id} ${terminal ? 'finished' : 'reported'}] ${info.result}${caveat}${capacity}`
  );
  return { info, report };
}

/**
 * Upgrades a finish that is still behind its immediate durability barrier when session
 * accounting proves the worker crossed the 400k ceiling in the meantime.
 *
 * The live Agent intentionally stays active until commit, so the staged overlay is the state
 * that is about to become authoritative. Leaving that overlay at sleeping/revivable=true while
 * writing contextTokens>=400k creates a crash snapshot that revives a worker which should be
 * terminal. Keep the staged report identity stable and update only its projected authority and
 * wording.
 */
function upgradeStagedFinishAtCeiling(agent: Agent): boolean {
  const stage = activeFinishStages.get(agent);
  if (
    !stage ||
    stage.settled ||
    !runProjectionStillOwned(stage.run) ||
    stage.info.state === 'finished' ||
    !ceilingCrossed(agent.info)
  ) {
    return false;
  }
  const terminal = planFinish(agent, stage.info.result ?? '');
  stage.info.state = 'finished';
  stage.info.finishedAt = stage.info.sleptAt ?? terminal.info.finishedAt ?? Date.now();
  stage.info.revivable = false;
  stage.info.contextTokens = agent.info.contextTokens;
  stage.report.text = terminal.report.text;
  return true;
}

function publishFinish(agent: Agent, info: AgentInfo, report: AgentMessage, durability: SwarmMutationDurability): void {
  // Only the authority fields are committed from the plan. Liveness/detach telemetry may
  // legitimately have advanced while an immediate disk write was awaiting I/O and must not be
  // rewound to the copy captured before that await.
  agent.info.state = info.state;
  agent.info.finishedAt = info.finishedAt;
  agent.info.sleptAt = info.sleptAt;
  agent.info.detachedAt = null;
  agent.info.result = info.result;
  agent.info.revivable = info.revivable;
  agent.info.silenceParked = false;
  agent.info.silenceRecoveryTurnId = null;
  agent.info.silenceRecoveryRequestOriginMax = null;
  // The conversation is kept either way, and for two reasons now: a retried finish from that
  // same chat is recognised as the retry it is, and — while the worker is only sleeping — that
  // id is the whole of what a later revival needs to reopen the chat and type into it.
  const prime = primeForOwnedAgent(agent);
  if (!prime) throw new AgentError(`Cannot find the prime that owns ${agent.info.id}.`);
  // Over the queue limit on purpose: the worker is about to stop calling tools and has no way
  // to retry its own report.
  prime.queue.push(report);
  recount(prime);
  logInfo(`multi-agent: ${agent.info.id} ${info.state === 'finished' ? 'finished for good' : 'is sleeping'}`);
  changed(durability);
}

/** Whether this exact run object still owns its agent map, active or parked. */
function runProjectionStillOwned(owner: Run): boolean {
  if (runs.get(owner.runId) === owner) return true;
  return [...dormantRuns.values()].some((history) => history.agents === owner.agents);
}

function stageFinish(agent: Agent, result: string, acknowledgedMessageIds: readonly string[] = []): StagedFinish {
  const run = runForAgent(agent);
  if (!canStageFinish(agent)) {
    logInfo(`multi-agent: ${agent.info.id} called finish again after it had already stopped (${agent.info.state})`);
    return {
      info: { ...agent.info },
      report: null,
      repeat: true,
      commit: () => undefined,
      rollback: () => undefined
    };
  }
  if (activeFinishStages.has(agent)) {
    throw new AgentError(
      `FINISH_IN_PROGRESS: ${agent.info.id} is already crossing its durable finish barrier. Retry the same finish after that call settles.`
    );
  }
  if (!run) throw new AgentError('No sub-agent run is active.');
  const planned = planFinish(agent, result);
  const stage: FinishStageState = {
    run,
    agent,
    ...planned,
    acknowledgedMessageIds: [...new Set(acknowledgedMessageIds)],
    settled: false
  };
  activeFinishStages.set(agent, stage);
  // This critical revision is represented only as an overlay in the immediate snapshot. Live
  // status/inbox readers and the ordinary debounce still see the active worker until commit.
  changed();

  const settle = (accepted: boolean): void => {
    if (stage.settled) return;
    stage.settled = true;
    if (activeFinishStages.get(agent) === stage) activeFinishStages.delete(agent);
    if (!runProjectionStillOwned(stage.run) || stage.run.agents.get(agent.info.id) !== agent) return;
    if (accepted) {
      // The exact projected terminal row + report already crossed the immediate durable barrier.
      // Publishing those same facts changes only live readers and the debounced mirror.
      if (stage.acknowledgedMessageIds.length > 0) {
        const acked = new Set(stage.acknowledgedMessageIds);
        const now = Date.now();
        let delivered = 0;
        for (const message of agent.queue) {
          if (message.ackedAt !== null || !acked.has(message.id)) continue;
          message.ackedAt = now;
          delivered += 1;
        }
        agent.info.delivered += delivered;
        recount(agent);
      }
      // Feature-disable parking may already have put the live row into `sleeping`. The staged
      // finish is still the accepted authority projection and carries the worker's real result
      // plus its prime report, so publish it into the same parked owner map rather than dropping
      // it merely because the active incarnation was released while the fsync was in flight.
      publishFinish(agent, stage.info, stage.report, 'telemetry');
      return;
    }
    // A failed write generation can remain queued for durable.ts retry. Emit a newer safe
    // pre-finish snapshot after removing the overlay so the rejected finish cannot resurrect.
    changed();
  };
  return {
    // These are the staged authority objects themselves. A session measurement may cross the
    // context ceiling while the fsync is in flight; upgradeStagedFinishAtCeiling() then updates
    // these same objects so both the durable snapshot and the eventual tool/bridge result say
    // what actually committed.
    info: stage.info,
    report: stage.report,
    repeat: false,
    commit: () => settle(true),
    rollback: () => settle(false)
  };
}

/** Plans an explicit worker finish behind its durable acceptance barrier. */
export function stageFinishAgent(caller: Caller, result: string): StagedFinish {
  return stageFinish(finishTarget(caller), result);
}

/**
 * Finishes the calling worker. An agent can only ever finish itself.
 *
 * Finishing twice is one finish. This connector loses tool results, so a worker whose result
 * never came back simply calls again, usually with slightly different wording. Taking the
 * second call literally rewrote `finishedAt` and queued a *second* final report, so the
 * prime was told the same thing twice with no way to tell that from two genuine reports.
 */
export function finishAgent(caller: Caller, result: string): FinishResult {
  const agent = finishTarget(caller);
  if (!canStop(agent.info.state)) {
    logInfo(`multi-agent: ${agent.info.id} called finish again after it had already stopped (${agent.info.state})`);
    return { info: { ...agent.info }, report: null, repeat: true };
  }
  const planned = planFinish(agent, result);
  publishFinish(agent, planned.info, planned.report, 'critical');
  return { info: { ...agent.info }, report: { ...planned.report }, repeat: false };
}

/**
 * App-owned terminal cleanup for a worker whose ChatGPT turn produced a settled answer.
 *
 * Broker messages ride on later tool results, so a worker that simply answers and then goes
 * idle has no future execution point at which an explicit `agents finish` can be required.
 * Leaving that worker `active` permanently consumed a slot and made the UI promise a worker
 * was still working when its chat had plainly finished. Treat workers as one-shot jobs: the
 * browser's settled assistant answer releases the slot, while an explicit finish remains the
 * same idempotent path when the model does call it first.
 */
export function finishWorkerConversation(conversationId: string, result: string): FinishResult | null {
  const run = runForConversation(conversationId);
  if (!run || !conversationId) return null;
  const agent = agentForConversationId(conversationId);
  if (!agent || agent.info.role !== 'worker' || !canStop(agent.info.state)) return null;
  return finishAgent({ conversationId }, result);
}

/** Browser-owned counterpart to stageFinishAgent(), resolved from the worker's bound chat. */
export function stageWorkerConversationFinish(conversationId: string, result: string): StagedFinish | null {
  const run = runForConversation(conversationId);
  if (!run || !conversationId) return null;
  const agent = agentForConversationId(conversationId);
  if (!agent || agent.info.role !== 'worker' || !canStageFinish(agent)) return null;
  // A settled browser answer is evidence the worker got past the preceding ordinary tool
  // result. Those are exactly the rows the next authenticated MCP call would retire. There is
  // no such next call when the worker simply answers and stops, so stage their retirement with
  // the browser-owned finish itself. Rows offered by a finish result remain excluded for the
  // same lost-result retry reason as acknowledgeOffers(byFinish=true).
  const acknowledged = agent.queue
    .filter((message) => message.ackedAt === null && message.offeredAt !== null && !message.offeredOnFinish)
    .map((message) => message.id);
  return stageFinish(agent, result, acknowledged);
}

/**
 * Ends a worker that never got off the ground, definitively.
 *
 * Called by whoever owns the bootstrap once it has run out of retries or time. Before this
 * existed, giving up only deleted the queued command: the worker stayed `invited`, still
 * counted towards the worker limit, still blocked the next bootstrap, and still promised the
 * prime a report that could never arrive.
 */
export function failAgent(
  id: string,
  reason: string,
  note?: string,
  options: { revivable?: boolean } = {}, runId?: string
): FinishResult | null {
  const run = scopedRun(runId);
  const agent = run?.agents.get(id);
  if (!run || !agent || agent.info.role !== 'worker' || isOver(agent.info.state)) return null;
  // A final answer/explicit finish is stronger evidence than a concurrent timeout/cleanup.
  // The callers that can legitimately race this path are themselves retryable after the
  // in-flight acceptance barrier settles, so never publish two incompatible terminal reports.
  if (activeFinishStages.has(agent)) return null;
  agent.info.state = 'failed';
  agent.info.finishedAt = Date.now();
  agent.info.detachedAt = null;
  agent.info.result = reason.slice(0, MAX_MESSAGE_CHARS);
  // Only a failure that says nothing about the turn itself may be undone by the turn proving
  // otherwise. A tab that never opened, a worker a person cleared, and a bootstrap that ran
  // out of retries are all verdicts about the work; a chat that was closed is not.
  agent.info.revivable = options.revivable === true;
  agent.info.silenceParked = false;
  agent.info.silenceRecoveryTurnId = null;
  agent.info.silenceRecoveryRequestOriginMax = null;
  // A revivable failure keeps whatever the prime said to it. If the worker comes back, those
  // messages are still the instructions it never acknowledged; throwing them away here and
  // then reviving the worker would silently drop them.
  if (!agent.info.revivable) agent.queue = [];
  recount(agent);

  const report = newMessage(
    id,
    PRIME_ID,
    note ??
      `[${id} failed] The worker did not start: ${agent.info.result}. It will not report. Continue that part of the ` +
        'work yourself. Resolve the reported startup problem before spawning a replacement; repeating the same failed startup opens more tabs without starting the work.'
  );
  const prime = primeAgent(run);
  prime.queue.push(report);
  recount(prime);
  logWarn(`multi-agent: ${id} failed — ${reason}`);
  changed();
  return { info: { ...agent.info }, report: { ...report }, repeat: false };
}

// -------------------------------------------------------------- sleep / wake

/**
 * Puts a worker to sleep on evidence that it stopped working, without ending it.
 *
 * The app-owned half of the lifecycle, and the reason a run can outlive any individual piece
 * of work. Every caller here is an observation rather than a verdict — a settled final answer,
 * a chat that went quiet with its tab gone, a durably quiescent turn — so none of them may
 * throw anything away. The conversation, the transcript, the workspace and the unacknowledged
 * queue all survive, because the next thing that happens to this worker is most likely the
 * prime waking it up in that same chat.
 *
 * The context ceiling makes a proven stop final, and it is read here rather than enforced
 * anywhere earlier: a worker that crossed it mid-task was never interrupted, it simply has no
 * room left for another task once this one ends. Ambiguous silence with a durably open turn is
 * parked before this helper, because silence alone does not prove that current task ended.
 */
function sleepAgent(agent: Agent, reason: string): FinishResult | null {
  const run = runForAgent(agent);
  if (!run || agent.info.role !== 'worker') return null;
  if (!canStop(agent.info.state)) return null;
  // A finish crossing its own durable acceptance barrier is the stronger, more specific
  // statement about the same transition. Never publish two of them.
  if (activeFinishStages.has(agent)) return null;
  const terminal = ceilingCrossed(agent.info);
  const now = Date.now();
  agent.info.state = terminal ? 'finished' : 'sleeping';
  agent.info.sleptAt = now;
  agent.info.finishedAt = terminal ? now : null;
  agent.info.detachedAt = null;
  agent.info.revivable = !terminal;
  recount(agent);
  const report = newMessage(
    agent.info.id,
    PRIME_ID,
    terminal
      ? `[${agent.info.id} finished] ${reason} Its chat has also reached the context limit, so it cannot be woken ` +
        'again. Its worker slot is free; spawn a new worker if that work still matters.'
      : `[${agent.info.id} is sleeping] ${reason} Its worker slot is free and its chat is intact — wake it with ` +
        `agents action=message to="${agent.info.id}" when you have more for it, rather than spawning a new worker.`
  );
  const prime = primeAgent(run);
  prime.queue.push(report);
  recount(prime);
  logInfo(`multi-agent: ${agent.info.id} ${terminal ? 'finished for good' : 'is sleeping'} — ${reason}`);
  changed();
  return { info: { ...agent.info }, report: { ...report }, repeat: false };
}

/** Sleeps a worker by slot id. Used by sweeps that already know which row they proved quiet. */
export function sleepWorker(id: string, reason: string, runId?: string): FinishResult | null {
  const run = scopedRun(runId);
  const agent = run?.agents.get(id);
  if (!agent) return null;
  return sleepAgent(agent, reason);
}

/**
 * What the app has to do in the browser to wake one worker, and which messages ride on it.
 *
 * Carries the conversation because that *is* the worker: reviving is reopening one exact
 * `/c/<id>` and typing into it. Carries the ids as well as the text so that acceptance can
 * mark exactly the messages that were typed as offered, rather than whatever happened to be
 * queued by the time the browser answered — a message marked offered but never delivered is
 * retired by the worker's next call and lost.
 */
export interface WorkerRevival {
  primeConversationId: string | null;
  id: string;
  conversationId: string;
  runId: string;
  text: string;
  messageIds: string[];
}

let reviveRequest: ((revivals: WorkerRevival[]) => void) | null = null;

/**
 * The bridge registers here, exactly as it does for spawn bootstraps.
 *
 * Registration replays whatever is already owed, for the same reason: a restart restores the
 * run before the bridge exists, so a worker left mid-revival has nobody to ask for a tab.
 */
export function onReviveRequest(handler: (revivals: WorkerRevival[]) => void): () => void {
  reviveRequest = handler;
  const owed = pendingWorkerRevivals();
  if (owed.length > 0) {
    handler(owed);
    logInfo(`multi-agent: ${owed.length} worker chat(s) still owed a revival`);
  }
  return () => {
    if (reviveRequest === handler) reviveRequest = null;
  };
}

/** Workers whose slot is reserved and whose chat has not been typed into yet. */
export function pendingWorkerRevivals(): WorkerRevival[] {
  const out: WorkerRevival[] = [];
  for (const run of runs.values()) for (const agent of run.agents.values()) {
    if (agent.info.state !== 'waking' || !agent.info.conversationId) continue;
    const plan = planRevivalText(agent);
    out.push({
      id: agent.info.id,
      conversationId: agent.info.conversationId,
      runId: run.runId,
      primeConversationId: run.primeConversationId,
      text: plan.text,
      messageIds: plan.messageIds
    });
  }
  return out;
}

/**
 * Gives the browser exclusive ownership of an in-flight wake before it receives the text.
 *
 * `waking + revivable=true` is the arbitration window: a late MCP call from the old server-side
 * turn may still prove that worker never really stopped and take it back to `active`. Once the
 * exact revival command has been durably redeemed, however, that same late call must not steal
 * the transaction after the browser already owns its payload. Reuse `revivable=false` only while
 * state is `waking`; every other state already gives that bit its ordinary meaning.
 *
 * The bridge makes this mutation durable before returning the command body. If that barrier
 * fails it calls {@link rollbackWorkerRevivalClaim}, restoring the pre-claim arbitration state.
 */
export function claimWorkerRevival(id: string, conversationId: string, runId?: string): boolean {
  const run = scopedRun(runId);
  const agent = run?.agents.get(id);
  if (!agent || agent.info.state !== 'waking' || agent.info.conversationId !== conversationId) return false;
  if (!agent.info.revivable) return true;
  agent.info.revivable = false;
  changed('critical');
  return true;
}

/** Rolls back only the browser-claim marker while the wake is otherwise still untouched. */
export function rollbackWorkerRevivalClaim(id: string, conversationId: string, runId?: string): boolean {
  const run = scopedRun(runId);
  const agent = run?.agents.get(id);
  if (!agent || agent.info.state !== 'waking' || agent.info.conversationId !== conversationId || agent.info.revivable) {
    return false;
  }
  agent.info.revivable = true;
  changed('critical');
  return true;
}

/** True only while a browser-owned wake is between durable redeem and sent/failed ACK. */
export function workerRevivalClaimed(conversationId: string | null | undefined): boolean {
  const run = runForConversation(conversationId);
  if (!run || !conversationId) return false;
  const agent = boundAgent(conversationId);
  return Boolean(agent?.info.role === 'worker' && agent.info.state === 'waking' &&
    !agent.info.revivable && !agent.info.lastRevivalCommandId);
}

/**
 * Durable evidence that a browser-owned wake already crossed its semantic send boundary.
 *
 * `/commands/ack` writes the worker snapshot before it writes the bridge receipt. A crash in
 * between therefore restores the leased command but may restore the worker as active/sleeping
 * rather than `waking`. The browser must be able to retry that ACK without the bridge turning a
 * successful send into a terminal failure. A revival-offer stamped no earlier than this
 * command's owner lease is the exact broker-side evidence of that prior send; acknowledged rows
 * count too, because the worker may have made its next call before the browser's HTTP retry.
 */
export function workerRevivalDeliveredSince(
  id: string,
  conversationId: string,
  commandId: string,
  claimedAt: number, runId?: string
): boolean {
  const run = scopedRun(runId);
  const agent = run?.agents.get(id);
  if (!agent || !conversationId || agent.info.conversationId !== conversationId) return false;
  if (commandId && agent.info.lastRevivalCommandId === commandId) return true;
  // Backward-compatible evidence for a snapshot written between introduction of durable
  // revival offers and the exact command-id marker. New sends always take the exact branch.
  //
  // Unread is part of that evidence, not decoration. An offer the worker has already answered
  // belongs to a wake that is over, and reading it as proof of delivery is what refused a
  // later, legitimate wake as `command_already_sent`. This is the same reading of "a revival
  // was delivered" that noteAgentAlive() uses.
  return agent.queue.some(
    (message) =>
      message.ackedAt === null &&
      message.offeredViaRevival === true &&
      message.offeredAt !== null &&
      message.offeredAt >= claimedAt
  );
}

/**
 * The user message the extension types into a woken worker's chat.
 *
 * The prime's own words, delivered the way a person would deliver them, because that is what
 * they are: this app is not asking the worker to go and fetch something, it is handing it the
 * instruction. The short parenthetical afterwards exists only because the worker's last turn
 * ended with it being told to stop — without it, a well-behaved worker reads a new user turn
 * and still believes it is finished.
 */
function planRevivalText(agent: Agent): { text: string; messageIds: string[] } {
  const waiting: AgentMessage[] = [];
  let chars = 0;
  for (const message of agent.queue) {
    // A browser `sent` ACK is stronger than an ordinary MCP offer: ChatGPT already accepted
    // this row as a real user message in the worker chat. It remains in the queue only until
    // the worker's next authenticated call proves receipt, but it must never be typed again by
    // a later revival in the meantime. This matters especially across feature-disable parking:
    // an active revived worker can be put back to sleep before it makes another tool call.
    if (message.ackedAt !== null || message.offeredViaRevival || unpublishedMessages.has(message)) continue;
    if (waiting.length > 0 && chars + message.text.length > MAX_INBOX_OFFER_CHARS) break;
    waiting.push(message);
    chars += message.text.length;
  }
  const body = waiting.map((message) => message.text).join('\n\n');
  const text =
    (body || 'The prime agent has more work for you; check your inbox on the next tool result.') +
    `\n\n(Chat On Steroids: you are still ${agent.info.id} in the same run, and this is the prime agent talking to ` +
    'you again in the chat you already know. Pick up from what you did here before rather than starting over. ' +
    `Report with ${ownCoreHint() ? `the agents tool${ownCoreHint()}: ` : 'agents '}action=message to="prime" as you go and action=finish when this piece is done.)`;
  return { text, messageIds: waiting.map((message) => message.id) };
}

type WorkerAssignment = Pick<
  AgentInfo,
  'label' | 'task' | 'result' | 'silenceParked' | 'silenceRecoveryTurnId' | 'silenceRecoveryRequestOriginMax'
>;

/**
 * Reserves a slot for a sleeping worker and asks the browser to wake it, or refuses.
 *
 * Slot reservation is the whole reason this is a state transition rather than a side effect.
 * Two messages to two sleeping workers arriving at once must not both see the same last free
 * slot, so the transition into `waking` — which {@link occupiesSlot} counts — happens here,
 * synchronously, before anything touches the browser.
 */
function beginRevival(agent: Agent, label?: string): WorkerAssignment {
  const previous = {
    label: agent.info.label,
    task: agent.info.task,
    result: agent.info.result,
    silenceParked: agent.info.silenceParked,
    silenceRecoveryTurnId: agent.info.silenceRecoveryTurnId,
    silenceRecoveryRequestOriginMax: agent.info.silenceRecoveryRequestOriginMax
  };
  // The prime explicitly names new work; an omitted label preserves the existing name.
  // An old report must not masquerade as the result of the waking assignment. Keep that
  // report in the prime's existing inbox/history; status carries only a bounded task preview.
  if (label !== undefined) agent.info.label = label;
  agent.info.task = agent.queue
    .filter((message) => message.ackedAt === null && !message.offeredViaRevival)
    .map((message) => message.text).join('\n\n').slice(0, MAX_TASK_CHARS);
  agent.info.result = null;
  agent.info.state = 'waking';
  // `sleptAt` stays: the worker is still stopped while waking, and that timestamp is what tells
  // a turn the page reports *now* apart from the page replaying the turn that ended before the
  // sleep. It is cleared by the revival's own proof, in noteAgentAlive().
  agent.info.detachedAt = null;
  // True only for the pre-claim arbitration window. A proven tool call may still show that the
  // old server-side turn never stopped and take the worker active; `/commands/redeem` flips this
  // false durably before it returns any payload, after which the browser owns the wake instead.
  agent.info.revivable = true;
  // A prime-authorized new task supersedes the ambiguous old-turn parking authority. Rollback
  // restores this field from `previous`; once the wake is accepted, only the normal wake proof
  // may take the worker active.
  agent.info.silenceParked = false;
  agent.info.silenceRecoveryTurnId = null;
  agent.info.silenceRecoveryRequestOriginMax = null;
  agent.info.lastRevivalCommandId = null;
  logInfo(`multi-agent: ${agent.info.id} is being woken in conversation ${agent.info.conversationId}`);
  return previous;
}

/**
 * Reserves workers that have stopped with prime work which was never offered to them.
 *
 * A message sent while a worker is `detached` cannot safely be injected immediately: its
 * server-side turn may still be running. Once that worker is later proved stopped, however,
 * leaving the already-accepted message in a sleeping inbox strands it until the prime happens
 * to send a *second* message. This stages the missing handoff from "stopped" to "waking".
 *
 * No browser side effect happens here. The caller must persist this critical revision, commit
 * it, and only then call requestWorkerRevivals(). That keeps the same durable-before-publish
 * boundary as an ordinary message-to-sleeping-worker revival.
 */
export function stageQueuedWorkerRevivals(ids: readonly string[], runId?: string): {
  waking: string[];
  commit: () => void;
  rollback: () => void;
} {
  const run = scopedRun(runId);
  if (!run || ids.length === 0) return { waking: [], commit: () => undefined, rollback: () => undefined };
  const wanted = new Set(ids);
  const reserved: Array<{ agent: Agent; sleptAt: number | null; assignment: WorkerAssignment }> = [];
  for (const agent of run.agents.values()) {
    if (
      agent.info.role !== 'worker' ||
      !wanted.has(agent.info.id) ||
      agent.info.state !== 'sleeping' ||
      !agent.info.revivable ||
      !agent.info.conversationId ||
      ceilingCrossed(agent.info)
    ) {
      continue;
    }
    const hasUnseen = agent.queue.some(
      (message) =>
        message.ackedAt === null &&
        message.offeredAt === null &&
        !unpublishedMessages.has(message)
    );
    if (!hasUnseen || freeWorkerSlots(run.runId) <= 0 || globalFreeWorkerSlots() <= 0) continue;
    const sleptAt = agent.info.sleptAt;
    const assignment = beginRevival(agent);
    reserved.push({ agent, sleptAt, assignment });
  }
  if (reserved.length === 0) return { waking: [], commit: () => undefined, rollback: () => undefined };
  changed();
  let settled = false;
  return {
    waking: reserved.map(({ agent }) => agent.info.id),
    commit: () => {
      if (settled) return;
      settled = true;
      changed('telemetry');
    },
    rollback: () => {
      if (settled) return;
      settled = true;
      for (const { agent, sleptAt, assignment } of reserved) {
        if (agent.info.state !== 'waking') continue;
        Object.assign(agent.info, assignment);
        returnWakingWorkerToStopped(
          agent,
          sleptAt ?? Date.now(),
          'Its queued-work revival was rolled back before the browser could safely deliver it.'
        );
      }
      changed();
    }
  };
}

/**
 * Publishes revival bootstraps for workers that are still genuinely waking.
 *
 * The second half of the `message` transaction, mirroring {@link requestWorkerBootstraps}: the
 * broker plans and reserves first, that revision is made durable, and only then is a browser
 * asked to open anything. A retry after a failed disk barrier is safe because a worker that is
 * already awake is skipped.
 */
export function requestWorkerRevivals(ids: readonly string[], runId?: string): number {
  const run = scopedRun(runId);
  if (!run || ids.length === 0) return 0;
  const wanted = new Set(ids);
  const owed = pendingWorkerRevivals().filter((revival) => revival.runId === run.runId && wanted.has(revival.id));
  if (owed.length === 0) return 0;
  if (reviveRequest) reviveRequest(owed);
  else logWarn('multi-agent: no browser extension is paired, so sleeping worker chats cannot be reopened');
  return owed.length;
}

/**
 * The browser proved it typed the prime's message into the worker's own chat.
 *
 * Delivery is recorded as an offer, not liveness. The worker stays `waking` until an exact
 * authenticated call proves the model reacted; a different conversation never counts.
 */
export function noteWorkerRevived(
  id: string,
  conversationId: string,
  messageIds: readonly string[],
  commandId: string | null = null, runId?: string
): boolean {
  const run = scopedRun(runId);
  const agent = run?.agents.get(id);
  if (!agent || agent.info.state !== 'waking') return false;
  if (!conversationId || agent.info.conversationId !== conversationId) {
    logWarn(`multi-agent: refused a revival ack for ${id} naming conversation ${conversationId}`);
    return false;
  }
  const now = Date.now();
  agent.info.revivable = false;
  agent.info.finishedAt = null;
  agent.info.result = null;
  if (commandId) agent.info.lastRevivalCommandId = commandId;
  const offered = new Set(messageIds);
  for (const message of agent.queue) {
    if (message.ackedAt !== null || !offered.has(message.id)) continue;
    message.offeredAt = now;
    message.offers += 1;
    message.offeredOnFinish = false;
    message.offeredViaRevival = true;
  }
  recount(agent);
  logInfo(`multi-agent: revival message reached ${id} in conversation ${conversationId}; waiting for worker liveness`);
  changed('critical');
  return true;
}

/**
 * Permanently closes a worker that is already stopped and is now known to be at the context
 * ceiling. This can happen after it was first reported sleeping, or while a wake transaction
 * is being rolled back.
 *
 * Messages never offered to the worker cannot ever be consumed once this state is terminal.
 * Remove those rows and tell the prime exactly what became undeliverable rather than leaving a
 * finished worker with a permanently nonzero inbox. Already-offered rows stay for the existing
 * lost-result retry semantics: they may genuinely have reached the worker.
 */
function finishStoppedWorkerAtCeiling(agent: Agent, reason: string, sleptAt = Date.now()): AgentMessage {
  const now = Date.now();
  const neverOffered = agent.queue.filter(
    (message) => message.ackedAt === null && message.offeredAt === null && !unpublishedMessages.has(message)
  );
  if (neverOffered.length > 0) {
    const doomed = new Set(neverOffered);
    agent.queue = agent.queue.filter((message) => !doomed.has(message));
  }

  agent.info.state = 'finished';
  agent.info.sleptAt = sleptAt;
  agent.info.finishedAt = now;
  agent.info.detachedAt = null;
  agent.info.revivable = false;
  agent.info.silenceParked = false;
  agent.info.silenceRecoveryTurnId = null;
  agent.info.silenceRecoveryRequestOriginMax = null;
  recount(agent);

  const missed =
    neverOffered.length > 0
      ? ` ${neverOffered.length} queued message${neverOffered.length === 1 ? '' : 's'} could not be delivered before that limit` +
        ` (${neverOffered
          .slice(0, 3)
          .map((message) => `“${message.text.slice(0, 180)}”`)
          .join(', ')}${neverOffered.length > 3 ? ', …' : ''}). Those instructions are no longer queued.`
      : '';
  const report = newMessage(
    agent.info.id,
    PRIME_ID,
    `[${agent.info.id} finished for good] ${reason} Its chat has reached the context limit, so it cannot be woken again.` +
      `${missed} Its worker slot is free; spawn a new worker for any remaining work.`
  );
  const prime = primeForOwnedAgent(agent);
  if (!prime) throw new AgentError(`Cannot find the prime that owns ${agent.info.id}.`);
  prime.queue.push(report);
  recount(prime);
  return report;
}

/** Finds the prime row that owns this exact Agent object, active or dormant. */
function primeForOwnedAgent(agent: Agent): Agent | null {
  const run = runForAgent(agent);
  if (run && [...run.agents.values()].includes(agent)) return run.agents.get(PRIME_ID) ?? null;
  for (const dormant of dormantRuns.values()) {
    if ([...dormant.agents.values()].includes(agent)) return dormant.agents.get(PRIME_ID) ?? null;
  }
  return null;
}

/** Returns a failed/rolled-back wake to the only stopped state its current context permits. */
function returnWakingWorkerToStopped(agent: Agent, sleptAt: number, reason: string): AgentMessage | null {
  if (ceilingCrossed(agent.info)) return finishStoppedWorkerAtCeiling(agent, reason, sleptAt);
  agent.info.state = 'sleeping';
  agent.info.sleptAt = sleptAt;
  agent.info.finishedAt = null;
  agent.info.detachedAt = null;
  agent.info.revivable = true;
  recount(agent);
  return null;
}

/** Consecutive failed wakes, with no sign of life from the chat between them, that end a worker. */
export const WAKE_FAILURES_BEFORE_GIVING_UP = 2;
/** Failed wakes per worker conversation since that chat last proved alive. Memory-only: a restart forgives one. */
const consecutiveWakeFailures = new Map<string, number>();
/**
 * Wakes the app repeats by itself after a page that redeemed the wake and failed before Send
 * (#1086: no message box after choosing the model, or its own draft refused as changed). Those
 * pages loaded the chat and typed nothing, so the chat is not in doubt: only after these does such
 * a failure count as a strike. A chat that never loads still counts at once.
 */
export const TRANSIENT_WAKE_RETRIES = 2;
export const TRANSIENT_WAKE_RETRY_MS = 15_000;
const transientWakeRetries = new Map<string, number>();

/**
 * The browser could not wake this worker, so the slot it was holding goes back.
 *
 * Deliberately not a failure of the worker. Nothing was typed into its chat, its queue is
 * untouched and still unacknowledged, and the chat itself is exactly as reusable as it was a
 * moment ago — so it returns to `sleeping` and the prime can try again. The prime is told,
 * because it is holding a message it believes was delivered.
 */
export function failWorkerRevival(id: string, why: string, runId?: string, options: { transient?: boolean } = {}): AgentMessage | null {
  const run = scopedRun(runId);
  const agent = run?.agents.get(id);
  if (!agent || agent.info.state !== 'waking') return null;
  const chat = agent.info.conversationId ?? id;
  if (options.transient) {
    const retries = (transientWakeRetries.get(chat) ?? 0) + 1;
    if (retries <= TRANSIENT_WAKE_RETRIES) {
      // Still waking: the slot stays reserved and the prime is not troubled. The same broker
      // incarnation asks again; a wake that was answered, withdrawn or ended meanwhile is not.
      transientWakeRetries.set(chat, retries);
      const forRun = run!.runId;
      logWarn(`multi-agent: ${id}'s page was not ready (${why}); waking it again in ${TRANSIENT_WAKE_RETRY_MS / 1000} s (${retries}/${TRANSIENT_WAKE_RETRIES})`);
      const timer = setTimeout(() => {
        if (scopedRun(forRun)?.agents.get(id) === agent && agent.info.state === 'waking') requestWorkerRevivals([id], forRun);
      }, TRANSIENT_WAKE_RETRY_MS);
      timer.unref?.();
      return null;
    }
    transientWakeRetries.delete(chat);
  }
  const strikes = (consecutiveWakeFailures.get(chat) ?? 0) + 1;
  consecutiveWakeFailures.set(chat, strikes);
  if (strikes >= WAKE_FAILURES_BEFORE_GIVING_UP && !ceilingCrossed(agent.info)) {
    // The second failed wake with nothing heard from the chat in between is the verdict on the
    // chat, not on the browser. On 2026-09-03 worker-7's ChatGPT conversation answered every
    // load with "This content is unavailable"; four wakes each waited out their deadline and
    // each told the prime "try once more", which it did — thirty minutes and four prime turns
    // before it spawned the replacement it could have spawned after the first repeat. A
    // revivable failure keeps its inbox: the chat calling again brings it back as usual.
    const failed = failAgent(
      id,
      `its chat did not answer ${strikes} revivals in a row (${why})`,
      `[${id} failed] Its chat did not answer ${strikes} revivals in a row: ${why} Treat it as gone — do not try to ` +
        'wake it again. Do that part of the work yourself or spawn a replacement worker. Should its chat ever call ' +
        'in again, you will be told it is back.',
      { revivable: true }, run?.runId
    );
    if (failed) {
      consecutiveWakeFailures.delete(chat);
      return failed.report;
    }
  }
  const terminal = returnWakingWorkerToStopped(
    agent,
    Date.now(),
    `The browser could not complete its revival: ${why}`
  );
  if (terminal) {
    consecutiveWakeFailures.delete(chat);
    logWarn(`multi-agent: could not wake ${id}; the chat crossed its context ceiling while revival was in flight`);
    changed();
    return terminal;
  }
  const report = newMessage(
    id,
    PRIME_ID,
    `[${id} could not be woken] ${why} It is still asleep and still holds everything it knew. Any revival text ChatGPT ` +
      'accepted remains offered but was not proven read, so it will not be injected twice. Its slot is free again: try agents action=message to="' +
      id +
      '" once more, or do that work another way.'
  );
  const prime = primeAgent(run);
  prime.queue.push(report);
  recount(prime);
  logWarn(`multi-agent: could not wake ${id} — ${why}`);
  changed();
  return report;
}

/**
 * What the local session store measured this agent's own chat to be carrying.
 *
 * Fed from the durable session that records this exact conversation, never from anything a
 * model said about itself. Monotonic within a run: a conversation's context only grows, and a
 * transient read of a half-rebuilt summary must not be able to un-cross the ceiling and make a
 * worker revivable again after the prime was told it was finished.
 */
export function noteAgentContextTokens(conversationId: string | null | undefined, tokens: number): void {
  if (!conversationId || !Number.isFinite(tokens) || tokens < 0) return;
  const agent = boundAgent(conversationId) ?? dormantAgentForConversation(conversationId)?.agent ?? null;
  if (!agent || agent.info.contextTokens >= tokens) return;
  const crossed = !ceilingCrossed(agent.info) && tokens >= WORKER_CONTEXT_CEILING_TOKENS;
  agent.info.contextTokens = tokens;
  // Crossing never stops anything. A worker in the middle of a task keeps its slot, its inbox
  // and its right to report; all that changes is that it can no longer be woken afterwards,
  // which is only decided the next time it stops.
  if (crossed && agent.info.role === 'worker') {
    const staged = upgradeStagedFinishAtCeiling(agent);
    if (!staged && agent.info.state === 'sleeping' && !agent.info.silenceParked) {
      finishStoppedWorkerAtCeiling(
        agent,
        'A late measurement crossed the context ceiling after this worker had already stopped.'
      );
    } else if (hasStopped(agent.info.state)) {
      agent.info.revivable = false;
    }
    logInfo(
      `multi-agent: ${agent.info.id} passed the ${WORKER_CONTEXT_CEILING_TOKENS} token ceiling; it keeps working but cannot be woken again`
    );
    // The crossing can revoke wake authority or rewrite a staged finish projection. That is a
    // critical state edge, not optional telemetry: crash recovery must never resurrect the old
    // revivable state after this process has already measured the terminal ceiling.
    changed('critical');
    return;
  }
  changed('telemetry');
}

// -------------------------------------------------------- prime lifecycle

/** Whether a run exists at all. */
export function swarmRunning(runId?: string): boolean { return runId === undefined ? runs.size > 0 : runs.has(runId); }

/** The conversation the prime is bound to, or null when there is no run. */
export function primeConversation(runId?: string): string | null { return scopedRun(runId)?.primeConversationId ?? null; }

/** The run identifier, or null. Names the run in logs, transfers and tool results. */
export function currentRunId(conversationId?: string): string | null { return (conversationId === undefined ? scopedRun() : runForConversation(conversationId))?.runId ?? null; }

/** Whether Compact & Resume currently owns the prime binding transition. */
export function swarmTransferActive(runId?: string): boolean { return runId === undefined ? [...runs.values()].some(r => Boolean(r.transfer)) : Boolean(scopedRun(runId)?.transfer); }

/**
 * The prime chat's tab has gone.
 *
 * Called by the bridge when the prime's tab reports that it closed or navigated away with no
 * transfer open. It used to end the run on the spot, and with one-shot workers that was right:
 * a swarm whose coordinator is gone has nobody to report to, and workers that keep going are
 * tabs writing files for a run nobody is reading.
 *
 * Reusable workers change what a closed prime tab means. The run's whole value is now the
 * chats it has accumulated — workers that already understand the task, asleep and waiting for
 * the next thing to do — and the user's own loop is *the prime stops, I read something else, I
 * come back and give it feedback*. Closing that tab in between is a pause, not a decision, and
 * ending the run over it destroyed every sleeping worker in it. There is deliberately no
 * timeout on the pause either: a run that is worth resuming after ten minutes is worth
 * resuming the next morning, and any clock here would only move the same bug further out.
 *
 * So the prime detaches, exactly as a worker does, and the run waits. It ends here only when
 * there is genuinely nothing left to come back to — no worker still working and none that
 * could be woken — which is the same condition the run would have ended on anyway. Otherwise
 * the user's escape hatch is the explicit one: Clear swarm in the app.
 */
export function primeConversationGone(conversationId: string): boolean {
  const owned = [...runs.values()].filter(run => run.primeConversationId === conversationId);
  return owned.map(run => detachPrimeRun(run, conversationId)).some(ended => ended);
}

function detachPrimeRun(run: Run, conversationId: string): boolean {
  // A handover in flight is the one case where the prime chat is *supposed* to go away.
  if (run.transfer) return false;
  const prime = run.agents.get(PRIME_ID);
  // A terminal worker report is still part of the run until the prime has actually received
  // and acknowledged it. Ending the run merely because every worker is now terminal destroys
  // exactly the result their terminalisation produced. A closed prime tab therefore remains a
  // pause while any prime inbox row is outstanding; reopening the same chat can collect it and
  // ordinary releaseQuiescentRun() retires the run once delivery is safe.
  const pendingPrimeReport = Boolean(prime?.queue.some((message) => message.ackedAt === null));
  const reusable = [...run.agents.values()].some(
    (agent) => agent.info.role === 'worker' && (occupiesSlot(agent.info.state) || canBeRevived(agent.info))
  );
  if (!reusable && !pendingPrimeReport) {
    endRun(run, 'the prime conversation was closed and no worker was left to come back to');
    changed();
    return true;
  }
  if (prime && prime.info.state !== 'detached') {
    prime.info.state = 'detached';
    prime.info.detachedAt = Date.now();
  }
  if (run.primeGoneAt === null) {
    run.primeGoneAt = Date.now();
    logInfo(
      `multi-agent: the prime chat ${conversationId} closed, but its run keeps ${pendingPrimeReport ? 'its undelivered reports' : 'its workers'} until the user returns or clears it`
    );
  }
  changed();
  return false;
}

/** Whether the prime may wake this agent by messaging it. */
function canBeRevived(info: AgentInfo): boolean {
  return info.role === 'worker' && info.state === 'sleeping' && info.revivable;
}

/**
 * Detaches a bound worker when the browser reports its final tab closed.
 *
 * **A closed tab is not a finished worker.** The turn belongs to OpenAI's servers, not to the
 * page: a worker whose chat is closed mid-task keeps thinking, keeps calling this connector,
 * and its calls keep arriving stamped with the same `x-request-id` workflow that
 * correlation.ts has already proved belongs to this exact conversation. Terminalising the
 * slot here was reading the browser's lifecycle as if it were the turn's — the run declared a
 * failure, told the prime to do that work itself, and freed a slot belonging to a worker that
 * was at that moment still writing files.
 *
 * So the browser event is recorded as what it actually is: the view went away. The worker
 * keeps its slot, its binding, its inbox and its right to `finish`, and it ends only when
 * something says something about the *work* — a `finish`, a durably completed turn, a person
 * clearing the row, or {@link sleepSilentWorkers} once the calls stop too.
 */
export function workerConversationGone(conversationId: string): boolean {
  const run = runForConversation(conversationId);
  if (!run || !conversationId) return false;
  const worker = [...run.agents.values()].find(
    (agent) =>
      agent.info.role === 'worker' &&
      agent.info.conversationId === conversationId &&
      occupiesSlot(agent.info.state)
  );
  // A sleeping worker's tab closing is not an event: it was not working, it holds no slot, and
  // the chat is reopened from its id the next time the prime wants it.
  if (!worker || worker.info.state === 'detached' || worker.info.state === 'waking') return false;
  worker.info.state = 'detached';
  worker.info.detachedAt = Date.now();
  worker.info.revivable = true;
  // Nothing is queued for the prime here on purpose. The prime cannot act on "a tab closed",
  // and it is told the one thing it can act on either way: the worker's result when it
  // finishes, or the failure report when it goes quiet. `status` shows `detached` meanwhile.
  logInfo(`multi-agent: ${worker.info.id} detached — its chat was closed while its turn may still be running`);
  changed();
  return true;
}

/** What one piece of first-hand liveness evidence did to the agent it names. */
export interface AliveResult {
  agentId: string;
  /** True only on the call that brought a given-up-on agent back. */
  revived: boolean;
  /** Queued for the prime when the prime had already been told this worker was gone. */
  report: AgentMessage | null;
}

/**
 * First-hand liveness, and the revival it can justify.
 *
 * Exact MCP work and recorder-accepted new output renew the worker's work clock.
 * Page reports prove reachability and attachment only; polling and historical
 * replays never extend the deadline measured by {@link sleepSilentWorkers}.
 * A later proven call or accepted new output can revive a worker that went quiet.
 *
 * Revival is deliberately never something a model can ask for. It is the same evidence that
 * routes every other call — a stored request id, or the extension's own report — arriving at
 * a slot that was closed underneath a turn which never stopped.
 *
 * A revival can put a run one worker over the configured limit, when the prime spawned a
 * replacement in the meantime. That is the honest reading: the worker *is* running, the limit
 * governs how many chats this app will start, and refusing to recognise one that is already
 * working would only make its calls unattributable.
 */
export function noteAgentAlive(
  conversationId: string | null | undefined,
  source: 'call' | 'page' | 'turn' | 'output' = 'call',
  at = Date.now()
): AliveResult | null {
  const primeRuns = conversationId ? [...runs.values()].filter(owner => owner.primeConversationId === conversationId) : [];
  if (primeRuns.length) {
    let revived = false;
    for (const owner of primeRuns) {
      const prime = owner.agents.get(PRIME_ID)!;
      prime.info.lastSeenAt = Date.now();
      if (owner.primeGoneAt !== null || prime.info.state === 'detached') {
        owner.primeGoneAt = null;
        prime.info.state = 'active';
        prime.info.detachedAt = null;
        revived = true;
      }
    }
    if (revived) changed();
    return { agentId: PRIME_ID, revived, report: null };
  }
  const run = runForConversation(conversationId);
  if (!run || !conversationId) return null;
  const agent = boundAgent(conversationId);
  if (!agent) return null;
  // Reachability clears a failed browser wake, but does not renew the work deadline.
  consecutiveWakeFailures.delete(conversationId);
  transientWakeRetries.delete(conversationId);
  const now = Date.now();
  // Page reports establish attachment, never work. Preserve the work clock even when a
  // closed tab returns, so repeated recovery cannot lease an inactive worker forever.
  if (source === 'page') {
    if (agent.info.state === 'detached') {
      agent.info.state = 'active';
      agent.info.detachedAt = null;
      changed();
      return { agentId: agent.info.id, revived: true, report: null };
    }
    return { agentId: agent.info.id, revived: false, report: null };
  }
  // A sleeping worker's *page* is not evidence that it is working. Its tab stays open after
  // its turn settles and keeps reporting the same transcript, so waking on that would undo
  // every sleep the moment it happened and hand the slot straight back. A proven tool call is
  // different: the model in that chat is running, whatever the app decided a moment ago.
  //
  // So is a turn that *started after this app put the worker to sleep*. That is not the old
  // transcript being re-reported, it is a new generation beginning, and it is the model running
  // just as much as a call is. Refusing it made a worker whose request-id path broke unwakeable
  // by construction: its calls arrive with no conversation to wake, so `call` never fires, and
  // every page fact was refused here — the app then slept a worker that was visibly generating
  // and spent the next revival deadline typing at a chat it had already given up on.
  const sleeping = agent.info.state === 'sleeping' || agent.info.state === 'waking';
  const staleTurn = (source === 'turn' || source === 'output') && at <= (agent.info.sleptAt ?? 0);
  // A completed report is stronger than later capture of the same response.
  // Native preambles/statuses often hydrate after finish; they retain their
  // transcript without retracting the report or reclaiming its worker slot.
  // A new accepted turn or exact tool call still proves the worker is working.
  const reportedOutput = source === 'output' && agent.info.result !== null;
  if (sleeping && (staleTurn || reportedOutput)) {
    return { agentId: agent.info.id, revived: false, report: null };
  }
  // Recorder timestamps belong to accepted work, not to the later delivery/replay time.
  const workAt = Math.max(agent.info.lastSeenAt ?? 0, Math.min(now, at));
  // A model turn can keep making connector calls after its browser tab was closed. That call
  // proves the server-side worker is still alive, but it does not prove a page exists again.
  // Keeping `detached` preserves the silence-based escape hatch for a turn whose final call is
  // the last thing this app ever sees; a real page observation below is what clears detachment.
  if (agent.info.state === 'detached' && source === 'call') {
    agent.info.lastSeenAt = workAt;
    return { agentId: agent.info.id, revived: false, report: null };
  }
  const ended =
    agent.info.state !== 'active' && agent.info.state !== 'invited';
  // A worker that was ended on the work's own evidence stays ended: its chat calling again is
  // a model that has not stopped, not a slot to reopen.
  // Redeem makes `revivable=false`; only a delivery marker followed by this exact call, or a
  // turn beginning after that delivery, may finish the wake. Before redeem, a late old-turn
  // call or turn may still prove the wake was unnecessary. Between the two — the browser owns
  // the payload but has not typed it — nothing does, so the page cannot be raced into typing
  // the same words twice.
  //
  // A turn counts because it is the earlier of the two proofs and the one that never depends
  // on the request-id join: the woken model routinely reads for a minute before its first
  // call, and when that call's page evidence is late the worker used to sit in `waking` while
  // its calls piled into Unattributed activity, until the deadline slept it as "could not be
  // woken" under a turn that was visibly running.
  const hasDeliveredRevival =
    Boolean(agent.info.lastRevivalCommandId) ||
    agent.queue.some((message) => message.ackedAt === null && message.offeredViaRevival && message.offeredAt !== null);
  const provedDeliveredWake =
    agent.info.state === 'waking' &&
    (agent.info.revivable || hasDeliveredRevival);
  if (!ended || (!provedDeliveredWake && agent.info.state !== 'detached' && !agent.info.revivable)) {
    agent.info.lastSeenAt = workAt;
    return { agentId: agent.info.id, revived: false, report: null };
  }
  const was = agent.info.state;
  agent.info.state = 'active';
  agent.info.detachedAt = null;
  agent.info.finishedAt = null;
  agent.info.sleptAt = null;
  agent.info.revivable = false;
  agent.info.silenceParked = false;
  agent.info.silenceRecoveryTurnId = null;
  agent.info.silenceRecoveryRequestOriginMax = null;
  agent.info.lastSeenAt = workAt;
  agent.info.result = null;
  if (!agent.info.activatedAt) agent.info.activatedAt = now;
  // Two revivals need saying, and both for the same reason: the prime was told something
  // about this worker that has just stopped being true, and left standing it is how the same
  // work gets done twice or a slot gets counted free while somebody is using it. A worker
  // coming back from `detached` needs nothing said — the prime was never told it had gone.
  let report: AgentMessage | null = null;
  if (was === 'failed' || was === 'sleeping') {
    const how =
      source === 'turn' || source === 'output' ? 'published new work' : 'made another tool call';
    report = newMessage(
      agent.info.id,
      PRIME_ID,
      was === 'failed'
        ? `[${agent.info.id} is back] It was reported gone, but it is working again — it just ${how}. ` +
          'Ignore that earlier report: do not redo its work, and expect its result normally.'
        : `[${agent.info.id} is awake again] It was reported asleep with its slot free, but it never actually ` +
          `stopped — it just ${how}. It is working, it holds its slot again, and its result will arrive the ` +
          'ordinary way. You do not need to wake it.'
    );
    const prime = primeAgent(run);
    prime.queue.push(report);
    recount(prime);
  }
  logInfo(`multi-agent: ${agent.info.id} revived from ${was} — conversation ${conversationId} is still alive (${source})`);
  changed();
  return { agentId: agent.info.id, revived: true, report };
}

/** Every agent bound to a conversation, terminal ones included. Revival has to see those. */
function boundAgent(conversationId: string): Agent | null {
  const run = runForConversation(conversationId);
  if (!run) return null;
  if (conversationId === run.primeConversationId) return run.agents.get(PRIME_ID) ?? null;
  for (const agent of run.agents.values()) {
    if (agent.info.conversationId === conversationId) return agent;
  }
  return null;
}

/**
 * The verdict an ordinary tool call from a bound worker's chat deserves, if it deserves one.
 *
 * A worker that is genuinely over used to learn nothing: its slot was a tombstone, its calls
 * were attributed to nobody, and the file writes went through as if some unrelated chat had
 * made them. So the chat kept working — the one thing nobody wanted — and the user watched a
 * worker it had ended carry on. This is the sentence that tells it, on its own next call.
 *
 * `null` for everything else, including a `detached` worker (still working, still welcome), a
 * revivable one (about to be revived by this very call instead) and a sleeping one — a call
 * from a sleeping worker's chat means it was not asleep, and {@link noteAgentAlive} has
 * already taken its slot back by the time this is asked.
 */
export function endedWorkerNotice(conversationId: string | null | undefined): string | null {
  if (!conversationId) return null;
  const agent = boundAgent(conversationId) ?? dormantAgentForConversation(conversationId)?.agent ?? null;
  if (!agent || agent.info.role !== 'worker' || !isOver(agent.info.state) || agent.info.revivable) return null;
  return (
    `WORKER_ENDED: ${agent.info.id} has already ${agent.info.state === 'finished' ? 'finished' : 'ended'} in this run` +
    `${agent.info.result ? ` (${agent.info.result.slice(0, 200)})` : ''}. Nothing was run. Stop working and stop ` +
    'calling tools: the prime agent is not waiting for anything else from this chat, and anything you do here now is ' +
    'work nobody asked for.'
  );
}

/** Sleep an inactive bound worker in its existing chat, independent of attachment.
 * Running tools protect only their exact worker. Invites/wakes retain their delivery deadline. */
/** When each chat's own page last said its turn is still running. Not work, and never persisted. */
const pageGenerating = new Map<string, number>();

/**
 * The page's own word on whether this chat's turn is still running, from its activity poll.
 *
 * Deliberately not {@link noteAgentAlive}: it renews no work clock and revives nobody. All it
 * does is keep the silence sweep from calling a worker asleep while ChatGPT is visibly still
 * thinking, which it can do for many minutes without a call or a word of output.
 */
export function notePageGenerating(conversationId: string, generating: boolean, at = Date.now()): void {
  if (generating) pageGenerating.set(conversationId, at);
  else pageGenerating.delete(conversationId);
}

function pageStillGenerating(conversationId: string, since: number, now: number): boolean {
  const at = pageGenerating.get(conversationId);
  return at !== undefined && now - at < PAGE_GENERATING_FRESH_MS && now - since < WORKER_THINKING_MAX_MS;
}

export function sleepSilentWorkers(
  now = Date.now(),
  runId?: string,
  isWorking: (conversationId: string) => boolean = () => false,
  unresolvedTurn?: (conversationId: string) => string | null | undefined,
  requestOriginMax?: (conversationId: string) => number | null | undefined
): FinishResult[] {
  const out: FinishResult[] = [];
  for (const agent of [...runs.values()].filter(run => runId === undefined || run.runId === runId).flatMap(run => [...run.agents.values()])) {
    if (agent.info.role !== 'worker' || !['active', 'detached'].includes(agent.info.state) || !agent.info.conversationId) continue;
    if (isWorking(agent.info.conversationId)) continue;
    const since = Math.max(agent.info.activatedAt ?? 0, agent.info.lastSeenAt ?? 0, livenessFloor);
    if (now - since < WORKER_SILENCE_MS) continue;
    if (pageStillGenerating(agent.info.conversationId, since, now)) continue;
    const observedRecoveryTurn = unresolvedTurn?.(agent.info.conversationId);
    const observedRequestOriginMax = requestOriginMax?.(agent.info.conversationId);
    // A caller-scoped sweep may know nothing about another worker's durable turn. Unknown is not
    // evidence for discarding that worker's exact continuation authority; leave it active until
    // the bridge's owner-wide sweep can read its session. A known open turn also needs a durable
    // pre-park request boundary before it can be parked recoverably.
    if (
      ceilingCrossed(agent.info) &&
      ((unresolvedTurn && observedRecoveryTurn === undefined) ||
        (observedRecoveryTurn && requestOriginMax && !Number.isFinite(observedRequestOriginMax)))
    ) {
      continue;
    }
    const recoveryTurnId = observedRecoveryTurn ?? null;
    const recoveryRequestOriginMax = Number.isFinite(observedRequestOriginMax)
      ? observedRequestOriginMax!
      : null;
    if (ceilingCrossed(agent.info)) {
      agent.info.state = 'sleeping';
      agent.info.sleptAt = Date.now();
      agent.info.finishedAt = null;
      agent.info.detachedAt = null;
      agent.info.revivable = false;
      agent.info.silenceParked = true;
      agent.info.silenceRecoveryTurnId = recoveryTurnId;
      agent.info.silenceRecoveryRequestOriginMax = recoveryRequestOriginMax;
      recount(agent);
      const report = newMessage(
        agent.info.id,
        PRIME_ID,
        `[${agent.info.id} paused at context limit] No new activity was observed for three minutes, but its current turn has not durably finished. Its slot is free and no new work may be assigned to this chat. ` +
          (recoveryTurnId && recoveryRequestOriginMax !== null
            ? 'An exact late call already proven to belong to that same turn may resume it.'
            : 'No exact turn continuation can be proven here; wait for durable terminal evidence.')
      );
      const run = runForAgent(agent);
      if (!run) continue;
      const prime = primeAgent(run);
      prime.queue.push(report);
      recount(prime);
      changed('critical');
      out.push({ info: { ...agent.info }, report: { ...report }, repeat: false });
      continue;
    }
    const outcome = sleepAgent(
      agent,
      'No new assistant output, native work or tool activity was observed for three minutes. Its chat is preserved and can be resumed.'
    );
    if (outcome) {
      if (outcome.info.state === 'sleeping') {
        // Remember that this stop came only from silence, independently of whether recorder state
        // currently names the response. The optional exact turn id is latent provenance below the
        // ceiling; if delayed token accounting later crosses 400k, silenceParked prevents the
        // accounting edge from turning this ambiguous stop into a terminal verdict.
        agent.info.silenceParked = true;
        agent.info.silenceRecoveryTurnId = recoveryTurnId;
        agent.info.silenceRecoveryRequestOriginMax = recoveryRequestOriginMax;
        outcome.info.silenceParked = true;
        outcome.info.silenceRecoveryTurnId = recoveryTurnId;
        outcome.info.silenceRecoveryRequestOriginMax = recoveryRequestOriginMax;
        changed('critical');
      }
      out.push(outcome);
    }
  }
  return out;
}

/**
 * Notes that the app's own Compact & Resume is moving this session to a new chat.
 *
 * Deliberately *not* a second one-time-token system. The single continuation transaction
 * lives in the session layer, which owns the durable local session and its one-time token;
 * the swarm binding is one of the things that transaction moves, alongside the workspace and
 * the recorded history. All this flag does is stop {@link primeConversationGone} from
 * killing the run while chat A is being replaced, which is the one moment the prime chat is
 * *supposed* to disappear.
 */
export function beginPrimeTransfer(conversationId: string): boolean {
  const owned = allFamilies().filter(owner => owner.primeConversationId === conversationId);
  for (const owner of owned) owner.transfer = { from: conversationId, at: Date.now(), frozen: false };
  return owned.length > 0;
}

/** Abandons an open handover, so the prime stays where it is. */
export function cancelPrimeTransfer(conversationId: string): void {
  for (const owner of allFamilies()) if (owner.transfer?.from === conversationId) owner.transfer = null;
}

/**
 * What the session layer must know *before* it starts writing, and the point of no expiry.
 *
 * The commit is a fallible durable write followed by moves that have to be total, and the
 * swarm move is the one that used to be neither: it re-checked its own deadline inside the
 * total phase, so a commit that preflighted fine, then spent a second on disk, could leave
 * the durable session in chat B with the swarm still bound to chat A. So the decision is
 * taken here, once, before the write:
 *
 *   `absent`      — this chat is not the prime of any run. There is nothing to move, and the
 *                   session rebind is free to proceed.
 *   `unavailable` — it *is* the prime, but no usable handover is open. The caller must refuse
 *                   the whole commit; a session that moved without its swarm is the split this
 *                   exists to prevent.
 *   `frozen`      — the handover is now pinned and {@link commitPrimeTransfer} will succeed
 *                   for this pair unless the run itself ends in the meantime, which is a
 *                   terminal state rather than a half-commit: there is no prime left in chat A
 *                   to be inconsistent with.
 *
 * A freeze whose commit does not happen is released with {@link thawPrimeTransfer}, which
 * leaves the handover open, so a retry is still possible.
 */
export function freezePrimeTransfer(fromConversationId: string): 'absent' | 'unavailable' | 'frozen' {
  const owned = allFamilies().filter(owner => owner.primeConversationId === fromConversationId);
  if (!owned.length) return 'absent';
  if (owned.some(owner => owner.transfer?.from !== fromConversationId || !owner.agents.has(PRIME_ID))) return 'unavailable';
  for (const owner of owned) owner.transfer!.frozen = true;
  return 'frozen';
}

/** Undoes a freeze whose commit did not happen, leaving the handover open. */
export function thawPrimeTransfer(fromConversationId: string): void {
  for (const owner of allFamilies()) if (owner.transfer?.from === fromConversationId) owner.transfer.frozen = false;
}

/**
 * Moves the prime binding as part of the session rebind commit.
 *
 * Called only from the commit step of the session continuation transaction, after
 * {@link freezePrimeTransfer} authorised it and after that transaction has proven chat B is
 * real and usable. Deliberately has no deadline of its own — the freeze is the deadline — so
 * the only way this can now decline is that the run ended entirely while the write was in
 * flight, and a run that no longer exists cannot be left behind in chat A.
 *
 * Returns false, changing nothing, when there is no handover open from that exact
 * conversation, which is what stops a stray chat from inheriting a swarm.
 */
export function commitPrimeTransfer(fromConversationId: string, toConversationId: string): boolean {
  if (!fromConversationId || !toConversationId || fromConversationId === toConversationId) return false;
  const owned = allFamilies().filter(owner => owner.primeConversationId === fromConversationId);
  if (!owned.length || owned.some(owner => owner.transfer?.from !== fromConversationId ||
    !owner.agents.has(PRIME_ID) || conversationOwnedOutside(owner.agents, fromConversationId, toConversationId))) return false;
  for (const owner of owned) {
    owner.primeConversationId = toConversationId;
    owner.agents.get(PRIME_ID)!.info.conversationId = toConversationId;
    for (const agent of owner.agents.values()) agent.info.primeConversationId = toConversationId;
    owner.transfer = null;
  }
  logInfo(`multi-agent: moved ${owned.length} prime fleet(s) from ${fromConversationId} to ${toConversationId}`);
  changed();
  return true;
}

/** No prime transfer may land on a worker conversation or another prime owner's history. */
function conversationOwnedOutside(ownerAgents: Map<string, Agent>, fromConversationId: string, toConversationId: string): boolean {
  if (toConversationId === fromConversationId) return false;
  for (const run of runs.values()) {
    if (run.agents === ownerAgents) continue;
    if (run.primeConversationId === toConversationId) return true;
    if ([...run.agents.values()].some((agent) => agent.info.conversationId === toConversationId)) return true;
  }
  for (const dormant of dormantRuns.values()) {
    if (dormant.agents === ownerAgents) continue;
    if (dormant.primeConversationId === toConversationId) return true;
    if ([...dormant.agents.values()].some((agent) => agent.info.conversationId === toConversationId)) return true;
  }
  return [...ownerAgents.values()].some(
    (agent) => agent.info.id !== PRIME_ID && agent.info.conversationId === toConversationId
  );
}

/**
 * A stopped-but-reusable worker in dormant history is still a worker conversation, not an
 * ordinary chat. Kernel integration uses this to fail closed if that old tab unexpectedly calls
 * a local tool while another prime owns its own active incarnation.
 */
export function dormantWorkerNotice(conversationId: string | null | undefined): string | null {
  const found = dormantAgentForConversation(conversationId);
  const agent = found?.agent ?? null;
  if (!agent || agent.info.role !== 'worker') return null;
  if (isOver(agent.info.state)) {
    return (
      `WORKER_ENDED: ${agent.info.id} remains part of its prime's dormant worker history but is ${agent.info.state} and cannot act again. ` +
      'Nothing was run. Stop working and return to the prime conversation.'
    );
  }
  if (agent.info.state !== 'sleeping' || !agent.info.revivable) return null;
  return (
    `WORKER_SLEEPING: ${agent.info.id} belongs to the dormant worker history owned by its prime conversation. ` +
    'Nothing was run. Stay stopped until that prime sends a new agents message into this exact chat.'
  );
}

/**
 * Worker chats whose tabs the browser may close, oldest first.
 *
 * A worker that has stopped — asleep, finished or failed — holds no slot and needs no page:
 * a sleeping one is woken by opening its chat again, and a terminal one is never opened
 * again. Its tab is pure cost, and by the end of a long run that cost is the machine: on
 * 2026-09-01 thirteen workers left Chrome at thirty-four processes and five gigabytes with
 * the prime still working. So all but the `keep` most recently used stopped worker chats
 * are handed to the browser to close, across the active run and every parked family.
 * Recency is the last thing that happened to the worker, so a chat the prime keeps coming
 * back to stays open while ones it has moved on from go.
 */
export function closableWorkerConversations(keep: number): string[] {
  const stopped: Array<{ conversationId: string; usedAt: number }> = [];
  const families = [...runs.values(), ...dormantRuns.values()].map(owner => owner.agents);
  for (const agents of families) {
    for (const agent of agents.values()) {
      const info = agent.info;
      if (info.role !== 'worker' || !info.conversationId || unpublishedAgents.has(agent)) continue;
      if (info.state === 'sleeping' && info.silenceParked && !info.revivable) continue;
      if (info.state !== 'sleeping' && info.state !== 'finished' && info.state !== 'failed') continue;
      stopped.push({
        conversationId: info.conversationId,
        usedAt: Math.max(info.activatedAt ?? 0, info.sleptAt ?? 0, info.finishedAt ?? 0, info.lastSeenAt ?? 0)
      });
    }
  }
  stopped.sort((a, b) => a.usedAt - b.usedAt);
  const surplus = Math.max(0, stopped.length - Math.max(0, keep));
  return stopped.slice(0, surplus).map((entry) => entry.conversationId);
}

/** Any dormant worker conversation remains an identity fence, reusable or terminal. */
export function hasDormantWorkerLeases(): boolean {
  for (const dormant of dormantRuns.values()) {
    if (
      [...dormant.agents.values()].some(
        (agent) => agent.info.role === 'worker' && Boolean(agent.info.conversationId)
      )
    ) {
      return true;
    }
  }
  return false;
}

/**
 * Recovery-only repair for the one crash ordering normal transfer cannot represent.
 *
 * Compact & Resume durably moves session S from chat A to chat B before publishing the
 * in-memory swarm move. If the process dies between those two steps, restore intentionally
 * brings the swarm back without its volatile transfer flag, so {@link commitPrimeTransfer}
 * must (and does) refuse. Continuation recovery can nevertheless prove from its WAL plus the
 * durable session metadata that A→B already committed. This hook lets that recovery authority
 * repair the projection without inventing a new transfer.
 *
 * It is deliberately not a general takeover API and is never exposed to MCP. The caller must
 * already have durable proof of this exact A→B transition. We additionally fail closed if B is
 * bound to any worker in the restored run. Repeating the same proven repair is idempotent.
 */
/** Whether a sub-agent fleet is led from this chat. */
export function primeFleetIn(conversationId: string): boolean {
  return allFamilies().some(owner => owner.primeConversationId === conversationId);
}

export function repairPrimeConversationAfterRecovery(
  fromConversationId: string,
  toConversationId: string
): boolean {
  if (!fromConversationId || !toConversationId || fromConversationId === toConversationId) return false;
  const owned = allFamilies().filter(owner => owner.primeConversationId === fromConversationId);
  if (!owned.length) return allFamilies().some(owner => owner.primeConversationId === toConversationId);
  if (owned.some(owner => !owner.agents.has(PRIME_ID) ||
    conversationOwnedOutside(owner.agents, fromConversationId, toConversationId))) return false;
  for (const owner of owned) {
    owner.primeConversationId = toConversationId;
    owner.agents.get(PRIME_ID)!.info.conversationId = toConversationId;
    for (const agent of owner.agents.values()) agent.info.primeConversationId = toConversationId;
    owner.transfer = null;
  }
  logInfo(`multi-agent: recovered ${owned.length} prime fleet(s) from ${fromConversationId} to ${toConversationId}`);
  changed();
  return true;
}

// -------------------------------------------------------------------- state

function stateForAgents(agents: Map<string, Agent>, running: boolean, retainedHistory = !running): SwarmState {
  const list = [...agents.values()]
    .filter((agent) => !unpublishedAgents.has(agent))
    .map((agent) => ({ ...agent.info }));
  list.sort((a, b) => (a.role === b.role ? a.id.localeCompare(b.id) : a.role === 'prime' ? -1 : 1));
  return {
    enabled: getConfig().multiAgent.enabled,
    running,
    retainedHistory,
    agents: list
  };
}

export function swarmState(runId?: string): SwarmState {
  const visible = [...runs.values()].filter(r => !unpublishedRuns.has(r) && (runId === undefined || r.runId === runId));
  return { enabled: getConfig().multiAgent.enabled, running: visible.length > 0, retainedHistory: dormantRuns.size > 0,
    retainedWorkers: [...dormantRuns.values()].filter(r => runId === undefined || answersTo(r, runId))
      .flatMap(r => stateForAgents(r.agents, false).agents.filter(agent => agent.role === 'worker')),
    agents: visible.flatMap(r => stateForAgents(r.agents, true).agents) };
}

export function agentConversation(id: string, runId?: string): string | null {
  const run = scopedRun(runId);
  return run?.agents.get(id)?.info.conversationId ?? null;
}

/** Reverse lookup used to file a recorded event into the right session. */
export function agentForConversation(conversationId: string): string | null {
  if ([...runs.values()].some(owner => !unpublishedRuns.has(owner) && owner.primeConversationId === conversationId)) return PRIME_ID;
  const run = runForConversation(conversationId);
  if (!run) return null;
  if (conversationId === run.primeConversationId) return PRIME_ID;
  for (const agent of run.agents.values()) {
    if (agent.info.conversationId === conversationId) return agent.info.id;
  }
  return null;
}

/**
 * Exact conversation ownership for durable recording/presentation, active or dormant.
 *
 * This deliberately does not reactivate anything and is not a command-authority lookup. A
 * sleeping/terminal worker keeps the same recorder identity after its active run parks, while
 * independently durable browser commands continue to use {@link agentForConversation} plus the
 * current run-id fence so old transport rows can never attach to dormant history.
 */
export function agentForOwnedConversation(conversationId: string): string | null {
  return agentInfoForOwnedConversation(conversationId)?.id ?? null;
}

/** Exact prime identity for presentation; does not activate or adopt a parked run. */
export function primeForOwnedConversation(conversationId: string): string | null {
  if (allFamilies().some(owner => !unpublishedRuns.has(owner as Run) && owner.primeConversationId === conversationId)) return conversationId;
  const run = runForConversation(conversationId);
  if (run && agentForConversationId(conversationId)) return run.primeConversationId;
  return dormantAgentForConversation(conversationId)?.owner.primeConversationId ?? null;
}

export interface WorkerPrimeOwner {
  /** True only when this exact conversation is durably/presently owned by a worker slot. */
  owned: boolean;
  /** Null for ambiguous/provisional ownership: strict authorization must fail closed. */
  primeConversationId: string | null;
  /** Current family incarnation, useful for diagnostics only; never an authorization token. */
  runId: string | null;
  /** Connection provenance when this family was created; absent/null for legacy histories. */
  setupProfileId?: string | null;
}

/**
 * Exact worker -> prime provenance across active, terminal and dormant worker history.
 *
 * Unlike the presentation helpers above, authorization must not lose a worker merely because it
 * finished, slept or parked. Inspect the published families directly, exclude unpublished staged
 * runs, and refuse to guess if corrupted/restored state names the same worker chat twice.
 */
export function workerPrimeOwner(conversationId: string): WorkerPrimeOwner {
  if (!conversationId) return { owned: false, primeConversationId: null, runId: null };
  const owners = allFamilies().filter((owner) => {
    if ('runId' in owner && unpublishedRuns.has(owner)) return false;
    return [...owner.agents.values()].some(
      (agent) => agent.info.role === 'worker' && agent.info.conversationId === conversationId
    );
  });
  if (owners.length === 0) return { owned: false, primeConversationId: null, runId: null };
  if (owners.length !== 1) return { owned: true, primeConversationId: null, runId: null };
  const owner = owners[0]!;
  return {
    owned: true,
    primeConversationId: owner.primeConversationId ?? null,
    runId: familyKey(owner),
    setupProfileId: owner.setupProfileId ?? null
  };
}

/** A currently occupied slot; parked history must not grant or refuse browser recovery. */
export function liveAgentForOwnedConversation(conversationId: string): AgentInfo | null {
  const agent = agentForConversationId(conversationId);
  return agent ? { ...agent.info } : null;
}

/** Read-only exact owner metadata for recorder/origin reconstruction across parked histories. */
export function agentInfoForOwnedConversation(conversationId: string): AgentInfo | null {
  const primes = allFamilies().filter(owner => !unpublishedRuns.has(owner as Run) && owner.primeConversationId === conversationId)
    .map(owner => owner.agents.get(PRIME_ID)!.info);
  if (primes.length) return { ...primes[0]!, runId: primes.length === 1 ? primes[0]!.runId : undefined,
    pending: primes.reduce((sum, prime) => sum + prime.pending, 0),
    awaitingAck: primes.reduce((sum, prime) => sum + prime.awaitingAck, 0),
    delivered: primes.reduce((sum, prime) => sum + prime.delivered, 0) };
  const run = runForConversation(conversationId);
  if (run) {
    const active = agentForConversationId(conversationId);
    if (active) return { ...active.info };
  }
  const dormant = dormantAgentForConversation(conversationId)?.agent ?? null;
  return dormant ? { ...dormant.info } : null;
}

/**
 * Whether this conversation is a worker chat this app opened — in any state, ever.
 *
 * The owner lookups above answer "who is working here", and deliberately skip a worker that
 * is over: a finished chat calling tools is not a slot. This answers the other question, the
 * one the Goal and compaction fences ask: is this a chat the loop may author in, or that a
 * Compact & Resume may be typed into? A worker chat never becomes an ordinary chat by
 * finishing. On 2026-09-03 two workers crossed the context ceiling, went terminal, and were
 * from that moment invisible to `agentForOwnedConversation()`; the auto-compaction fence read
 * them as plain chats over the line, filed tickets a worker page can never discharge, and
 * reloaded each working page five times before giving up.
 */
export function isWorkerConversation(conversationId: string): boolean {
  if (!conversationId) return false;
  const owns = (agents: Map<string, Agent>): boolean =>
    [...agents.values()].some((agent) => agent.info.role === 'worker' && agent.info.conversationId === conversationId);
  for (const run of runs.values()) if (owns(run.agents)) return true;
  for (const dormant of dormantRuns.values()) if (owns(dormant.agents)) return true;
  return false;
}

/**
 * Binds a worker to the ChatGPT conversation it is running in, and starts it.
 *
 * This *is* the worker lifecycle transition. Called by the bridge when the extension
 * acknowledges the tab it opened — the one party that knows the mapping first-hand, and knows
 * it before the model in that tab has said anything — so by the time the worker reads its task
 * it is already an active member of the run and its later calls route by conversation alone.
 * Nothing is asked of the model to make that true.
 *
 * It can never move the prime: that binding is set once by `spawn` and moved only by an
 * authenticated transfer. It can never move a worker either — see
 * {@link bindWorkerConversation} for why one binding per slot and one slot per conversation
 * is an invariant rather than a preference.
 */
export function bindConversation(id: string, conversationId: string, runId?: string): boolean {
  const run = scopedRun(runId);
  const agent = run?.agents.get(id);
  if (!agent || agent.info.role !== 'worker' || hasStopped(agent.info.state)) return false;
  if (unpublishedAgents.has(agent)) return false;
  const bound = activateWorker(agent, conversationId);
  if (bound && run) bindAgentWorkspace(id, conversationId, run.runId);
  return bound;
}

/**
 * Binds a worker to its conversation and makes it active, in one indivisible step.
 *
 * One step on purpose. A slot that is bound but not yet active is a state nothing can act
 * on and everything has to special-case: the bridge cannot tell whether its bootstrap
 * succeeded, `pendingWorkerSpawns` still owes it a tab, and the prime waits on a worker that
 * is, in every sense that matters, already running. Activation on binding is what makes
 * "the app opened this chat for this slot" and "this worker is running" the same fact.
 */
function activateWorker(agent: Agent, conversationId: string): boolean {
  const wasBound = agent.info.conversationId !== null;
  if (!bindWorkerConversation(agent, conversationId)) return false;
  let mutated = !wasBound;
  if (agent.info.state === 'invited') {
    agent.info.state = 'active';
    agent.info.activatedAt = Date.now();
    logInfo(`multi-agent: ${agent.info.id} is active in conversation ${conversationId}`);
    mutated = true;
  }
  // Binding and activation are one durable state transition. Persisting from
  // bindWorkerConversation used to expose an impossible intermediate snapshot — a worker with
  // a conversation while still `invited`. A crash after that first snapshot made restart open
  // a second tab for the already-bound worker and then fail the slot when the new chat could
  // not steal its binding.
  if (mutated) changed();
  return true;
}

/**
 * The one place a worker's conversation is ever set. Exactly once, and to a free chat.
 *
 * Two invariants, both load-bearing for identity:
 *
 *   *One binding per slot.* A worker already running in a conversation stays there. Every
 *   later report of a different chat is either a mistake or someone else's tab, and honouring
 *   it would point the worker's messages, its recorded events and its workspace at a chat
 *   that is not doing the work — while the chat that *is* doing it stops being recognised at
 *   all. A binding is only re-set to the identical value, which is a no-op.
 *
 *   *One slot per conversation.* A conversation already holding the prime or another live
 *   worker cannot be bound again, or one chat would answer to two identities and
 *   {@link agentForConversation} would file its work under whichever it found first.
 *
 * The second check counts finished workers too. Their chats are tombstones: still readable,
 * never re-usable, and a new worker inheriting one would make the transcript of a worker that
 * is over look like the transcript of the one that replaced it.
 */
function bindWorkerConversation(agent: Agent, conversationId: string): boolean {
  if (!conversationId) return false;
  if (agent.info.conversationId === conversationId) return true;
  if (agent.info.conversationId) {
    logWarn(
      `multi-agent: refused to move ${agent.info.id} from conversation ${agent.info.conversationId} to ${conversationId}`
    );
    return false;
  }
  const taken = boundAgent(conversationId);
  if (taken && taken !== agent) {
    logWarn(`multi-agent: refused to bind ${agent.info.id} to conversation ${conversationId}, already held by ${taken.info.id}`);
    return false;
  }
  const dormantTaken = dormantAgentForConversation(conversationId);
  if (dormantTaken) {
    logWarn(
      `multi-agent: refused to bind ${agent.info.id} to conversation ${conversationId}, already owned by dormant ${dormantTaken.agent.info.id}`
    );
    return false;
  }
  agent.info.conversationId = conversationId;
  return true;
}

/** Explicit destructive clear. Feature-off uses pauseSwarmForDisable() and preserves histories. */
export function resetSwarm(): void {
  const reason = 'the run was cleared in the app';
  for (const run of [...runs.values()]) endRun(run, reason);
  consecutiveWakeFailures.clear();
  transientWakeRetries.clear();
  const retiredAt = Date.now();
  let retiredDormant = false;
  const dormantChats: string[] = [];
  for (const dormant of dormantRuns.values()) {
    retireManagedWorktreeCleanupOffers(dormant.agents.values(), 'cleared');
    for (const agent of dormant.agents.values()) {
      if (agent.info.role !== 'worker' || !agent.info.conversationId) continue;
      if (agent.info.managedWorktree) retiredManagedWorkerConversations.add(agent.info.conversationId);
      retiredWorkers.set(agent.info.conversationId, {
        id: agent.info.id,
        conversationId: agent.info.conversationId,
        reason,
        retiredAt
      });
      dormantChats.push(agent.info.conversationId);
      retiredDormant = true;
    }
  }
  dormantRuns.clear();
  if (retiredDormant) retiredPersist?.();
  announceRetired(dormantChats);
  changed();
}

/**
 * Turns live multi-agent execution off without deleting the prime-owned worker histories.
 *
 * A feature toggle is not the destructive "Clear swarm" action. Bound workers become stopped
 * but reusable (or terminal if their exact chat is already full); a bootstrap that never got a
 * conversation becomes a terminal historical row. The whole owner map then parks normally, so
 * stale worker tabs remain fenced while the feature is off and the same exact chats can be
 * resumed after re-enable/restart.
 *
 * An unpublished spawn has not been accepted/launched yet, so cancel that topology transaction
 * first rather than preserving rows ChatGPT was never told existed.
 */
export function pauseSwarmForDisable(reason = 'multi-agent mode was turned off'): boolean {
  for (const stage of [...activeSpawnStages.values()]) settleSpawnStage(stage, false);
  const now = Date.now();
  let parked = false;
  let terminalizedDormant = false;
  for (const run of [...runs.values()]) {
  for (const agent of run.agents.values()) {
    if (agent.info.role !== 'worker') continue;
    const unresolvedCeilingTurn =
      agent.info.state === 'sleeping' && agent.info.silenceParked === true;
    if (hasStopped(agent.info.state) && !unresolvedCeilingTurn) continue;
    if (!agent.info.conversationId) {
      agent.info.state = 'failed';
      agent.info.finishedAt = now;
      agent.info.sleptAt = null;
      agent.info.detachedAt = null;
      agent.info.revivable = false;
      agent.info.silenceParked = false;
      agent.info.silenceRecoveryTurnId = null;
      agent.info.silenceRecoveryRequestOriginMax = null;
      agent.info.result = reason.slice(0, MAX_MESSAGE_CHARS);
      agent.queue = [];
      recount(agent);
      continue;
    }

    const terminal = ceilingCrossed(agent.info);
    agent.info.state = terminal ? 'finished' : 'sleeping';
    agent.info.sleptAt = now;
    agent.info.finishedAt = terminal ? now : null;
    agent.info.detachedAt = null;
    agent.info.revivable = !terminal;
    agent.info.silenceParked = false;
    agent.info.silenceRecoveryTurnId = null;
    agent.info.silenceRecoveryRequestOriginMax = null;
    recount(agent);
  }

  parked = parkRun(run, reason) || parked;
  }
  for (const dormant of dormantRuns.values()) {
    for (const agent of dormant.agents.values()) {
      if (
        agent.info.role !== 'worker' ||
        agent.info.state !== 'sleeping' ||
        !agent.info.silenceParked ||
        !ceilingCrossed(agent.info)
      ) {
        continue;
      }
      agent.info.state = 'finished';
      agent.info.sleptAt ??= now;
      agent.info.finishedAt = now;
      agent.info.detachedAt = null;
      agent.info.revivable = false;
      agent.info.silenceParked = false;
      agent.info.silenceRecoveryTurnId = null;
      agent.info.silenceRecoveryRequestOriginMax = null;
      recount(agent);
      terminalizedDormant = true;
    }
  }
  if (terminalizedDormant || runs.size === 0) changed();
  return parked || terminalizedDormant;
}

/** What a clear actually did, so the UI can say it rather than guess. */
export interface ClearResult {
  cleared: 'run' | 'worker' | 'none';
  report: AgentMessage | null;
  reason: string;
}

/**
 * The user clearing one row in the app.
 *
 * The prime *is* the run, so clearing it ends everything — there is no such thing as a run
 * whose prime was removed but whose workers continue. A worker is one slot: it is
 * terminalised, never deleted, so the row stays visible and honestly labelled as over while
 * its queued bootstrap is retired and the slot frees up.
 */
export function clearAgent(id: string, runId?: string): ClearResult {
  const run = scopedRun(runId);
  if (id === PRIME_ID) {
    if (!run) return { cleared: 'none', report: null, reason: 'there is no run to clear' };
    // Row-level clear is scoped to the active owner the row belongs to. `resetSwarm()` is the
    // explicit global "Clear swarm" operation and intentionally destroys every dormant owner
    // history too; using it here would let clearing Prime B's visible row erase parked Prime A
    // workers that are not even present in this renderer list.
    const reason = 'the run was cleared in the app';
    endRun(run, reason);
    changed();
    return { cleared: 'run', report: null, reason };
  }
  const agent = run?.agents.get(id);
  if (!agent) return { cleared: 'none', report: null, reason: `${id} is not part of this run` };
  if (isOver(agent.info.state)) return { cleared: 'none', report: null, reason: `${id} has already ended` };
  // Clearing a sleeping worker is the user saying they are done with that chat for good. It is
  // still a terminalisation, so it goes through failAgent like any other; what makes it worth
  // saying separately is that the row was not costing the run a slot.

  const reason = 'the user cleared this worker in the app';
  const outcome = failAgent(
    id,
    reason,
    `[${id} cleared] The user ended this worker from the app. It will not report and cannot be messaged. Carry on ` +
      'without it, or spawn a replacement worker if the work still needs doing.', {}, run?.runId
  );
  if (outcome) {
    retireManagedWorktreeCleanupOffers([agent], 'cleared');
    changed();
  }
  return { cleared: 'worker', report: outcome?.report ?? null, reason };
}

// -------------------------------------------------------------- persistence

export interface RetiredWorkersSnapshot {
  version: 1;
  savedAt: number;
  workers: RetiredChat[];
}

export function snapshotRetiredWorkers(): RetiredWorkersSnapshot {
  pruneRetiredWorkers();
  return { version: 1, savedAt: Date.now(), workers: [...retiredWorkers.values()].map((worker) => ({ ...worker })) };
}

export function restoreRetiredWorkers(snapshot: RetiredWorkersSnapshot | null): void {
  retiredWorkers.clear();
  if (!snapshot || snapshot.version !== 1 || !Array.isArray(snapshot.workers)) return;
  const cutoff = Date.now() - RETIRED_WORKER_TTL_MS;
  // Every still-live lease is authority state. The old `slice(-64)` matched the previous
  // lifetime worker-id ceiling, but histories are now intentionally unbounded; after explicit
  // clear a long-lived prime can retire more than 64 worker conversations at once. Dropping the
  // oldest rows on restart would let those still-open worker chats become ordinary callers.
  for (const worker of snapshot.workers) {
    if (
      !worker ||
      typeof worker.id !== 'string' ||
      typeof worker.conversationId !== 'string' ||
      !worker.conversationId ||
      typeof worker.reason !== 'string' ||
      !Number.isFinite(worker.retiredAt) ||
      worker.retiredAt < cutoff
    ) {
      continue;
    }
    retiredWorkers.set(worker.conversationId, { ...worker });
  }
}

/**
 * What survives a restart.
 *
 * Agent state and unacknowledged messages are the parts that cannot be reconstructed: the
 * session log is the audit trail, but it does not know which messages were still in flight.
 * Nothing here is a credential: an agent is the conversation it runs in, and that id is
 * recorded on purpose.
 */
interface SerializedAgent {
  info: AgentInfo;
  queue: AgentMessage[];
}

interface DormantRunSnapshot {
  formerRunIds?: string[];
  setupProfileId?: string;
  primeConversationId: string | null;
  primeRequestId?: string;
  localOwnerId?: string;
  startedAt: number;
  parkedAt: number;
  agents: SerializedAgent[];
}

export interface SwarmSnapshot {
  /**
   * 7 adds provisional request owners and multiple recovered fleets per prime. 6 introduced
   * independent activeRuns plus dormant histories. Top-level fields remain a sole-run
   * compatibility projection; versions 6/7 restore from activeRuns.
   * Versions 4/5 migrate their single active incarnation; versions
   * before 4 are discarded because their worker identity depended on routing codes this build
   * cannot honour.
   */
  version: 4 | 5 | 6 | 7;
  activeRuns?: Array<{ runId: string; formerRunIds?: string[]; setupProfileId?: string; primeConversationId: string | null; primeRequestId?: string; localOwnerId?: string; startedAt: number; agents: SerializedAgent[] }>;
  savedAt: number;
  /** Top-level fields are the active incarnation; all are null/empty while only history remains. */
  runId: string | null;
  setupProfileId?: string;
  primeConversationId: string | null;
  localOwnerId?: string;
  startedAt: number | null;
  agents: SerializedAgent[];
  dormantRuns?: DormantRunSnapshot[];
  /** Denial-only managed worker identities after family eviction or explicit Clear. */
  managedRetiredConversations?: string[];
  /** Cleanup-only authority retained when a managed worker's family leaves broker history. */
  managedWorktreeCleanupOffers?: ManagedWorktreeCleanupOffer[];
}

/**
 * Project eligible terminal workers from the exact snapshot generation being persisted.
 * The immediate snapshot includes accepted finish overlays while the ordinary snapshot omits
 * them, so a failed staged finish can never leak an offer into a debounced disk write.
 */
function collectManagedWorktreeCleanupOffers(groups: readonly (readonly SerializedAgent[])[]): ManagedWorktreeCleanupOffer[] {
  const offers = new Map(managedWorktreeCleanupHistory);
  const candidates = new Map<string, ManagedWorktreeCleanupOffer[]>();
  for (const group of groups) for (const { info } of group) {
    const identity = cleanupIdentity(info);
    if (!identity || cleanupAcknowledged(info)) continue;
    if (info.state !== 'finished' && !(info.state === 'failed' && info.revivable !== true)) continue;
    const key = cleanupOfferKey(identity);
    candidates.set(key, [...(candidates.get(key) ?? []), {
      ...identity,
      reason: info.state === 'finished' ? 'completed' : 'failed',
      createdAt: info.finishedAt ?? info.sleptAt ?? Date.now(),
      label: cleanupDisplayLabel(info)
    }]);
  }
  // A duplicated restored identity cannot grant cleanup authorization by either record.
  for (const [key, matches] of candidates) {
    if (matches.length !== 1 || offers.has(key)) continue;
    offers.set(key, matches[0]!);
  }
  return [...offers.values()]
    .sort((a, b) => a.createdAt - b.createdAt || cleanupOfferKey(a).localeCompare(cleanupOfferKey(b)));
}

/**
 * Authoritative broker identities eligible for an opt-in cleanup offer. Caller must cross
 * persistAgentAuthorityNow() before publishing these to UI, and the worktree manager must
 * independently verify the marker and Git lease before any filesystem operation.
 */
export function managedWorktreeCleanupOffers(): ManagedWorktreeCleanupOffer[] {
  return snapshotSwarm()?.managedWorktreeCleanupOffers?.map(offer => ({ ...offer })) ?? [];
}

/** Compatibility name for consumers describing offers as allocation identities. */
export const managedWorkerCleanupIdentities = managedWorktreeCleanupOffers;

export function resolveManagedWorktreeCleanupOffer(runId: string, agentId: string): ManagedWorktreeCleanupOffer | null {
  if (!managedAllocationRunPattern.test(runId) || !managedAllocationAgentPattern.test(agentId)) return null;
  return managedWorktreeCleanupOffers().find(offer => offer.runId === runId.toLowerCase() && offer.agentId === agentId) ?? null;
}

/**
 * Called only after the worktree manager confirms the checkout was removed. Preserve a durable
 * closed marker on any retained broker row, so it cannot generate a fresh terminal offer after
 * the retirement catalog entry is deleted. Caller persists this mutation before reporting success.
 */
export function acknowledgeManagedWorktreeCleanupOffer(runId: string, agentId: string): boolean {
  const offer = resolveManagedWorktreeCleanupOffer(runId, agentId);
  if (!offer) return false;
  const key = cleanupOfferKey(offer);
  const owned = allFamilies().flatMap(owner => [...owner.agents.values()]
    .filter(agent => cleanupIdentity(agent.info) &&
      cleanupOfferKey(cleanupIdentity(agent.info)!) === key));
  if (owned.length > 1 || owned.some(agent =>
    unpublishedAgents.has(agent) ||
    (agent.info.state !== 'finished' && !(agent.info.state === 'failed' && agent.info.revivable !== true)))) {
    return false;
  }
  for (const agent of owned) {
    (agent.info as AgentInfo & { managedWorktreeCleaned?: boolean }).managedWorktreeCleaned = true;
  }
  managedWorktreeCleanupHistory.delete(key);
  changed();
  return true;
}

export function snapshotSwarm(): SwarmSnapshot | null {
  return buildSwarmSnapshot(false);
}

/** What each worker conversation's archive last received, so unchanged workers skip the store. */
const archivedAssignments = new Map<string, string>();

/**
 * Project only a snapshot whose broker write succeeded. Also migrate saved history before TTL
 * pruning. Callers do not wait on it, so it never rejects: a malformed entry is skipped.
 */
export async function archiveWorkerAssignments(snapshot: SwarmSnapshot | null): Promise<void> {
  if (!snapshot || ![4, 5, 6, 7].includes(snapshot.version) || !Number.isFinite(snapshot.savedAt)) return;
  const groups = snapshot.version >= 6 && Array.isArray(snapshot.activeRuns)
    ? snapshot.activeRuns : [{ agents: snapshot.agents }];
  const workers = [...groups, ...(Array.isArray(snapshot.dormantRuns) ? snapshot.dormantRuns : [])]
    .flatMap(group => Array.isArray(group?.agents) ? group.agents : []);
  for (const agent of workers) {
    const info = agent?.info;
    if (info?.role !== 'worker' || typeof info.conversationId !== 'string' || typeof info.id !== 'string' ||
        typeof info.label !== 'string' || typeof info.task !== 'string') continue;
    const key = JSON.stringify([info.id, info.label, info.task]);
    if (archivedAssignments.get(info.conversationId) === key) continue;
    try {
      await recordWorkerAssignment({ conversationId: info.conversationId, agentId: info.id,
        label: info.label, task: info.task, recordedAt: snapshot.savedAt });
      archivedAssignments.set(info.conversationId, key);
    } catch (err) {
      logWarn(`could not archive worker presentation: ${err instanceof Error ? err.message : String(err)}`);
    }
  }
}

/**
 * Snapshot used only by the explicit critical acceptance barrier.
 *
 * A staged agent message has to be present in exactly the generation whose successful
 * immediate write publishes acceptance. It must be absent from every ordinary/debounced
 * generation, because those can reach disk before the immediate writer succeeds. Keeping
 * this helper private makes that distinction structural rather than a convention callers can
 * accidentally bypass.
 */
function snapshotSwarmIncludingUnpublished(): SwarmSnapshot | null {
  return buildSwarmSnapshot(true);
}

/**
 * Earlier ids from disk: UUIDs only, never the current id, with one stable plus eight recent.
 * A legacy snapshot that already discarded an older peer address contains no trustworthy source
 * family for that opaque UUID, so restore preserves what exists and never reconstructs by guess.
 */
function savedFormerRunIds(saved: unknown, current: string): string[] | undefined {
  if (!Array.isArray(saved)) return undefined;
  const ids = saved.filter((id): id is string => typeof id === 'string' && id !== current &&
    /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id));
  const bounded = boundedFormerRunIds(ids);
  return bounded.length ? bounded : undefined;
}

function buildSwarmSnapshot(includeUnpublished: boolean): SwarmSnapshot | null {
  const stageEligible = (run: Run): boolean => {
    const stage = activeSpawnStages.get(run);
    return !stage || stage.durableReady;
  };
  const active = [...runs.values()].filter(r =>
    (!unpublishedRuns.has(r) || (includeUnpublished && stageEligible(r))));
  const dormant = [...dormantRuns.values()];
  if (active.length === 0 && dormant.length === 0 && retiredManagedWorkerConversations.size === 0 &&
      managedWorktreeCleanupHistory.size === 0) return null;
  // Legacy top-level projection is deliberately empty with multiple owners. Version 6 readers
  // use activeRuns exclusively; retaining a sole-owner projection keeps older diagnostic readers useful.
  const sole = active.length === 1 ? active[0] : null;
  const snapshot: SwarmSnapshot = { version: 7, savedAt: Date.now(), runId: sole?.runId ?? null,
    ...(sole?.setupProfileId ? { setupProfileId: sole.setupProfileId } : {}),
    primeConversationId: sole?.primeConversationId ?? null, startedAt: sole?.startedAt ?? null,
    agents: sole ? serializeAgents(sole.agents, includeUnpublished) : [],
    activeRuns: active.map(r => ({ runId: r.runId, ...(r.formerRunIds?.length ? { formerRunIds: r.formerRunIds } : {}),
      ...(r.setupProfileId ? { setupProfileId: r.setupProfileId } : {}), primeConversationId: r.primeConversationId,
      primeRequestId: r.primeRequestId,
      localOwnerId: r.localOwnerId,
      startedAt: r.startedAt, agents: serializeAgents(r.agents, includeUnpublished) })),
    ...(retiredManagedWorkerConversations.size ? { managedRetiredConversations: [...retiredManagedWorkerConversations] } : {}),
    dormantRuns: dormant.map(h => ({ ...(h.formerRunIds?.length ? { formerRunIds: h.formerRunIds } : {}),
      ...(h.setupProfileId ? { setupProfileId: h.setupProfileId } : {}), primeConversationId: h.primeConversationId, startedAt: h.startedAt,
      primeRequestId: h.primeRequestId,
      localOwnerId: h.localOwnerId,
      parkedAt: h.parkedAt, agents: serializeAgents(h.agents, includeUnpublished) })) };
  const offers = collectManagedWorktreeCleanupOffers([
    ...(snapshot.activeRuns ?? []).map(run => run.agents),
    ...(snapshot.dormantRuns ?? []).map(run => run.agents)
  ]);
  if (offers.length > 0) snapshot.managedWorktreeCleanupOffers = offers;
  return snapshot;
}

function serializeAgents(agents: Map<string, Agent>, includeUnpublished: boolean): SerializedAgent[] {
  const stage = [...activeSpawnStages.values()].find(candidate => candidate.run.agents === agents && !candidate.settled);
  const stagedEligible = !stage || stage.durableReady;
  const stagedFinishes =
    includeUnpublished
      ? [...activeFinishStages.values()].filter((stage) => !stage.settled && stage.run.agents === agents)
      : [];
  return [...agents.values()]
    .filter((agent) => !unpublishedAgents.has(agent) || (includeUnpublished && stagedEligible))
    .map((agent) => {
      const finish = includeUnpublished ? activeFinishStages.get(agent) : undefined;
      const info =
        finish && !finish.settled && finish.run.agents === agents
          ? {
              ...agent.info,
              state: finish.info.state,
              finishedAt: finish.info.finishedAt,
              sleptAt: finish.info.sleptAt,
              result: finish.info.result,
              revivable: finish.info.revivable,
              silenceParked: finish.info.silenceParked,
              silenceRecoveryTurnId: finish.info.silenceRecoveryTurnId,
              silenceRecoveryRequestOriginMax: finish.info.silenceRecoveryRequestOriginMax
            }
          : { ...agent.info };
      const finishAcknowledged =
        includeUnpublished && finish && !finish.settled && finish.run.agents === agents
          ? new Set(finish.acknowledgedMessageIds)
          : null;
      if (finishAcknowledged && finishAcknowledged.size > 0) {
        const newlyDelivered = agent.queue.filter(
          (message) => message.ackedAt === null && finishAcknowledged.has(message.id)
        ).length;
        info.delivered += newlyDelivered;
      }
      const queue = agent.queue
        .filter(
          (message) =>
            message.ackedAt === null &&
            (!finishAcknowledged || !finishAcknowledged.has(message.id)) &&
            (includeUnpublished || !unpublishedMessages.has(message))
        )
        .map((message) => ({ ...message }));
      if (finishAcknowledged) {
        info.pending = queue.length;
        info.awaitingAck = queue.filter((message) => message.offeredAt !== null).length;
      }
      if (includeUnpublished && agent.info.id === PRIME_ID) {
        queue.push(...stagedFinishes.map((stage) => ({ ...stage.report })));
      }
      return { info, queue };
    });
}

/**
 * Restores a run from disk.
 *
 * Messages that were in an ordinary MCP result come back unoffered rather than delivered: the
 * app cannot know whether that result ever arrived, and offering one twice is the recoverable
 * half of that uncertainty. A browser revival is different: its `sent` ACK proves ChatGPT
 * accepted the prime's words as a real user message, so that row keeps its offer marker and is
 * acknowledgement-only after restart. An open transfer is deliberately not restored — a
 * handover interrupted by a restart is abandoned, and the prime stays where it was.
 */
export function restoreSwarm(snapshot: SwarmSnapshot | null): void {
  requestOwnerEpoch++;
  requestOwnerRecovery = null;
  requestOwnerRecoveryAgain = false;
  runs.clear();
  dormantRuns.clear();
  retiredManagedWorkerConversations.clear();
  managedWorktreeHistoryPossible = false;
  managedWorktreeCleanupHistory.clear();
  unpublishedRuns.clear();
  activeSpawnStages.clear();
  activeFinishStages.clear();
  criticalMutationRevision = 0;
  persistedCriticalRevision = 0;
  criticalPersistFlight = null;
  if (!snapshot || !Array.isArray(snapshot.agents)) return;
  if (snapshot.version !== 4 && snapshot.version !== 5 && snapshot.version !== 6 && snapshot.version !== 7) {
    logInfo('multi-agent: discarded a run saved by an older build — spawn again to start a new one.');
    return;
  }
  if (Array.isArray(snapshot.managedWorktreeCleanupOffers)) {
    const seen = new Set<string>();
    const ambiguous = new Set<string>();
    for (const offer of snapshot.managedWorktreeCleanupOffers) {
      if (!offer || typeof offer.runId !== 'string' || typeof offer.agentId !== 'string' ||
          !managedAllocationRunPattern.test(offer.runId) || !managedAllocationAgentPattern.test(offer.agentId) ||
          !['completed', 'failed', 'cleared', 'evicted'].includes(offer.reason) ||
          !Number.isFinite(offer.createdAt) || offer.createdAt <= 0) continue;
      const normalized: ManagedWorktreeCleanupOffer = {
        runId: offer.runId.toLowerCase(), agentId: offer.agentId, reason: offer.reason,
        createdAt: offer.createdAt,
        ...(typeof offer.label === 'string' && offer.label.length <= 160 && offer.label.trim()
          ? { label: offer.label } : {})
      };
      const key = cleanupOfferKey(normalized);
      if (seen.has(key)) {
        managedWorktreeCleanupHistory.delete(key);
        ambiguous.add(key);
        continue;
      }
      seen.add(key);
      if (ambiguous.has(key)) continue;
      managedWorktreeCleanupHistory.set(key, normalized);
    }
  }
  // These rows deny access; they can never grant worker role, checkout ownership or revival.
  // Restore them before seven-day history pruning adds any newly evicted managed workers.
  if (Array.isArray(snapshot.managedRetiredConversations)) {
    for (const conversationId of snapshot.managedRetiredConversations) {
      if (typeof conversationId === 'string' && conversationId.length > 0 && conversationId.length <= 512)
        retiredManagedWorkerConversations.add(conversationId);
    }
  }
  let repaired = false;
  const occupiedWorkers = new Set<string>();
  const occupiedPrimes = new Set<string>();
  const ordinaryPrimes = new Set<string>();

  const occupiedRequests = new Set<string>();
  const validRequestOwner = (value: unknown): value is string =>
    typeof value === 'string' && /^[a-z0-9_-]{1,100}$/i.test(value);
  const acceptOwner = (primeConversationId: string | null, agents: Map<string, Agent>, primeRequestId?: string, localOwnerId?: string): boolean => {
    const prime = agents.get(PRIME_ID);
    if (!prime || prime.info.role !== 'prime' || prime.info.conversationId !== primeConversationId) return false;
    if (localOwnerId !== undefined && (!validLocalOwner(localOwnerId) || primeConversationId || primeRequestId)) return false;
    if (!primeConversationId && !validRequestOwner(primeRequestId) && !validLocalOwner(localOwnerId)) return false;
    if (primeRequestId && (!validRequestOwner(primeRequestId) || occupiedRequests.has(primeRequestId))) return false;
    if (primeConversationId && (occupiedWorkers.has(primeConversationId) ||
      (snapshot.version < 7 && occupiedPrimes.has(primeConversationId)) ||
      (!primeRequestId && ordinaryPrimes.has(primeConversationId)))) return false;
    const local = new Set<string>();
    for (const agent of agents.values()) {
      if (agent.info.id === PRIME_ID || !agent.info.conversationId) continue;
      if (agent.info.conversationId === primeConversationId || local.has(agent.info.conversationId) ||
        occupiedWorkers.has(agent.info.conversationId) || occupiedPrimes.has(agent.info.conversationId)) return false;
      local.add(agent.info.conversationId);
    }
    for (const conversationId of local) occupiedWorkers.add(conversationId);
    if (primeConversationId) {
      occupiedPrimes.add(primeConversationId);
      if (!primeRequestId) ordinaryPrimes.add(primeConversationId);
    }
    if (primeRequestId) occupiedRequests.add(primeRequestId);
    return true;
  };

  if (snapshot.version >= 5 && Array.isArray(snapshot.dormantRuns)) {
    for (const saved of snapshot.dormantRuns) {
      if (!saved || (!(typeof saved.primeConversationId === 'string' && saved.primeConversationId) &&
        !(snapshot.version === 7 && saved.primeConversationId === null && (validRequestOwner(saved.primeRequestId) || validLocalOwner(saved.localOwnerId)))) || !Array.isArray(saved.agents)) {
        repaired = true;
        continue;
      }
      const restored = deserializeAgents(saved.agents, snapshot.savedAt);
      repaired ||= restored.repaired;
      // A dormant history can never contain a slot-holder. If disk says otherwise, choosing to
      // run it beside another owner or silently sleeping live work would both be guesses.
      if ([...restored.agents.values()].some((agent) => agent.info.role === 'worker' && occupiesSlot(agent.info.state))) {
        repaired = true;
        logWarn(`multi-agent: discarded invalid dormant history for ${saved.primeConversationId} with a live worker`);
        continue;
      }
      const previousRunId = restored.agents.get(PRIME_ID)?.info.runId;
      const runId = typeof previousRunId === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(previousRunId)
        ? previousRunId : randomUUID();
      const restoredSetupProfileId = setupProfileId(saved.setupProfileId);
      if (saved.setupProfileId !== undefined && !restoredSetupProfileId) repaired = true;
      if (dormantRuns.has(runId) || !acceptOwner(saved.primeConversationId, restored.agents, snapshot.version === 7 ? saved.primeRequestId : undefined, saved.localOwnerId)) {
        repaired = true;
        logWarn(`multi-agent: discarded conflicting dormant history for ${saved.primeConversationId}`);
        continue;
      }
      if (runId !== previousRunId) repaired = true;
      for (const agent of restored.agents.values()) {
        agent.info.runId = runId;
        agent.info.primeConversationId = saved.primeConversationId ?? undefined;
      }
      dormantRuns.set(runId, {
        formerRunIds: savedFormerRunIds(saved.formerRunIds, runId),
        ...(restoredSetupProfileId ? { setupProfileId: restoredSetupProfileId } : {}),
        primeConversationId: saved.primeConversationId,
        primeRequestId: snapshot.version === 7 ? saved.primeRequestId : undefined,
        localOwnerId: saved.localOwnerId,
        startedAt: Number.isFinite(saved.startedAt) ? saved.startedAt : snapshot.savedAt || Date.now(),
        parkedAt: Number.isFinite(saved.parkedAt) ? saved.parkedAt : snapshot.savedAt || Date.now(),
        agents: restored.agents,
        transfer: null
      });
    }
    // Disk is the one place old history accumulates unchecked between parkings.
    if (pruneDormantRuns()) repaired = true;
  }

  const savedRuns = snapshot.version >= 6 ? (Array.isArray(snapshot.activeRuns) ? snapshot.activeRuns : []) : [snapshot];
  for (const saved of savedRuns) {
    if (!saved) { repaired = true; continue; }
    const hasActive =
      ((typeof saved.primeConversationId === 'string' && Boolean(saved.primeConversationId)) ||
        (snapshot.version === 7 && saved.primeConversationId === null && (('primeRequestId' in saved && validRequestOwner(saved.primeRequestId)) || validLocalOwner(saved.localOwnerId)))) &&
      typeof saved.runId === 'string' &&
      Boolean(saved.runId) &&
      Array.isArray(saved.agents);
    if (snapshot.version === 4 && !hasActive) {
      logInfo('multi-agent: discarded a version-4 run with no usable prime binding');
      return;
    }
    if (hasActive) {
      const primeConversationId = saved.primeConversationId;
      const primeRequestId = snapshot.version === 7 && 'primeRequestId' in saved && validRequestOwner(saved.primeRequestId)
        ? saved.primeRequestId : undefined;
      const restored = deserializeAgents(saved.agents, snapshot.savedAt);
      repaired ||= restored.repaired;
      if (runs.has(saved.runId!) || dormantRuns.has(saved.runId!) || !acceptOwner(primeConversationId, restored.agents, primeRequestId, saved.localOwnerId)) {
        logWarn(`multi-agent: discarded active run for ${primeConversationId} because its conversation ownership conflicted`);
        repaired = true;
      } else {
        const restoredSetupProfileId = setupProfileId(saved.setupProfileId);
        if (saved.setupProfileId !== undefined && !restoredSetupProfileId) repaired = true;
        const restoredRunId =
          typeof saved.runId === 'string' &&
          /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(saved.runId)
            ? saved.runId
            : randomUUID();
        if (restoredRunId !== saved.runId) {
          repaired = true;
          logWarn('multi-agent: re-keyed a restored run whose legacy incarnation id was not a full UUID');
        }
        const formerRunIds = savedFormerRunIds((saved as { formerRunIds?: unknown }).formerRunIds, restoredRunId);
        const run: Run = {
          runId: restoredRunId,
          ...(formerRunIds ? { formerRunIds } : {}),
          ...(restoredSetupProfileId ? { setupProfileId: restoredSetupProfileId } : {}),
          primeConversationId,
          primeRequestId,
          localOwnerId: saved.localOwnerId,
          startedAt: Number.isFinite(saved.startedAt) ? (saved.startedAt as number) : snapshot.savedAt || Date.now(),
          agents: restored.agents,
          transfer: null,
          primeGoneAt: null
        };
        if (runs.has(run.runId)) { repaired = true; continue; }
        runs.set(run.runId, run);
        stampOwner(run);
      }
    }

  }

  // This process has been watching for exactly no time. Every `lastSeenAt` that came back
  // from disk predates the restart and cannot be evidence of silence since it.
  livenessFloor = Date.now();

  // A crash can land after the final worker's sleeping snapshot but before the cheap parking
  // write. Reconstruct ownership first, then complete that lifecycle edge deterministically.
  const restoredActiveIds = [...runs.keys()];
  for (const run of [...runs.values()]) {
    if (workingWorkers(run).length === 0) {
      parkRun(run, 'restart recovered an active incarnation with no slot-holding workers');
      repaired = true;
    }
  }
  if (repaired) changed();

  // A worker that was invited but whose chat was never bound needs it opened again. If the
  // bridge is not registered yet — at startup it is not, because the run is restored first —
  // this is replayed by onSpawnRequest the moment it registers.
  const stranded = pendingWorkerSpawns();
  if (stranded.length > 0 && spawnRequest) {
    spawnRequest(stranded);
    logInfo(`multi-agent: re-requested ${stranded.length} worker chat(s) that were unbound at the restart`);
  }
  const activeAgents = [...runs.values()].flatMap(r => [...r.agents.values()]);
  const pending = activeAgents.reduce((sum, agent) => sum + agent.info.pending, 0);
  logInfo(
    `multi-agent: restored ${restoredActiveIds.length ? `active runs ${restoredActiveIds.join(', ')}` : 'no active run'} with ${dormantRuns.size} dormant owner histor${dormantRuns.size === 1 ? 'y' : 'ies'} and ${pending} active undelivered message(s)`
  );
}

function deserializeAgents(entries: readonly SerializedAgent[], savedAt: number): { agents: Map<string, Agent>; repaired: boolean } {
  const agents = new Map<string, Agent>();
  let repaired = false;
  for (const entry of entries) {
    if (!entry?.info?.id || agents.has(entry.info.id)) {
      repaired = true;
      continue;
    }
    const rawAllocation = entry.info.workerAllocationRunId;
      const allocation = typeof rawAllocation === 'string' &&
      managedAllocationRunPattern.test(rawAllocation)
      ? rawAllocation.toLowerCase() : undefined;
    if (rawAllocation !== undefined && !allocation) repaired = true;
    const agent: Agent = {
      info: {
        ...entry.info,
        workerAllocationRunId: allocation,
        managedWorktree: entry.info.managedWorktree === true,
        managedWorktreeCleaned: entry.info.managedWorktree === true && cleanupAcknowledged(entry.info),
        jobTitle: typeof entry.info.jobTitle === 'string' && entry.info.jobTitle ? entry.info.jobTitle.slice(0, 160) : undefined,
        model: isModelSlug(entry.info.model) ? entry.info.model : null,
        reasoningEffort: isReasoningEffort(entry.info.reasoningEffort) ? entry.info.reasoningEffort : null,
        sleptAt: typeof entry.info.sleptAt === 'number' ? entry.info.sleptAt : null,
        contextTokens: Number.isFinite(entry.info.contextTokens) ? entry.info.contextTokens : 0,
        lastRevivalCommandId:
          typeof entry.info.lastRevivalCommandId === 'string' && entry.info.lastRevivalCommandId
            ? entry.info.lastRevivalCommandId
            : null,
        silenceRecoveryTurnId:
          typeof entry.info.silenceRecoveryTurnId === 'string' && entry.info.silenceRecoveryTurnId
            ? entry.info.silenceRecoveryTurnId
            : null,
        silenceRecoveryRequestOriginMax:
          typeof entry.info.silenceRecoveryRequestOriginMax === 'number' &&
          Number.isFinite(entry.info.silenceRecoveryRequestOriginMax)
            ? entry.info.silenceRecoveryRequestOriginMax
            : null,
        silenceParked: entry.info.silenceParked === true
      },
      queue: (Array.isArray(entry.queue) ? entry.queue : []).map((message) => ({
        ...message,
        offeredAt:
          message.offeredViaRevival === true && typeof message.offeredAt === 'number' && Number.isFinite(message.offeredAt)
            ? message.offeredAt
            : null,
        offeredOnFinish: message.offeredOnFinish ?? false,
        offeredViaRevival: message.offeredViaRevival === true
      }))
    };
    if (agent.info.role === 'worker') {
      if (agent.info.state === 'invited' && agent.info.conversationId) {
        agent.info.state = 'active';
        agent.info.activatedAt ??= savedAt || Date.now();
        agent.info.revivable = false;
        repaired = true;
        logWarn(`multi-agent: repaired restored ${agent.info.id} from bound/invited to active`);
      }
      if (agent.info.state === 'finished' && agent.info.revivable) {
        agent.info.revivable = false;
        repaired = true;
      }
      if (agent.info.state === 'waking' && !agent.info.conversationId) {
        agent.info.state = 'sleeping';
        agent.info.sleptAt ??= savedAt || Date.now();
        agent.info.revivable = false;
        repaired = true;
        logWarn(`multi-agent: restored ${agent.info.id} out of waking; it has no chat to be woken in`);
      }
      if (
        agent.info.state === 'sleeping' &&
        ((!agent.info.revivable && !agent.info.silenceParked) || !agent.info.conversationId)
      ) {
        agent.info.state = 'finished';
        agent.info.finishedAt ??= agent.info.sleptAt ?? (savedAt || Date.now());
        agent.info.revivable = false;
        repaired = true;
      }
    }
    recount(agent);
    agents.set(entry.info.id, agent);
    if (agent.info.role === 'worker' && agent.info.managedWorktree) managedWorktreeHistoryPossible = true;
  }
  return { agents, repaired };
}

/** Test seam: forgets everything without touching disk. */
export function resetAgentsForTests(): void {
  requestOwnerEpoch++;
  requestOwnerRecovery = null;
  requestOwnerRecoveryAgain = false;
  runs.clear();
  dormantRuns.clear();
  retiredManagedWorkerConversations.clear();
  managedWorktreeHistoryPossible = false;
  managedWorktreeCleanupHistory.clear();
  archivedAssignments.clear();
  consecutiveWakeFailures.clear();
  transientWakeRetries.clear();
  pageGenerating.clear();
  unpublishedRuns.clear();
  activeSpawnStages.clear();
  activeFinishStages.clear();
  retiredWorkers.clear();
  livenessFloor = 0;
  spawnRequest = null;
  reviveRequest = null;
  persist = null;
  persistNow = null;
  criticalMutationRevision = 0;
  persistedCriticalRevision = 0;
  criticalPersistFlight = null;
  retiredPersist = null;
  retiredPersistNow = null;
  listeners.clear();
  endListeners.clear();
  retireListeners.clear();
}
