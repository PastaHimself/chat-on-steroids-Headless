/**
 * The model-facing surfaces this app publishes, and what each one is for.
 *
 * ChatGPT connects to one MCP server per connector, and the *whole* of that server's
 * tool list is one discovery unit: `api_tool.list_resources(paths=["Name"])` with no
 * query returns every schema the server advertises. A query narrows it, but nothing
 * guarantees the harness will ask a narrow one, so the honest planning number for a
 * surface is its complete tools/list — not the subset a lucky query would return.
 *
 * That is the entire reason this file exists. Splitting into separate servers is the
 * only mechanism that actually bounds the worst case, because a separate server is a
 * separate discovery boundary that no query can cross.
 *
 * It is deliberately not a splitting free-for-all. Every extra surface is another
 * connector the user has to create, name, describe and keep connected, and on the
 * OpenAI tunnel it is another tunnel id as well (see `docs/tool-surface.md` §6.4).
 * A surface has to earn that. The test applied here is: a distinct capability boundary
 * the user already thinks in, plus enough schema weight that folding it into Core
 * would meaningfully raise Core's no-query cost.
 *
 * Two surfaces pass that test today.
 */

import type { Capabilities } from '../../shared/types.js';
import { desktopAutomationSupported } from '../platform.js';
import { getConfig } from '../config.js';
import { CONNECTOR_BRAND, connectorName } from '../../shared/connector-names.js';
import { learnedConnectorName } from '../connector-identity.js';
import { WINDOWS_COMPUTER_METHODS, WINDOWS_COMPUTER_READ_METHODS, WINDOWS_COMPUTER_INPUT_METHODS } from '../../shared/windows-computer.js';
import { BROWSER_TOOLS, BROWSER_READ_TOOLS, BROWSER_WRITE_TOOLS } from '../../shared/browser-control.js';

export const SURFACE_IDS = ['core', 'desktop', 'plugins'] as const;
export type SurfaceId = (typeof SURFACE_IDS)[number];

/**
 * Brand shown to the user and pasted into ChatGPT.
 *
 * One constant because it appears in the MCP server name, the suggested connector
 * name and the setup cards, and those three drifting apart is how a user ends up with
 * a connector whose name does not match the thing the instructions told them to type.
 */
export { CONNECTOR_BRAND };

export interface SurfaceDefinition {
  id: SurfaceId;
  /** MCP server name. Stable; ChatGPT keys its cached metadata off it. */
  serverName: string;
  /**
   * Exactly what the user should type as the connector name in ChatGPT.
   *
   * Offered as copyable text rather than described, because the name is also the
   * retrieval handle: `paths=["…"]` is matched against it, and a user who invents
   * "my pc" gets a surface the model cannot address by name.
   */
  connectorName: string;
  /**
   * Exactly what the user should paste as the connector description.
   *
   * This is the single most load-bearing string in the whole design. Before any
   * discovery has happened the model holds the server name and this sentence and
   * nothing else, and it decides from them alone whether to pull this surface's
   * schemas at all. So it is written as vocabulary, not as prose: the words a person
   * would actually use for the work live in here, because a query that misses is
   * indistinguishable to the model from a capability that does not exist.
   */
  description: string;
  /** Short line for the setup card, in the app's own voice. */
  cardSummary: string;
  /**
   * Whether the app is usable without it. Core is required; Desktop is opt-in and
   * most sessions never want it.
   */
  required: boolean;
  /**
   * Every tool this surface can ever advertise, in listing order.
   *
   * The authority for tests, for the setup UI's "what you get" list, and for the
   * cross-surface leakage assertions. A tool that appears here and nowhere else is a
   * bug in one direction; a tool registered on a server that does not name it here is
   * a bug in the other.
   */
  tools: readonly string[];
}

/**
 * Core — the coding loop.
 *
 * Workers are part of the coding loop:
 *
 *  - `agents` is one flat tool and is registered only while multi-agent mode is on.
 *    Fresh installs enable it; an existing config that keeps it off still pays nothing for
 *    it here. A dedicated connector for one conditional schema is pure setup overhead with
 *    no discovery benefit.
 *
 * Each surface also exposes JavaScript exec, restricted to that surface's own tools.
 * `find` and the exec pair are mutually exclusive — `find` exists only when command
 * execution is off — so not all declarations are exposed together.
 */
const CORE: SurfaceDefinition = {
  id: 'core',
  serverName: 'chat-on-steroids-core',
  connectorName: `${CONNECTOR_BRAND} Core`,
  description:
    'Read and edit code and text files on this computer, and run commands in a real terminal. ' +
    'Use for: opening and reading files, searching a repository, applying patches, creating, renaming and deleting files, ' +
    'running builds, tests, linters, git, npm and shell commands, continuing long-running or interactive terminal sessions, ' +
    'and saving images and files ChatGPT generates onto this computer. ' +
    'Also displays task plans and — when the user has ' +
    'enabled it — spawns and coordinates worker agents, subagents or a parallel swarm across several ChatGPT conversations.',
  cardSummary: 'Files, patches and terminal.',
  required: true,
  tools: ['read', 'view_image', 'find', 'apply_patch', 'save_image', 'exec_command', 'write_stdin', 'update_plan', 'agents', 'session_finish', 'usage', 'exec']
};

/**
 * Desktop — seeing and driving the native desktop.
 *
 * This one earns its boundary twice over. It is gated on permissions the user grants
 * separately and can switch off independently; Windows has the Window2 app/window API,
 * while macOS retains observe/computer. The majority of coding sessions
 * never touch the desktop at all. Folding it into Core would put its weight into every
 * no-query discovery of the coding surface, for a capability most conversations do not
 * want.
 */
const DESKTOP: SurfaceDefinition = {
  id: 'desktop',
  serverName: 'chat-on-steroids-desktop',
  connectorName: `${CONNECTOR_BRAND} Desktop`,
  description:
    'Control browser tabs in the background and this computer desktop, including its clipboard. ' +
    'Attach existing Chrome/Edge/Brave tabs or open new tabs; inspect DOM refs, page screenshots, JavaScript, console errors and network requests; click, fill forms and navigate without foreground activation. ' +
    'Use for: listing and launching apps, taking background window screenshots, reading what is on screen, listing and finding windows, inspecting buttons, fields and other UI controls, ' +
    'clicking, typing, pressing keys, scrolling and dragging in native applications, ' +
    'and reading the clipboard or copying and pasting text between programs.',
  cardSummary: 'Browser and desktop apps.',
  required: false,
  tools: [...BROWSER_TOOLS, ...WINDOWS_COMPUTER_METHODS, 'read_clipboard', 'write_clipboard', 'observe', 'computer', 'exec']
};

const PLUGINS: SurfaceDefinition = {
  id: 'plugins', serverName: 'chat-on-steroids-plugins',
  connectorName: `${CONNECTOR_BRAND} Plugins`,
  description: 'Tools from external MCP integrations installed and enabled in Chat On Steroids Settings, including Blender and other connected applications and services.',
  cardSummary: 'One shared connector for your enabled external MCP plugins.',
  required: false,
  // Dynamic declarations are owned and bounded by the plugin manager.
  tools: ['exec']
};

export const SURFACES: Record<SurfaceId, SurfaceDefinition> = { core: CORE, desktop: DESKTOP, plugins: PLUGINS };

export const SURFACE_LIST: readonly SurfaceDefinition[] = [CORE, DESKTOP, PLUGINS];

/**
 * A surface as this install presents it to the model. The connector name is the live one (a
 * rename in ChatGPT is followed once a served call proves it), else the configured name with this
 * computer's suffix
 * (Settings › Setup), read at every call so a saved change reaches the Setup cards, the server
 * instructions and plugin refresh without a restart. `SURFACES` keeps the plain names.
 */
export function surfaceDefinition(id: SurfaceId): SurfaceDefinition {
  return { ...SURFACES[id], connectorName: liveConnectorName(id) };
}

/** The name this install tells the user to give the connector, and serves as its resource name. */
export function configuredConnectorName(id: SurfaceId): string {
  return connectorName(id, getConfig().connectorSuffix);
}

/**
 * What ChatGPT currently calls this surface's connector: the name proven by a served call
 * (connector-identity.ts; it follows a rename), else the configured one. Model-facing text uses this.
 */
export function liveConnectorName(id: SurfaceId): string {
  return learnedConnectorName(id) ?? configuredConnectorName(id);
}

/** Platform/capability projection used by setup; each registrar enforces the same split. */
export function desktopToolNames(caps: Capabilities, platform: NodeJS.Platform = process.platform): string[] {
  const browser = [...(caps.screen ? BROWSER_READ_TOOLS : []), ...(caps.control ? BROWSER_WRITE_TOOLS : [])];
  if (!desktopAutomationSupported(platform)) return browser;
  if (platform !== 'win32') return [...browser, ...(caps.screen ? ['observe'] : []), ...(caps.control || caps.clipboardRead || caps.clipboardWrite ? ['computer'] : [])];
  return [
    ...browser,
    ...(caps.screen ? WINDOWS_COMPUTER_READ_METHODS : []),
    ...(caps.control ? WINDOWS_COMPUTER_INPUT_METHODS : []),
    ...(caps.clipboardRead ? ['read_clipboard'] : []),
    ...(caps.clipboardWrite ? ['write_clipboard'] : [])
  ];
}

/**
 * Whether a surface has anything to offer under these capabilities.
 *
 * Desktop with neither screen, control nor clipboard access would advertise an empty tool list,
 * which is worse than not being offered: the user pays the whole setup cost for a
 * connector that can do nothing, and ChatGPT shows them a working connection. The
 * setup UI uses this to grey the card out and say why.
 *
 * Core remains the required surface even when its live tool list is temporarily empty. Keeping
 * that identity stable is what lets permissions be enabled again without changing connectors.
 */
export function surfaceIsUseful(
  id: SurfaceId,
  caps: Capabilities,
  platform: NodeJS.Platform = process.platform,
  release?: string
): boolean {
  // Clipboard counts: it is reached through `computer`, so granting only the clipboard
  // still gives this surface something real to advertise.
  if (id === 'desktop') {
    return (
      caps.screen || caps.control || (desktopAutomationSupported(platform, release) && (caps.clipboardRead || caps.clipboardWrite))
    );
  }
  return true;
}
