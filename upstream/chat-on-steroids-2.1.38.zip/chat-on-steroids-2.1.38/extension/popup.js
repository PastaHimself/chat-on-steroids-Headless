/**
 * Status UI, and the one place that answers "where did the stream stop?".
 *
 * Current-turn request evidence is distinct from whole-chat recording counters.
 * "Reaching the app" separates finding the ID, app receipt and exact owner confirmation;
 * only the activity feed can additionally prove a matching tool invocation was recorded.
 *
 * It opens itself when something is wrong and stays shut when nothing is, because a panel
 * that is always expanded is a panel nobody reads.
 */

const $ = (id) => document.getElementById(id);
const { t, localizeDocument } = globalThis.CLF_I18N;
const RENDER_STREAM_KEY = 'renderStreamEnabled';
const SHOW_TIMES_KEY = 'showStreamTimes';
const POLL_MS = 1500;

localizeDocument();

let overwriteEnabled = true;
let showTimes = false;
let latest = { status: null, tab: null };
let openedOnFailure = false;
let transferringSignIn = false;
let transferredSignIn = false;

// ------------------------------------------------------------------ formatting

/** Ids are long and only their ends identify them, so keep both ends rather than one. */
function shorten(value, keep = 6) {
  const text = String(value || '');
  if (text.length <= keep + 5) return text;
  return `${text.slice(0, keep)}…${text.slice(-4)}`;
}

function ago(at) {
  if (!at) return '';
  const seconds = Math.max(0, Math.round((Date.now() - at) / 1000));
  if (seconds < 60) return t('popup_time_seconds_short', '$1s', seconds);
  if (seconds < 3600) return t('popup_time_minutes_short', '$1m', Math.round(seconds / 60));
  return t('popup_time_hours_short', '$1h', Math.round(seconds / 3600));
}

/** One capture row: ok, no, wait or off, plus whatever it wants to say on the right. */
function row(name, state, meta) {
  $(`r-${name}`).className = `row ${state}`;
  const value = $(`d-${name}`);
  value.textContent = meta === null || meta === undefined ? '' : meta;
}

function idRow(name, state, meta, full) {
  row(name, state, meta);
  const value = $(`d-${name}`);
  value.title = full || '';
  value.disabled = !full;
}

function stage(name, state, meta) {
  $(`s-${name}`).className = `stage ${state}`;
  $(`n-${name}`).textContent = meta || '';
}

// -------------------------------------------------------------------- pipeline

/** How the app describes what it placed a call on, in its own words. */
const ATTRIBUTION = {
  request_id: t('popup_attribution_exact_request_id', 'exact request id'),
  unattributed: t('popup_attribution_request_id_not_resolved', 'request id not resolved'),
  agent: t('popup_attribution_agent_key', 'agent key'),
  turn: t('popup_attribution_tool_block_on_page', 'tool block on the page'),
  generation: t('popup_attribution_only_chat_generating', 'the only chat generating'),
  inferred: t('popup_attribution_not_placed_in_chat', 'not placed in a chat')
};

/**
 * The three stages, from evidence each layer produced independently.
 *
 * Global transport failures explain a blocked path. Success needs this chat's session
 * receipt and exact evidence projected from its newest native turn. Queue custody and
 * owner acknowledgement do not claim a matching MCP invocation has run.
 */
function pipeline(info, ready) {
  const page = info && info.page;
  const sent = info && info.delivery;
  const pending = info ? info.pending : 0;
  const read = page ? page.events : 0;
  const calls = page && Array.isArray(page.trace) ? page.trace : [];

  if (!info || !info.isChat) return { read: ['off'], sent: ['off'], proc: ['off'], why: ['', ''] };
  if (!info.recorder) {
    return { read: ['failed'], sent: ['off'], proc: ['off'], why: ['bad', t('popup_pipeline_no_recorder', 'No recorder in this tab. Reload the page.')] };
  }
  if (read === 0) {
    return { read: ['running'], sent: ['off'], proc: ['off'], why: ['', t('popup_pipeline_waiting_first_message', 'Waiting for the first message.')] };
  }

  const readStage = calls.length ? ['done', String(calls.length)] : ['running'];
  if (!ready) {
    return {
      read: readStage,
      sent: ['failed', pending ? t('popup_count_held', '$1 held', pending) : ''],
      proc: ['off'],
      why: ['bad', t('popup_pipeline_delivery_blocked', 'Delivery is blocked until the app is connected and protocol compatibility is confirmed.')]
    };
  }
  if (sent && sent.ok === false) {
    return {
      read: readStage,
      sent: ['failed', String(sent.error || t('popup_status_failed', 'failed'))],
      proc: ['off'],
      why: ['bad', t('popup_pipeline_delivery_rejected', 'The app rejected the last delivery ($1).', sent.error || t('popup_status_failed', 'failed'))]
    };
  }
  // Refused by the extension itself, before anything could be queued for the app. `pending`
  // counts only what the service worker already owns, so a document it is rejecting outright
  // reported nothing pending and this drawer went on to say "Delivered" — which is what it
  // said all through the 2026-08-21 blackout while the tab was reading ChatGPT perfectly and
  // sending none of it. The page is the only layer that knows, so it is the layer that says so.
  if (page.blocked) {
    return {
      read: readStage,
      sent: ['failed', page.queued ? t('popup_count_held_in_page', '$1 held in page', page.queued) : String(page.blocked)],
      proc: ['off'],
      why: [
        'bad',
        t(
          'popup_pipeline_extension_blocked',
          'The extension is not accepting this tab’s observations ($1). Reload the ChatGPT tab.',
          page.blocked
        )
      ]
    };
  }
  if (pending > 0) {
    return {
      read: readStage,
      sent: ['running', t('popup_count_queued', '$1 queued', pending)],
      proc: ['off'],
      why: ['', t('popup_pipeline_queued_retrying', 'Queued here. Retrying delivery to the app.')]
    };
  }

  if (!page.session) {
    return {
      read: readStage,
      sent: ['running'],
      proc: ['running'],
      // The worker's delivery counters cover every tab. Only the page's session
      // receipt proves that this particular chat reached the app.
      why: ['', t('popup_pipeline_waiting_session_receipt', 'App reachable. Waiting for this chat’s session receipt.')]
    };
  }
  if (!calls.length) return {
    read: ['running'], sent: ['off'], proc: ['off'],
    why: ['', t('popup_pipeline_waiting_latest_request_id', 'Chat recorded. Waiting for a request ID from the latest turn.')]
  };
  const received = calls.filter(call => call.sent || call.app === 'request_id').length;
  const confirmed = calls.filter(call => call.confirmed || call.app === 'request_id').length;
  const sentStage = [received === calls.length ? 'done' : 'running', `${received}/${calls.length}`];
  const placed = calls.filter((call) => call.app === 'request_id').length;
  const missed = calls.filter((call) => call.app && call.app !== 'request_id');
  if (missed.length > 0) {
    return {
      read: readStage,
      sent: sentStage,
      proc: ['failed', `${placed}/${calls.length}`],
      why: [
        'bad',
        missed.length === 1
          ? t(
            'popup_pipeline_call_fallback_one',
            'The app could not place a call by request id — it fell back to $1.',
            ATTRIBUTION[missed[0].app] || missed[0].app
          )
          : t(
            'popup_pipeline_call_fallback_many',
            'The app could not place $1 calls by request id — it fell back to $2.',
            [missed.length, ATTRIBUTION[missed[0].app] || missed[0].app]
          )
      ]
    };
  }
  return {
    read: ['done', String(calls.length)],
    sent: sentStage,
    proc: [confirmed === calls.length ? 'done' : 'running', `${confirmed}/${calls.length}`],
    why: ['', placed > 0
      ? placed === 1
        ? t('popup_pipeline_request_id_matched_one', '1 request ID matched to recorded tool activity.')
        : t('popup_pipeline_request_id_matched_many', '$1 request IDs matched to recorded tool activity.', placed)
      : confirmed > 0 ? t('popup_pipeline_owner_confirmed_no_activity', 'Request owner confirmed. No matching tool activity recorded yet.')
        : received > 0 ? t('popup_pipeline_received_waiting_owner', 'App received the ID. Waiting for owner confirmation.')
          : t('popup_pipeline_id_found_waiting_receipt', 'ID found in the latest turn. Waiting for the app to confirm receipt.')]
  };
}

/** One row per request id: three dots, the tool, the id. Newest first. */
function paintCalls(page) {
  const box = $('calls');
  box.textContent = '';
  const rows = page && Array.isArray(page.trace) ? page.trace.slice(0, 5) : [];
  for (const entry of rows) {
    const line = document.createElement('div');
    line.className = 'call';
    const pips = document.createElement('span');
    pips.className = 'pips';
    for (const state of [
      entry.read ? 'on' : '',
      entry.sent || entry.app === 'request_id' ? 'on' : '',
      entry.confirmed || entry.app === 'request_id' ? 'on' : entry.app ? 'bad' : ''
    ]) {
      const pip = document.createElement('span');
      pip.className = `pip ${state}`;
      pips.append(pip);
    }
    const tool = document.createElement('span');
    tool.className = 'tool';
    tool.textContent = entry.tool || t('popup_request_id', 'request ID');
    const id = document.createElement('span');
    id.className = 'id';
    id.textContent = shorten(entry.requestId, 5);
    line.title = t(
      'popup_call_details',
      '$1 — found $2 · app receipt $3 · owner $4 · tool activity $5',
      [
        entry.requestId,
        entry.read ? t('popup_yes', 'yes') : t('popup_no', 'no'),
        entry.sent || entry.app === 'request_id' ? t('popup_confirmed', 'confirmed') : t('popup_pending', 'pending'),
        entry.confirmed ? t('popup_confirmed', 'confirmed') : t('popup_pending', 'pending'),
        ATTRIBUTION[entry.app] || t('popup_no_record', 'no record')
      ]
    );
    line.append(pips, tool, id);
    box.append(line);
  }
}

// ------------------------------------------------------------------- rendering

function paintHeader(status) {
  const connected = status && status.connected === true;
  const paired = status && status.paired === true;
  const incompatible = connected && status.compatible === false;
  // Disconnected on purpose. This has to say so plainly rather than describing it as a
  // connection that has not finished yet, which is what it looked like back when the next
  // poll would silently undo it.
  const off = status && status.disconnected === true && !paired;
  const ready = connected && paired && status.compatible === true;

  $('pill').className = `pill ${ready ? '' : incompatible ? 'bad' : 'off'}`;
  $('state').textContent = incompatible
    ? t('popup_state_version_mismatch', 'Version mismatch')
    : off
      ? t('popup_state_disconnected', 'Disconnected')
      : !connected
        ? t('popup_state_app_not_reachable', 'App not reachable')
        : ready
          // Health + pairing prove reachability, not the recorder/command flow.
          ? t('popup_state_app_reachable_port', 'App reachable · Port $1', status.port)
          : t('popup_state_port_connecting', 'Port $1 · connecting', status.port);

  // The one state with nothing to click at the top: say what to do instead of a grey pill alone.
  $('appHint').hidden = !(status && !connected && !off);
  $('retryBtn').hidden = ready || incompatible;
  $('retryBtn').textContent = off ? t('popup_connect', 'Connect') : t('popup_try_again', 'Try again');
  return ready;
}

function paintAlert(status, info) {
  const page = info && info.page;
  const incompatible = status && status.connected === true && status.compatible === false;
  const pairError = status && status.pairError;
  const error = page && page.lastError;
  const text = incompatible
    ? t(
      'popup_version_mismatch_help',
      "App v$1 (protocol $2); extension v$3 (protocol $4). Open your browser's Extensions page, enable Developer mode, then Update / Reload this extension. If the mismatch remains, use Open extension folder in Chat On Steroids and load that folder. Reload ChatGPT tabs when their active work is finished.",
      [status.appVersion || '?', status.appProtocol ?? '?', status.extensionVersion || '?', status.extensionProtocol ?? '?']
    )
    : pairError && pairError.message
      ? pairError.message
      : pairError && pairError.error === 'secure_storage_unavailable'
        ? t('popup_secure_storage_unavailable', 'Secure credential storage is unavailable. Open Chat On Steroids for setup instructions.')
    : error && Date.now() - error.at < 10 * 60 * 1000
      ? error.text
      : '';
  $('alert').textContent = text;
  $('alert').hidden = !text;
}

function detail(list, term, value, bad) {
  const dt = document.createElement('dt');
  dt.textContent = term;
  const dd = document.createElement('dd');
  dd.textContent = value === null || value === undefined || value === '' ? '—' : String(value);
  if (bad) dd.className = 'bad';
  dd.title = dd.textContent;
  list.append(dt, dd);
}

/**
 * Only what changes the reading of the three stages.
 *
 * An earlier draft of this drawer listed twenty-eight fields, which is a different thing
 * from being informative: nothing in it told you which layer had stopped.
 */
function paintDetails(status, info) {
  if (!$('more').open) return;
  const grid = $('grid');
  grid.textContent = '';
  const page = info && info.page;
  const sent = info && info.delivery;

  detail(
    grid,
    t('popup_detail_app', 'app'),
    status ? t('popup_detail_app_value', 'v$1 · port $2', [status.appVersion || '?', status.port || '—']) : null
  );
  detail(
    grid,
    t('popup_detail_extension', 'extension'),
    status ? t('popup_detail_extension_value', 'v$1 · protocol $2', [status.extensionVersion, status.extensionProtocol]) : null,
    status && status.compatible === false
  );
  detail(grid, t('popup_detail_chat_id', 'chat id'), (info && info.conversationId) || null);
  detail(grid, t('popup_detail_app_session', 'app session'), (page && page.session) || null, Boolean(page && !page.session));
  detail(
    grid,
    t('popup_detail_tab', 'tab'),
    info ? t('popup_detail_tab_value', '$1 · epoch $2', [info.tab, info.epoch ?? '—']) : null
  );
  detail(
    grid,
    t('popup_detail_ownership', 'ownership'),
    info ? (info.terminal
      ? t('popup_status_retired', 'retired')
      : info.bound
        ? t('popup_status_bound', 'bound')
        : t('popup_status_unbound', 'unbound')) : null,
    Boolean(info && info.terminal)
  );
  detail(
    grid,
    t('popup_detail_recorder', 'recorder'),
    page
      ? t('popup_detail_recorder_value', 'fiber v$1 · run $2', [page.recorderVersion, page.runId])
      : t('popup_status_not_attached', 'not attached'),
    !page
  );
  detail(
    grid,
    t('popup_detail_turn', 'turn'),
    page ? (page.generating
      ? t('popup_detail_turn_live', '$1 · live', shorten(page.turnId, 8))
      : t('popup_status_idle', 'idle')) : null
  );
  detail(
    grid,
    t('popup_detail_observed', 'observed'),
    page ? t('popup_detail_observed_value', '$1 events · $2 calls', [page.events, page.calls]) : null
  );
  detail(
    grid,
    t('popup_detail_in_this_browser', 'in this browser'),
    info ? t('popup_detail_browser_queue_value', '$1 held · $2 total', [info.pending, info.pendingAll]) : null,
    Boolean(info && info.pendingAll)
  );
  const deliveryState = sent ? (sent.ok ? t('popup_status_ok', 'ok') : sent.error || t('popup_status_failed', 'failed')) : '';
  detail(
    grid,
    t('popup_detail_last_delivery', 'last delivery'),
    sent && sent.at
      ? t('popup_detail_last_delivery_value', '$1 · $2 · $3 ago', [deliveryState, sent.events, ago(sent.at)])
      : null,
    Boolean(sent && sent.ok === false)
  );
  detail(grid, t('popup_detail_delivered', 'delivered'), sent ? sent.total : null);
  detail(
    grid,
    t('popup_detail_page_sends', 'page sends'),
    page ? t('popup_detail_page_sends_value', '$1 · $2 failed', [page.sends, page.failures]) : null,
    Boolean(page && page.failures)
  );
}

async function refresh() {
  const [status, info] = await Promise.all([
    chrome.runtime.sendMessage({ type: 'status' }),
    chrome.runtime.sendMessage({ type: 'tabStatus' }).catch(() => null)
  ]);
  latest = { status, tab: info };

  const ready = paintHeader(status);
  const isChat = Boolean(info && info.isChat);
  const page = info && info.page;

  row('tab', isChat ? 'ok' : 'off', isChat ? '' : t('popup_status_none_open', 'none open'));
  row(
    'rec',
    !isChat ? 'off' : info.recorder ? 'ok' : 'no',
    !isChat ? '' : info.recorder ? (page.generating ? t('popup_status_answering', 'answering') : '') : t('popup_status_reload', 'reload')
  );

  const chatId = info && info.conversationId;
  idRow(
    'chat',
    !isChat ? 'off' : chatId ? 'ok' : 'wait',
    !isChat ? '' : chatId ? shorten(chatId, 8) : t('popup_status_new_chat', 'new chat'),
    chatId
  );

  const requestId = page && page.requestId;
  idRow(
    'req',
    !isChat ? 'off' : requestId ? 'ok' : 'wait',
    !isChat ? '' : requestId ? shorten(requestId, 9) : t('popup_status_none_yet', 'none yet'),
    requestId
  );

  const state = pipeline(info, ready);
  stage('read', ...state.read);
  stage('sent', ...state.sent);
  stage('proc', ...state.proc);
  $('why').textContent = state.why[1];
  $('why').className = `why ${state.why[0]}`;
  paintCalls(page);

  const broken = state.why[0] === 'bad';
  const flowing = Array.isArray(page?.trace) && page.trace.some(call => call.app === 'request_id');
  row(
    'app',
    !isChat ? 'off' : broken ? 'no' : flowing ? 'ok' : 'wait',
    !isChat
      ? ''
      : broken
        ? t('popup_status_blocked', 'blocked')
        : flowing
          ? t('popup_status_tool_matched', 'tool matched')
          : state.proc[0] === 'done'
            ? t('popup_status_id_confirmed', 'ID confirmed')
            : t('popup_status_waiting', 'waiting')
  );
  // Opens itself the first time something is actually wrong, so the panel that explains
  // the failure is already open when the popup is opened to look at one.
  if (broken && !openedOnFailure) {
    openedOnFailure = true;
    $('stream').open = true;
  }

  paintAlert(status, info);
  paintDetails(status, info);
  $('signInTransfer').hidden = !status?.signInOffer && !transferredSignIn && !$('signInTransferResult').textContent;
  $('signInTransferBtn').disabled = transferringSignIn || transferredSignIn || !status?.signInOffer;
}

// -------------------------------------------------------------------- controls

$('signInTransferBtn').addEventListener('click', async () => {
  const offer = latest.status?.signInOffer;
  if (!offer || transferringSignIn) return;
  const section = $('signInTransfer');
  const result = $('signInTransferResult');
  transferringSignIn = true;
  $('signInTransferBtn').disabled = true;
  section.setAttribute('aria-busy', 'true');
  result.textContent = '';
  try {
    // Request from this user gesture, before any messaging/await can lose Chrome's gesture.
    const allowed = await chrome.permissions.request({ permissions: ['cookies'] });
    if (!allowed) {
      result.textContent = t('popup_sign_in_permission', 'Cookie access not allowed. Click again.');
      return;
    }
    const reply = await chrome.runtime.sendMessage({ type: 'cos_sign_in_transfer', id: offer.id });
    transferredSignIn = reply?.imported === true;
    if (transferredSignIn) {
      // The receipt takes the button's place.
      $('signInTransferBtn').hidden = true;
      $('signInTransferDone').hidden = false;
    } else result.textContent = t('popup_sign_in_failed', 'Transfer failed. Start sign-in again from CoS.');
  } catch {
    result.textContent = t('popup_sign_in_failed', 'Transfer failed. Start sign-in again from CoS.');
  } finally {
    transferringSignIn = false;
    section.removeAttribute('aria-busy');
    $('signInTransferBtn').disabled = transferredSignIn;
  }
});

function syncOverwrite() {
  $('overwriteToggle').checked = overwriteEnabled;
}

async function loadPreferences() {
  const stored = await chrome.storage.local.get([RENDER_STREAM_KEY, SHOW_TIMES_KEY]);
  overwriteEnabled = stored[RENDER_STREAM_KEY] !== false;
  showTimes = stored[SHOW_TIMES_KEY] === true;
  syncOverwrite();
  $('timeToggle').checked = showTimes;
}

/** Puts one value on the clipboard and says so in place, without moving anything. */
async function copyInto(button, text) {
  if (!text) return;
  const was = button.textContent;
  const copied = t('popup_copied', 'copied');
  const copyFailed = t('popup_copy_failed', 'copy failed');
  try {
    await navigator.clipboard.writeText(text);
    button.textContent = copied;
  } catch {
    button.textContent = copyFailed;
  }
  setTimeout(() => {
    if (button.textContent === copied || button.textContent === copyFailed) button.textContent = was;
  }, 900);
}

for (const id of ['d-chat', 'd-req']) {
  $(id).addEventListener('click', (event) => {
    event.preventDefault();
    void copyInto(event.currentTarget, event.currentTarget.title);
  });
}

$('copyBtn').addEventListener('click', (event) => {
  const cells = [...$('grid').children].map((node) => node.textContent);
  const lines = [$('why').textContent];
  for (let index = 0; index < cells.length; index += 2) lines.push(`${cells[index]}: ${cells[index + 1]}`);
  void copyInto(event.currentTarget, lines.join('\n'));
});

$('more').addEventListener('toggle', () => paintDetails(latest.status, latest.tab));

$('retryBtn').addEventListener('click', async () => {
  $('retryBtn').disabled = true;
  await chrome.runtime.sendMessage({ type: 'pair' });
  $('retryBtn').disabled = false;
  await refresh();
});

$('overwriteToggle').addEventListener('change', async () => {
  const previous = overwriteEnabled;
  overwriteEnabled = $('overwriteToggle').checked === true;
  syncOverwrite();
  try {
    await chrome.storage.local.set({ [RENDER_STREAM_KEY]: overwriteEnabled });
    // The toggle is the action. Enabling it immediately pulls the latest app timeline into
    // every known ChatGPT tab; there is deliberately no second "Overwrite now" button.
    if (overwriteEnabled) await chrome.runtime.sendMessage({ type: 'overwriteNow' });
  } catch {
    overwriteEnabled = previous;
    syncOverwrite();
  }
});

$('timeToggle').addEventListener('change', async () => {
  showTimes = $('timeToggle').checked === true;
  await chrome.storage.local.set({ [SHOW_TIMES_KEY]: showTimes });
});

// A popup is open for seconds at a time and the three stages move within those seconds.
void loadPreferences().catch(() => undefined);
void refresh().catch(() => undefined);
// The app's language arrives with its catalog a moment later; repaint once it is there and on
// every later change, so the popup reads like the app rather than like Chrome.
const relocalize = () => { localizeDocument(); void refresh().catch(() => undefined); };
void globalThis.CLF_I18N.ready?.then(relocalize).catch(() => undefined);
globalThis.addEventListener?.('clf-i18n-changed', relocalize);
setInterval(() => void refresh().catch(() => undefined), POLL_MS);
